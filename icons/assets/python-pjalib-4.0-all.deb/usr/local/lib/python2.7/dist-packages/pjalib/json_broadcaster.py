#!/usr/bin/env python

from json_networking import JSONServer, JsonServerHandler
import  threading

class SrcJsonServerHandler (JsonServerHandler):
    """@brief The handler for the server that receives JSON messages which
              are then forwarded to all destinations."""

    def handle(self):
        try:

            try:

                while True:

                    rxDict = JsonServerHandler.RX(self.request)
                    if rxDict:
                        self._sendToAllDests(rxDict)

            finally:
                pass

        except RuntimeError:

            if self.request:
                self.request.close()

    def _sendToAllDests(self, rxDict):
        """@brief Send the dict to all dest clients.
           @param rxDict The JSON data received."""
        for destClient in self.destClientList:
            #Send the dict in another thread so that TX to one client does not block the TX to another client
            self._destServerThread = threading.Thread(target=destClient.txJsonDict, args=(rxDict,))
            self._destServerThread.setDaemon(True)
            self._destServerThread.start()



class DestJsonServerHandler (JsonServerHandler):
    """@brief The handler for the server that sends data to all client interested in receiving
              the broadcast JSON data."""

    def handle(self):

        try:
            try:

                self._createLock()

                self._txLock.acquire()
                self.destClientList.append(self)
                self._txLock.release()

                self.serverActive = True

                while self.serverActive:

                    rxDict = JsonServerHandler.RX(self.request)
                    if not rxDict:
                        break

            finally:

                self._txLock.acquire()
                self.destClientList.remove(self)
                self._txLock.release()
                self.serverActive = False
                
        except:

            if self.request:
                self.request.close()

    def _createLock(self):
        """@brief Create a lock object"""
        self._txLock = threading.Lock()

    def txJsonDict(self, jsonDict):
        """@brief Send the jsonDict to this dest client
           @param jsonDict The python dict (JSON data) to be sent to the client."""
        self._txLock.acquire()

        try:
            JsonServerHandler.TX(self.request, jsonDict)
        except:
            #If unable to send then close the connection to the client
            self.request.close()
            self.serverActive = False

        self._txLock.release()

class JsonBroadcaster(object):
    """@brief Responsible for accepting connections from source and destination clients.
              messages from source clients to destination clients."""

    def __init__(self, srcClientPort, destClientPort, serverAddress="0.0.0.0"):
        """@brief Constructor
           @param srcClientPort The TCP port that source clients can connect to.
           @param destClientPort The TCP port that destination clients can connect to.
           @param serverAddress The server adddress to bind to. By default this is 0.0.0.0 so
                  all local and remote clients can connect. To restrict to local clients only,
                  localhost may be used. To only allow connections to a specific interface only
                  the IP address of that interface maybe used."""
        self._srcClientPort=srcClientPort
        self._destClientPort=destClientPort
        self._serverAddress =serverAddress

        self._destClientList = []

    def run(self, blocking=True):
        """@brief Start the src and dest client servers.
           @param blocking If True then this method will block, if not then this method will start
                           both the src and dest client servers and then return."""
        class DestSubHander (DestJsonServerHandler):
            destClientList = self._destClientList

        self.destClientServer = JSONServer((self._serverAddress, self._destClientPort), DestSubHander)
        self._destServerThread = threading.Thread(target=self.destClientServer.serve_forever)
        self._destServerThread.setDaemon(True)
        self._destServerThread.start()

        class SrcSubHander (SrcJsonServerHandler):
            #can be referenced inside handle() using self.uo
            destClientList = self._destClientList

        if blocking:
            self._srcClientServer = JSONServer((self._serverAddress, self._srcClientPort), SrcSubHander)
            self._srcClientServer.serve_forever()
        else:
            self.srcClientServer = JSONServer((self._serverAddress, self._srcClientPort), SrcSubHander)
            self._srcServerThread = threading.Thread(target=self.srcClientServer.serve_forever)
            self._srcServerThread.setDaemon(True)
            self._srcServerThread.start()
