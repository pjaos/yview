from hw_support import HWSupport
from subprocess import call, check_output
import atexit

class GPIOError(Exception):
  pass

class GPIO(object):
    """@brief Responsible for controlling Omega2 GPIO pins.
              Currently it only supports.
              
              - Set a GPIO output pin state (0 or 1)
              - Get the state of a GPIO pin.
             
        @param simulateHardware If True then the hardware will be simulated and
                                therefore do not raise hardware unsupported errors."""
    
    SYSTEM_COMMAND = "/usr/sbin/fast-gpio"

    def __init__(self, simulateHardware):
        self._gpioDriver = None
        if not simulateHardware:
            if not HWSupport.IsOmega2() and not HWSupport.IsRaspberryPI():
                raise GPIOError("%s is not a supported hardware platform (GPIO class)." % (HWSupport.GetHWType()) )

            self._gpioDriver = None
            if HWSupport.IsRaspberryPI():
                from rpi_gpio import RPI_GPIODriver
                self._gpioDriver = RPI_GPIODriver()
                atexit.register(self._cleanUp)

    def _cleanUp(self):
        """@clean up GPIO driver if required."""
        if self._gpioDriver:
            self._gpioDriver.cleanUp()

    def setPin(self, pin, high):
        """@brief Set a GPIO pin high or low.
           @param pin The GPIO pin number.
           @param high If True then the pin is set high else the pin is set low.
           @return True if the pin was set to the required state."""
        if HWSupport.IsOmega2():
            return call("%s set %d %d > /dev/null 2>&1" % (GPIO.SYSTEM_COMMAND, pin, high), shell=True )

        elif HWSupport.IsRaspberryPI():
            self._gpioDriver.setupOutputPin(pin)
            self._gpioDriver.setPin(pin, high)

    def getPin(self, pin):
        """@brief read the state of a pin.
           @return True if the pin if high, False if low."""
        if HWSupport.IsOmega2():
            cmdOutput = check_output([GPIO.SYSTEM_COMMAND, 'read', '%d' % (pin)] )
            if cmdOutput.startswith("> Read GPIO"):
                elems = cmdOutput.split(":")
                if len(elems) == 2:
                    gpioState = elems[1]
                    gpioState=gpioState.strip()
                    gpioState = gpioState.rstrip("\r")
                    gpioState = gpioState.rstrip("\n")
                    if gpioState == '1':
                        return True
                    elif gpioState == '0':
                        return False
                        
            raise  GPIOError("Failed to read GPIO pin %d state." % (pin) )

        elif HWSupport.IsRaspberryPI():
            self._gpioDriver.setupInputPin(pin, True)
            return self._gpioDriver.getPin()

