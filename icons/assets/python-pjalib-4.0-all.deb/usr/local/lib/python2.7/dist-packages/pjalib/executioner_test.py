################################################################################
#
# Copyright (c) 2010, Paul Austen. All rights reserved.
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301  USA
#
################################################################################

from time import time, sleep
import os
import unittest
from   executioner import ExecutionerError,Executioner

class UO:
  lines=[]
  def infoPrint(self, line):
    self.lines.append(line)


class ExecutionerTestFunctions(unittest.TestCase):
  """Test cases for executioner"""
  TEST_CMD="test_cmd.sh"

  def setUp(self):
    self._workingDir=os.getcwd()
    #Create a script file that spews text to stdout at a high rate in order to
    #stress the Executioner code.
    self._scriptFile=os.path.join(self._workingDir, ExecutionerTestFunctions.TEST_CMD)
    fd = open(self._scriptFile,"w")
    fd.write("#!/bin/bash\n")
    fd.write("x=1\n")
    fd.write("while [ $x -le 10000 ]\n")
    fd.write("do\n")
    fd.write("  echo \"Welcome $x times\"\n")
    fd.write("  x=$(( $x + 1 ))\n")
    fd.write("done\n")
    fd.close()
    cmd="chmod 777 %s" % (self._scriptFile)
    os.system(cmd)

    self.stdoutCallbackLines=[]

  def testA_cmdOK(self):
    """Run a system command an check for a 0 (no error) return code"""
    executioner = Executioner(["ls", self._workingDir])
    executioner.run()
    self.assertTrue( executioner.getReturnCode() == 0 )

  def testB_cmdBadA(self):
    """Run a system command an check for a non 0 (error) return code when an unknown cmd is used.
    """
    executioner = Executioner(["acmdthatdoesnotexist"])
    executioner.run()
    self.assertTrue( executioner.getReturnCode() != 0 )

  def testC_cmdBadB(self):
    """Run a system command an check for a non 0 (error) return code when the cmd returns an error.
    """
    executioner = Executioner(["ls", "adirthatdoesnotexist"])
    executioner.run()
    self.assertTrue( executioner.getReturnCode() != 0 )

  def testD_getPID(self):
    """Run a system command an check for a non 0 (error) return code when the cmd returns an error.
    """
    executioner = Executioner(["ls", self._workingDir])
    executioner.run()
    #PID casn be 0 or greater, I've put an arbitary 2E32 limit on it
    self.assertTrue( executioner.getPID() >= 0 and executioner.getPID() <2E32 )

  def testE_checkComplete(self):
    """Check that the is complete state goe from False to True.
    """
    executioner = Executioner(["ls", self._workingDir])
    executioner.start()
    self.assertFalse( executioner.isComplete() )
    to=time()+2
    while True:
      if executioner.isComplete():
        break
      if time() > to:
        self.assertTrue( False, "Timeout waiting for process to complete.")

  def testF_checkException(self):
    """Run a system command an check for a non 0 (error) return code when an unknown cmd is used.
    """
    executioner = Executioner(["acmdthatdoesnotexist"])
    executioner.run()
    with self.assertRaises(OSError):
      raise executioner.getException()

  def testG_RunCmdCheckOutput(self):
    """Run an ls system command, ensure success and the test script is listed."""
    executioner = Executioner(["ls", self._workingDir])
    executioner.run()
    self.assertTrue( executioner.getReturnCode() == 0 )
    lines = executioner.getStdoutLines()
    foundScriptFile=False
    for l in lines:
      if l.startswith(ExecutionerTestFunctions.TEST_CMD):
        foundScriptFile=True
    self.assertTrue( foundScriptFile )
    stderrLines = executioner.getStderrLines()
    self.assertTrue( len(stderrLines) == 0 )

  def testH_ReadLargeProcessOutput(self):
    """Run a long running cmd that returns a lot of output in a separate thread (non blocking)."""
    executioner = Executioner([self._scriptFile])
    executioner.start()
    lineCount=0
    while not executioner.isComplete():
      lines = executioner.getStdoutLines()
      if len(lines) > 0:
        lineCount=lineCount+len(lines)
      sleep(.25)
    #Check we got at least half the lines
    self.assertTrue( lineCount>=5000 )
    #Once the cmd is complete ensure that we get all the lines
    lines = executioner.getStdoutLines()
    lineCount=len(lines)
    #Ensure we got all the lines of text
    self.assertTrue( lineCount ==10000 )

  def testI_ReadLargeProcessOutputBlocking(self):
    """Run a long running cmd that returns a lot of output in the current thread (blocking).
       This test also checks that output can be redirected through a uo object that
       implements the infoPrint() method."""
    uo=UO()
    executioner = Executioner([self._scriptFile], uo)
    executioner.run()
    #Once the cmd is complete ensure that we get all the lines
    lines = executioner.getStdoutLines()
    lineCount=len(lines)
    self.assertTrue( lineCount ==10000 )
    lineCount=len(uo.lines)
    #Check we got at least half the lines
    self.assertTrue( lineCount >= 5000 )

  def testJ_CheckgetStdoutData(self):
    """Run a cmd and check we get the correct amount of data from stdout."""
    executioner = Executioner([self._scriptFile])
    executioner.run()
    #Once the cmd is complete ensure that we get all the data
    stdoutData = executioner.getStdoutData()
    byteCount=len(stdoutData)
    self.assertTrue( byteCount ==188894 )

  def testK_CheckstderrData(self):
    """Run a cmd that generates an error and check the sdterr data."""
    executioner = Executioner(["ls", "adirthatdoesnotexist"])
    executioner.run()
    stderrData = executioner.getStderrData()
    self.assertTrue( stderrData == "ls: cannot access adirthatdoesnotexist: No such file or directory" )

  def stdoutCallBack(self, line):
    self.stdoutCallbackLines.append(line)

  def testL_checkRunCmd(self):
    """Check the legacy runCmd method()."""
    self.stdoutCallbackLines=[]
    executioner = Executioner()
    callBack=self.stdoutCallBack
    rc, lines = executioner.runCmd(self._scriptFile, True, callBack)
    self.assertTrue( rc == 0 )
    self.assertTrue( len(lines) == 10000 )
    lineCount=len(self.stdoutCallbackLines)
    #Check we got at least half the lines via the callback
    self.assertTrue( lineCount >= 5000 )

  def testM_checkRunCmdError(self):
    """"Check the legacy runCmd method() generates an exception correctly
    """
    executioner = Executioner()
    with self.assertRaises(ExecutionerError):
      executioner.runCmd("ls afilethatdoesnotexist", True, None)

  def testN_checkRunCmdErrorReturn(self):
    """"Check the legacy runCmd method() returns an error code correctly
    """
    executioner = Executioner()
    rc, lines = executioner.runCmd("ls afilethatdoesnotexist", False, None)
    self.assertTrue( rc != 0 )

  def testO_runcmd1(self):
    """Run a system command with the full path to the cmd prog"""
    executioner = Executioner(["/bin/ls", self._workingDir])
    executioner.run()
    self.assertTrue( executioner.getReturnCode() == 0 )



if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(ExecutionerTestFunctions)
    unittest.TextTestRunner(verbosity=2).run(suite)
