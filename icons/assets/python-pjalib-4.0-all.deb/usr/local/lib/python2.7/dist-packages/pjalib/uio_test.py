#!/usr/bin/env python
################################################################################
#
# Copyright (c) 2010, Paul Austen. All rights reserved.
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301  USA
#
################################################################################

import os
import getpass
import sys
from   uio import UIO

#-------------------------------------------------------------------------------
#Unit test functions
import unittest
from Queue import Queue
from time import sleep, time

class UIOTestFunctions(unittest.TestCase):
#class UIOTestFunctions(object):

  def setUp(self):
    #stdout is piped through this queue
    self._queue = Queue()
    self.lineToRead = ""

  def write(self, data):
    """Called by UIO.print to capture data that would have been sent to stdout"""
    self._queue.put(data)

  def readline(self):
    """Called when getting input from a uio object for testing.
       self.lineToRead should be preloaded with the user input text."""
    return self.lineToRead

  def flush(self):
    pass

  def testA_createUIO(self):
    """Check that we can instantiate the UIO class"""
    UIO()

  def testB_checkInfo(self):
    """Check that we can display info level messages"""
    uio = UIO()

    org_stdout = sys.stdout
    sys.stdout = self
    uio.info("A MESSAGE")
    sys.stdout = org_stdout

    self.assertTrue( self._queue.qsize() == 2 )
    self.assertTrue( self._queue.get() == "INFO:  A MESSAGE" )
    self.assertTrue( self._queue.get() == "\n" )

  def testC_checkError(self):
    """Check that we can display error level messages"""
    uio = UIO()

    org_stdout = sys.stdout
    sys.stdout = self
    uio.error("A MESSAGE")
    sys.stdout = org_stdout

    self.assertTrue( self._queue.qsize() == 2 )
    self.assertTrue( self._queue.get() == "ERROR: A MESSAGE" )
    self.assertTrue( self._queue.get() == "\n" )

  def testD_checkWarn(self):
    """Check that we can display warning level messages"""
    uio = UIO()

    org_stdout = sys.stdout
    sys.stdout = self
    uio.warn("A MESSAGE")
    sys.stdout = org_stdout

    self.assertTrue( self._queue.qsize() == 2 )
    self.assertTrue( self._queue.get() == "WARN:  A MESSAGE" )
    self.assertTrue( self._queue.get() == "\n" )

  def testE_checkInfoSyslog(self):
    """Check syslog output"""

    #Ensure we have a syslog file on this machine
    syslogFile = "/var/log/messages"
    if not os.path.isfile(syslogFile):
      syslogFile = "/var/log/syslog"
      if not os.path.isfile(syslogFile):
        print "Unable to find syslog file."
        raise

    uio = UIO(syslogEnabled=True)
    fd = open(syslogFile, "r")
    fd.seek(0, 2)
    org_stdout = sys.stdout
    sys.stdout = self
    uio.info("A MESSAGE")
    sys.stdout = org_stdout

    foundTextInSyslog=False
    tot=time()+2
    while True:
      l = fd.readline()
      if l.find("INFO:  A MESSAGE") > 0:
        foundTextInSyslog=True
        break
      if time() >= tot:
        break
      sleep(0.5)
    self.assertTrue( foundTextInSyslog )

  def testF_checkFileLogging(self):
    """Check that output can be directed directly to a log file"""
    logFile = "/tmp/log.txt"
    if os.path.isfile(logFile):
      os.remove(logFile)

    uio = UIO(logFile=logFile)
    org_stdout = sys.stdout
    sys.stdout = self
    uio.log("Line 1")
    uio.info("A MESSAGE 1")
    uio.warn("A MESSAGE 2")
    uio.error("A MESSAGE 3")
    sys.stdout = org_stdout

    fd = open(logFile, 'r')
    lines = fd.readlines()
    fd.close()

    self.assertTrue( lines[0] == 'Line 1\n')
    self.assertTrue( lines[1] == 'INFO:  A MESSAGE 1\n')
    self.assertTrue( lines[2] == 'WARN:  A MESSAGE 2\n')
    self.assertTrue( lines[3] == 'ERROR: A MESSAGE 3\n')

  def _debugPrint(self, uio):
    """Print one message at each debug level"""
    org_stdout = sys.stdout
    sys.stdout = self
    for i in range(UIO.DEBUG_LEVEL_1,UIO.DEBUG_LEVEL_7+1):
      uio.debug("DEBUG LEVEL %d MESSAGE" % (i), i )
    sys.stdout = org_stdout

  def testG_checkDebug(self):
    """Check that we can display all levels of debug messages correctly"""
    for debugLevel in range(UIO.DEBUG_LEVEL_1,UIO.DEBUG_LEVEL_7+1):
      uio = UIO(debugLevel=debugLevel)
      #Send one debug message at each debug level
      self._debugPrint(uio)
      #Check we get the correct number of debug messages.
      self.assertTrue( self._queue.qsize() == (2*debugLevel) )
      #Check we get the correct message text for each debug level.
      for debugLevelToCheckFor in range(1, debugLevel+1):
        self.assertTrue( self._queue.get() == "DEBUG%d: DEBUG LEVEL %d MESSAGE" % (debugLevelToCheckFor,debugLevelToCheckFor) )
        self.assertTrue( self._queue.get() == "\n" )


  def testH_check_debugHex(self):
    """Check that hex output is correct"""
    uio = UIO(debugLevel=UIO.DEBUG_LEVEL_7)
    org_stdout = sys.stdout
    sys.stdout = self
    uio.debugHex("thequickbrownfoxjumpsoverthelazydogsback", UIO.DEBUG_LEVEL_7)
    sys.stdout = org_stdout

    self.assertTrue( self._queue.qsize() == 6 )
    self.assertTrue( self._queue.get() == "DEBUG7: 00000000:  74 68 65 71 75 69 63 6b 62 72 6f 77 6e 66 6f 78  thequickbrownfox" )
    self.assertTrue( self._queue.get() == "\n" )
    self.assertTrue( self._queue.get() == "DEBUG7: 00000010:  6a 75 6d 70 73 6f 76 65 72 74 68 65 6c 61 7a 79  jumpsoverthelazy" )
    self.assertTrue( self._queue.get() == "\n" )
    self.assertTrue( self._queue.get() == "DEBUG7: 00000020:  64 6f 67 73 62 61 63 6b                          dogsback" )
    self.assertTrue( self._queue.get() == "\n" )

  def testI_getUsername(self):
    """Check that the getUsername method allows the user to enter a username"""
    uio = UIO()

    localUsername = getpass.getuser()

    self.lineToRead = "anybody"

    org_stdin  = sys.stdin
    org_stdout = sys.stdout

    sys.stdin  = self
    sys.stdout = self

    username = uio.getUsername()

    sys.stdout = org_stdout
    sys.stdin  = org_stdin

    self.assertTrue( username == "anybody" )

    expectedLine = "INFO:  Press enter to use the your current username (%s)." % (localUsername)
    self.assertTrue( self._queue.get() == expectedLine )
    self.assertTrue( self._queue.get() == "\n" )
    self.assertTrue( self._queue.get() == "INPUT: SSH username: " )



    self.lineToRead = "\n"

    org_stdin  = sys.stdin
    org_stdout = sys.stdout

    sys.stdin  = self
    sys.stdout = self

    username = uio.getUsername(prompt="Username")

    sys.stdout = org_stdout
    sys.stdin  = org_stdin

    self.assertTrue( username == localUsername )

    expectedLine = "INFO:  Press enter to use the your current username (%s)." % (localUsername)
    self.assertTrue( self._queue.get() == expectedLine )
    self.assertTrue( self._queue.get() == "\n" )
    self.assertTrue( self._queue.get() == "INPUT: Username: ")





if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(UIOTestFunctions)
    unittest.TextTestRunner(verbosity=2).run(suite)



#-------------------------------------------------------------------------------
# EXAMPLE CODE
def do1():
  print "do1 DONE"
def do2():
  print "do2 DONE"
def do3():
  print "do3 DONE"

#if __name__ == "__main__":
#  uio = UIO(debugLevel=UIO.DEBUG_LEVEL_7)

#  pw = uio.getInput(prompt="Please a password", noEcho=True)
#  uio.info("Entered: %s" % (pw) )

#  uio.info("An info Message")
#  uio.warn("An warn Message")
#  uio.error("An error Message")
#  uio.debug("An debug Message", 1)
#  uio.debug("An debug Message", 2)
#  uio.debug("An debug Message", 3)
#  uio.debug("An debug Message", 4)
#  uio.debug("An debug Message", 5)
#  uio.debug("An debug Message", 6)
#  uio.debug("An debug Message", 7)

#  menuOptions=[]
#  menuOptions.append( MenuOption( do1, "A description of do1.", None ) )
#  menuOptions.append( MenuOption( do2, "A description of do2.", None ) )
#  menuOptions.append( MenuOption( do3, "A description of do3.", None ) )
#  uio.runMenu("Menu Title", menuOptions, addQuit=True)
