#!/usr/bin/env python

from netif import NetIF

if __name__== '__main__':
    netIF = NetIF()
    ifDict =  netIF.getIFDict()
    print 'ifDict=',ifDict
    
    print netIF.IsAddressInNetwork("192.168.1.1","192.168.1.0/24")
    print netIF.IsAddressInNetwork("192.168.1.1","192.168.2.0/24")
    print netIF.IsAddressInNetwork("10.1.2.3","10.0.0.0/8")
    
    
    ifName =  netIF.getIFName("192.168.0.21")
    print '%s=%s' % (ifName,ifDict[ifName])
    print 'IP=%s' % (netIF.getIFIPAddress(ifName))
    print 'NETMASK=%s' % (netIF.getIFNetmask(ifName))
    
    
