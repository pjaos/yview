#!/usr/bin/env python
################################################################################
#
# Copyright (c) 2018, Paul Austen. All rights reserved.
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301  USA
#
################################################################################

import  os
import  base64
from    Crypto.PublicKey import RSA
from    Crypto.Cipher import PKCS1_OAEP
from    pjalib.cmd_helper import getDict, saveDict

class CredentialError(Exception):
    pass

class Credential(object):
    """@brief Constructor
              A Persistent storage class for a credential that comprises a username and passowrd.
              As a starting position it's not safe to store usernames/passwords in files/persistent storage.
              However...
              The storage of passwords is done using the local ssh RSA key (must have been created previously).
              The ssh private key should be secure (if not then system security has been compromised and all bets are off).
              The private key is used for decryption of the password.

              The persistent storage of a credential (username and password) is not sensible but in some situations
              options are limited.
              E.G database access on system boot with no user interaction.

              You have been warned, use at your own risk.
       """

    PUBLIC_SSH_KEY_FILENAME     = "id_rsa.pub"
    PRIVATE_SSH_KEY_FILENAME    = "id_rsa"
    SSH_FOLDER                  = ".ssh"
    CONFIG_FOLDER               = ".config"
    USERNAME                    = "USERNAME"
    PASSWORD                    = "PASSWORD"
    MAX_PASSWORD_LENGTH         = 200
    MAX_USERNAME_LENGTH         = MAX_PASSWORD_LENGTH
    MIN_PASSWORD_LENGTH         = 8

    DEFAULT_CONFIG = {
        USERNAME: "",
        PASSWORD: ""
    }

    @staticmethod
    def GetHomePath():
        """@brief Get the users home path."""
        homePath = os.path.expanduser("~")

        if not os.path.isdir(homePath):
            raise CredentialError("%s folder not found" % (homePath) )

        return homePath

    @staticmethod
    def GetConfigStoragePath():
        """@brief Get the storage path for the credentials file."""
        homePath = Credential.GetHomePath()

        configPath = os.path.join(homePath , Credential.CONFIG_FOLDER)

        if os.path.isdir(configPath):
            return configPath

        return homePath

    @staticmethod
    def GetStorageFile(reference):
        """@brief Get the storage file for config.
           @param reference The reference for the configuration."""
        storagePath = Credential.GetConfigStoragePath()
        if storagePath.find(Credential.CONFIG_FOLDER) != -1:
            return os.path.join(storagePath, reference)

        #If in home folder we prefix file with . in home folder
        return os.path.join(storagePath, "."+reference)

    @staticmethod
    def GetPublicKeyFile():
        """@brief Get the public key file."""
        homePath = Credential.GetHomePath()
        folder = os.path.join(homePath, Credential.SSH_FOLDER)
        pubKeyFile = os.path.join(folder, Credential.PUBLIC_SSH_KEY_FILENAME)
        if not os.path.isfile(pubKeyFile):
            raise CredentialError("%s file not found" % (pubKeyFile) )
        return pubKeyFile

    @staticmethod
    def GetPrivateKeyFile():
        """@brief Get the private key file."""
        homePath = Credential.GetHomePath()
        folder = os.path.join(homePath, Credential.SSH_FOLDER)
        pubKeyFile = os.path.join(folder, Credential.PRIVATE_SSH_KEY_FILENAME)
        if not os.path.isfile(pubKeyFile):
            raise CredentialError("%s file not found" % (pubKeyFile) )
        return pubKeyFile

    @staticmethod
    def GetPublicKey():
        """@brief Get the public key file.
           @return The RSA public key"""
        pubRSAKeyFile = Credential.GetPrivateKeyFile()
        fd = open(pubRSAKeyFile, 'r')
        fileContents = fd.read()
        fd.close()
        return PKCS1_OAEP.new( RSA.importKey(fileContents) )

    @staticmethod
    def GetPrivateKey():
        """@brief Get the private key file.
           @return The RSA public key"""
        privateRSAKeyFile = Credential.GetPrivateKeyFile()
        fd = open(privateRSAKeyFile, 'r')
        fileContents = fd.read()
        fd.close()
        return PKCS1_OAEP.new( RSA.importKey(fileContents) )

    def __init__(self):
        """@brief Constructor"""
        self.clear()

    def set(self, username, password):
        """@brief Set the details of this credential instance
           @param username
           @password"""
        if len(username) > Credential.MAX_USERNAME_LENGTH:
            raise CredentialError("The username (%s) is to long (max length = %d characters)" % (username, Credential.MAX_USERNAME_LENGTH) )

        if len(password) > Credential.MAX_PASSWORD_LENGTH:
            raise CredentialError("The password has %d characters. This is to long (max length = %d characters)" % (len(password), Credential.MAX_PASSWORD_LENGTH) )

        if len(password) < Credential.MIN_PASSWORD_LENGTH:
            raise CredentialError("The password (%s) is to short (min length = %d characters)" % (password, Credential.MIN_PASSWORD_LENGTH) )

        self._username=username
        self._password=password

    def get(self):
        """@brief Get the username and password of this credential.
           @return (username, password)"""
        return (self._username, self._password)

    def clear(self, saved=False):
        """@brief Clear the username and password so that they are no longer stored in memory."""
        self._username=""
        self._password=""

    def remove(self, reference):
        """@brief Remove persistent storage of the credential. The memory is also cleared of the credential."""
        if self.credentialStored(reference):
            storageFile = Credential.GetStorageFile(reference)
            os.remove(storageFile)
            if self.credentialStored(reference):
                raise CredentialError("Failed to remove %s" % (storageFile) )
        self.clear()

    def store(self, reference):
        """@brief Store the credentials (encrypted using a local RSA ssh public key) in local storage.
           @param reference The reference for the stored credentials."""
        pubKey = Credential.GetPublicKey()

        encUsername = base64.b64encode( pubKey.encrypt(self._username) )
        encPassword = base64.b64encode( pubKey.encrypt(self._password) )

        storageFile = Credential.GetStorageFile(reference)
        credDict = {}
        credDict[Credential.USERNAME]=encUsername
        credDict[Credential.PASSWORD]=encPassword
        saveDict(credDict, storageFile, jsonFmt=True)

    def load(self, reference):
        """@brief Load the credential from persistent storage.
           @param reference The reference for the stored credentials."""
        priKey = Credential.GetPrivateKey()

        storageFile = Credential.GetStorageFile(reference)

        credDict = getDict(storageFile, jsonFmt=True)

        encUsername = base64.b64decode( credDict[Credential.USERNAME] )
        encPassword = base64.b64decode( credDict[Credential.PASSWORD] )

        self._username = priKey.decrypt(encUsername)
        self._password = priKey.decrypt(encPassword)

    def credentialStored(self, reference):
        """@brief Check if credential is stored
           @param reference The reference for the stored credentials."""
        stored = False
        storageFile = Credential.GetStorageFile(reference)
        if os.path.isfile(storageFile):
            stored = True
        return stored
