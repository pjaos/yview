#include <Python.h>
#include <stdint.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/types.h>
#include <linux/spi/spidev.h>

static PyObject *PSPIError;

PyMODINIT_FUNC initnative_pspi(void);
static void set_debug_enabled(int _debug_enabled);

static uint8_t mode;
static uint8_t bits;
static uint32_t speed;
static uint16_t delay=0;

static int debug_enabled=0;

/**
 * Open a SPI device
 **/
static PyObject * native_pspi_spi_open(PyObject *self, PyObject *args)
{
  const char *spi_dev;
  int fd;
  int ret;
  int debug;
  
  if (!PyArg_ParseTuple(args, "sbbihi", &spi_dev, &mode, &bits, &speed, &delay, &debug)) {
    PyErr_SetString(PSPIError, "Failed to parse arguments for spi_open().");
    return NULL;          
  }
  
  set_debug_enabled(debug);
  
  if( debug_enabled ) {
    printf("%s %s(): spi_dev = %s.\n",__FILE__,__FUNCTION__,spi_dev);
    printf("%s %s(): mode    = %d.\n",__FILE__,__FUNCTION__,mode);
    printf("%s %s(): bits    = %d.\n",__FILE__,__FUNCTION__,bits);
    printf("%s %s(): speed   = %d.\n",__FILE__,__FUNCTION__,speed);
    printf("%s %s(): delay   = %d.\n",__FILE__,__FUNCTION__,delay);
  }
  
  //Open an SPI dev
  fd = open(spi_dev, O_RDWR);
  if (fd < 0) {
      PyErr_SetString(PSPIError, "Failed to open SPI dev (check you have access privalages for the device).");
      return NULL;      
  }

  if( debug_enabled ) {
    printf("%s %s(): fd      = %d.\n",__FILE__,__FUNCTION__,fd);
  }
  
  //Set the SPI mode
	ret = ioctl(fd, SPI_IOC_WR_MODE, &mode);
	if (ret == -1) {
    PyErr_SetString(PSPIError, "Failed to set SPI mode.");
    return NULL;  
	}
	
	//Get the SPI mode
	ret = ioctl(fd, SPI_IOC_RD_MODE, &mode);
	if (ret == -1) {
    PyErr_SetString(PSPIError, "Failed to get SPI mode.");
    return NULL;  	  
  }
  
	//Set bits per word
	ret = ioctl(fd, SPI_IOC_WR_BITS_PER_WORD, &bits);
	if (ret == -1) {
    PyErr_SetString(PSPIError, "Failed to set WR bits per word.");
    return NULL;	  
	}

	//Get bits per word
	ret = ioctl(fd, SPI_IOC_RD_BITS_PER_WORD, &bits);
	if (ret == -1) {
    PyErr_SetString(PSPIError, "Failed to RD get bits per word.");
    return NULL;	  
  }

	//Set the speed in Hz
	ret = ioctl(fd, SPI_IOC_WR_MAX_SPEED_HZ, &speed);
	if (ret == -1) {
    PyErr_SetString(PSPIError, "Failed to set the speed in Hz.");
    return NULL;	  	  
	}

	//Get the speed in Hz
	ret = ioctl(fd, SPI_IOC_RD_MAX_SPEED_HZ, &speed);
	if (ret == -1) {
    PyErr_SetString(PSPIError, "Failed to get the speed in Hz.");
    return NULL;	  
	}

  //Return a tuple containing the floowing values that were set
  // 0 = File descriptor
  // 1 = mode
  // 2 = bits
  // 3 = speed
  return Py_BuildValue("ibbi", fd, mode, bits, speed);
}

/*
 * Close an open SPI device.
 * The file descriptor passed into this function must be that returned from 
 * native_pspi_open().
 */
static PyObject * native_pspi_spi_close(PyObject *self, PyObject *args)
{
  int fd;

  if (!PyArg_ParseTuple(args, "i", &fd)) {
    PyErr_SetString(PSPIError, "Failed to parse arguments for spi_close().");
    return NULL;          
  }
  
  if( debug_enabled ) {
    printf("%s %s(): fd      = %d.\n",__FILE__,__FUNCTION__,fd);
  }
  
  if (fd < 0) {
    PyErr_SetString(PSPIError, "Cannot close fd == 0.");
    return NULL;      
  }
  close(fd);
  
  Py_INCREF(Py_None);
  return Py_None;
}

/**
 * Enable/Disable debugging to stdout.
 **/
static void set_debug_enabled(int _debug_enabled) {
  if( _debug_enabled == 0 ) {
    debug_enabled=0;
  }
  else {
    debug_enabled=1; 
  } 
}

/*
 * Enable/Disable debug to stdout.
 * If 0 is passed as an argument then debug is disabled, else debug
 * is enabled.
 */
static PyObject * native_pspi_spi_debug(PyObject *self, PyObject *args)
{
  int debug;

  if (!PyArg_ParseTuple(args, "i", &debug)) {
    PyErr_SetString(PSPIError, "Failed to parse arguments for spi_debug().");
    return NULL;          
  }
  
  set_debug_enabled(debug);
  
  Py_INCREF(Py_None);
  return Py_None;
}

/**
 * Transfer data to/from an SPI device
 **/
static PyObject * native_pspi_spi_transfer(PyObject *self, PyObject *args)
{
  const char *tx_buf;
  const int  tx_buf_len;
  const int  fd;
  int   ret, bi;
  
  if( debug_enabled ) {
    printf("%s %s():\n",__FILE__,__FUNCTION__);
  }
  
  if (!PyArg_ParseTuple(args, "is#:in_bytes", &fd, &tx_buf, &tx_buf_len)) {
    PyErr_SetString(PSPIError, "Failed to parse arguments for spi_transfer().");
    return NULL;          
  }
  
  if( debug_enabled ) {
    printf("%s %s(): fd         = %d.\n",__FILE__,__FUNCTION__,fd);
    printf("%s %s(): tx_buf_len = %d.\n",__FILE__,__FUNCTION__,tx_buf_len);
    printf("%s %s(): bits       = %d.\n",__FILE__,__FUNCTION__,bits);
    printf("%s %s(): speed      = %d.\n",__FILE__,__FUNCTION__,speed);
    printf("%s %s(): delay      = %d.\n",__FILE__,__FUNCTION__,delay);
    for( bi=0 ; bi < tx_buf_len ; bi++ ) {
    printf("%s %s(): byte %04d  = %02x.\n",__FILE__,__FUNCTION__,bi, tx_buf[bi]);
    }
  }

  uint8_t rx_buf[tx_buf_len];
  memset(rx_buf, 0, tx_buf_len);

 	struct spi_ioc_transfer tr = {
		.tx_buf = (unsigned long)tx_buf,
		.rx_buf = (unsigned long)rx_buf,
		.len = tx_buf_len,
		.delay_usecs = delay,
		.speed_hz = speed,
		.bits_per_word = bits,
	};
	ret = ioctl(fd, SPI_IOC_MESSAGE(1), &tr);
	if (ret < 1) {
    PyErr_SetString(PSPIError, "Failed to send SPI data.");
    return NULL;	  
	}
	
  return Py_BuildValue("s#i", rx_buf, tx_buf_len);
}

static PyMethodDef PSPIMethods[] = {
    {"spi_open",      native_pspi_spi_open,      METH_VARARGS, "Open a SPI device and return a fd."},
    {"spi_close",     native_pspi_spi_close,     METH_VARARGS, "Close an open SPI device."},
    {"spi_transfer",  native_pspi_spi_transfer,  METH_VARARGS, "Transfer data to/from and SPI device."},
    {"spi_debug",     native_pspi_spi_debug,     METH_VARARGS, "Enable/Disable spi debugging to stdout."},
    {NULL, NULL, 0, NULL}        /* Sentinel */
};

PyMODINIT_FUNC initnative_pspi(void)
{
    PyObject *m;
    
    m = Py_InitModule("native_pspi", PSPIMethods);
    if (m == NULL)
        return;
      
    PSPIError = PyErr_NewException("native_pspi.error", NULL, NULL);
    Py_INCREF(PSPIError);
    PyModule_AddObject(m, "error", PSPIError);
}

