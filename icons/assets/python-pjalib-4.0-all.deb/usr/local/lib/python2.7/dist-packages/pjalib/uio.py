#!/usr/bin/env python
################################################################################
#
# Copyright (c) 2010, Paul Austen. All rights reserved.
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301  USA
#
################################################################################

import thread
import os
import getpass
import sys
from   types import StringType
import traceback
import unicodedata

reload(sys)
sys.setdefaultencoding('utf8')

from syslogger import syslog, PRIORITY
LOG_ERR     = PRIORITY.ERROR
LOG_WARNING = PRIORITY.WARNING
LOG_INFO    = PRIORITY.INFO
LOG_DEBUG   = PRIORITY.DEBUG

#-------------------------------------------------------------------------------
# uio lib

#Connect uio messages to syslog messages

class UIOError(Exception):
  pass

class UIO:
  """Responsible for providing user input output"""

  DEBUG_OFF=0       #Debug off
  DEBUG_LEVEL_1=1   #Lowest level of debug showing minimal output
  DEBUG_LEVEL_2=2
  DEBUG_LEVEL_3=3
  DEBUG_LEVEL_4=4
  DEBUG_LEVEL_5=5
  DEBUG_LEVEL_6=6
  DEBUG_LEVEL_7=7   #Highest level of debug showing maximal output

  DISABLE_SYSLOG_FILE = ".uio_syslog_off"

  StdoutLock = thread.allocate_lock()
  SyslogLock = thread.allocate_lock()

  @staticmethod
  def GetAppName():
      """@brief Get the name of the executing python program.
         @return the python filename without the .py suffix"""
      pythonFile = sys.argv[0] #The python file excuted at program startup
      pythonFile = os.path.basename(pythonFile)
      if pythonFile.startswith("./"):
          pythonFile=pythonFile[2:]
      if pythonFile.endswith(".py"):
          pythonFile=pythonFile[:-3]
      return pythonFile

  @staticmethod
  def AddMenuOption(menuOptionList, description, method, args):
      """@brief Add a menu option to the the menuOptionList
         @param menuOptionList The list to add MenuOption instances to.
         @param description The menu option text
         @param method The method to be called when selected
         @param args The arguments to be passed to the above method"""
      menuOption = MenuOption(method, description, args)
      menuOptionList.append(menuOption)

  def __init__(self,  infoEnabled=True,
                      warnEnabled=True,
                      errorEnabled=True,
                      syslogEnabled=False,
                      quiet=False,
                      debugLevel=DEBUG_OFF,
                      logFile=None):

    self._infoEnabled   = infoEnabled
    self.warnEnabled    = warnEnabled
    self.errorEnabled   = errorEnabled
    self.syslogEnabled  = syslogEnabled
    self.syslogHost     = "localhost"
    self.quiet          = quiet
    self.appName        = sys.argv[0]    #Only used when syslog messages are written
    self.debugLevel     = debugLevel
    self.logFile        = logFile
    self._disableSyslogFile = self._getDisableSyslogFile()

    self.disableSyslog(not syslogEnabled)

  def _getDisableSyslogFile(self):
      """@return The abs path of the disabled syslog file."""
      return os.path.join( os.path.expanduser("~"), "."+UIO.GetAppName()+UIO.DISABLE_SYSLOG_FILE )

  def setDisableSyslogFile(self, disableSyslogFile):
    """Set a file that is checked each time a syslog message is written.
      @param disableSyslogFile If the file exists then syslog output is disabled.
    """
    self._disableSyslogFile=disableSyslogFile

  def enableSyslog(self, enabled, host="localhost"):
      """@brief Enable/disable syslog.
                Alternative to disableSyslog which uses negative logic which can
                be confusing. However disableSyslog() needs to be preserved for
                legacy code reasons.
         @param enabled If True then syslog is enabled."""
      self.disableSyslog(not enabled, host=host)

  def disableSyslog(self, disabled, host="localhost"):
    """ Disable/enable syslog output for all instances of this program running
        on the same computer.
        @param disabled If True then syslog output is disabled as long as
                        setDisableSyslogFile() has been called previously
                        with a valid filename.
        @param host The syslog server address."""

    if self._disableSyslogFile == None:
      raise UIOError("Bug: UIO.setDisableSyslogFile() must be called before calling UIO.disableSyslog()")

    self.syslogHost = host
    if disabled:
      if not os.path.isfile(self._disableSyslogFile):
        #Create the disable syslog file. The existance of this file will
        #cause syslog output to be disabled the next time an attempt to generate
        #a syslog message is made.
        fd = open(self._disableSyslogFile, 'w')
        fd.close()
    #If we wish to set syslog as not disabled.
    else:
      #Remove the _disableSyslogFile if present.
      if os.path.isfile(self._disableSyslogFile):
        os.remove(self._disableSyslogFile)
      #Enable Syslog
      self.syslogEnabled=True
      self.info("Syslog output is now enabled.")

  def getCurrentUsername(self):
    """Get the current users username or return unknown_user if not able to read it.
       This is required as getpass.getUser() does not always work on windows platforms."""
    username="unknown_user"
    try:
      username=getpass.getuser()
    except:
      pass
    return username

  def update_syslog(self, pri, msg):
    """Send a message to syslog is syslog is enabled
       Syslog messages will have the following components
       0 = time/date stamp
       1 = hostname
       2 = main python file name
       3 = PID
       4 = username under which the program is being executed
       5 = The syslog message

       The syslog messages will be prefixed withj the application name
    """
    #If the disable syslog file has been set
    if self._disableSyslogFile != None:
      #If the file exists then disable syslog
      if os.path.isfile(self._disableSyslogFile):
        self.syslogEnabled=False
      else:
        self.syslogEnabled=True

    if self.syslogEnabled:
      #If the disable syslog file exists then quit
      if os.path.isfile(self._disableSyslogFile):
        return

      aMsg=msg
      #Ensure we have no zero characters in the message. syslog will
      #throw an error if it finds any
      if "\x00" in aMsg:
        aMsg=aMsg.replace("\x00", "")

      #Ensure we have ASCII character <= 127 or the syslog will blow up
      aMsg=unicodedata.normalize('NFKD', unicode(aMsg)).encode('ascii', 'ignore')

      UIO.SyslogLock.acquire()
      try:
        #send aMsg to syslog with the current process ID and username
        syslog(pri, "%d %s: %s" % (os.getpid(), str(self.getCurrentUsername()), str(aMsg) ), host=self.syslogHost )
      #Ignore if we have no syslog module
      except NameError:
        pass
      if UIO.SyslogLock.locked():
        UIO.SyslogLock.release()

  def log(self, text):
    """Save to a log file if one is defined"""
    if self.logFile != None:
      if os.path.isfile(self.logFile):
        fd = open(self.logFile, 'a')
      else:
        fd = open(self.logFile, 'w')
      fd.write("%s\n" % (text) )
      #Could do more efficiently, e.g close after a timeout
      fd.close()

  def info(self, text):
    """show an information message"""
    if self._infoEnabled:
      msg = "INFO:  %s" % (text)
      self.log(msg)
      if not self.quiet:
        self._print(msg)
      self.update_syslog(LOG_INFO, msg)

  def error(self, text):
    """show an information message"""
    if self.warnEnabled:
      msg="ERROR: %s" % (text)
      self.log(msg)
      if not self.quiet:
        self._print(msg)
      self.update_syslog(LOG_ERR, msg)

  def warn(self, text):
    """show an information message"""
    if self.errorEnabled:
      msg="WARN:  %s" % (text)
      self.log(msg)
      if not self.quiet:
        self._print(msg)
      self.update_syslog(LOG_WARNING, msg)

  def debug(self, text, debugLevel):
    """show an information message"""
    #Check if we should show this message
    if self.debugLevel >= debugLevel:
      msg="DEBUG%d: %s" % (debugLevel, text)
      self.log(msg)
      if not self.quiet:
        self._print(msg)
      self.update_syslog(LOG_DEBUG, msg)

  def _print(self, msg):
    UIO.StdoutLock.acquire()
    print msg
    if UIO.StdoutLock.locked():
      UIO.StdoutLock.release()

  def setDebugLevel(self, debugLevel):
    """Set the debug level"""
    self.debugLevel=debugLevel

  def debugHex(self, theBytes, debugLevel):
    """Print the bytes in theBytes in ASIC and hex
    """
    #Check if we should show this message
    if self.debugLevel >= debugLevel:
      printable = ' 1!2 at 3#4$5%6^7&8*9(0)aAbBcCdDeEfFgGhHiIjJkKlLmMnNoOpPqQrRsStTuUvVwWxXyYzZ\`~-_=+\\|[{]};:\'",<.>/?'
      lines=[]
      hexOutput=""
      asciiOutput=""
      bytesPerLine=16
      lineIndex=0
      address=0
      for b in theBytes:
        #Convert string to num if reqiuired (if passed a string object)
        if type(b) == StringType:
          b=ord(b)

        hexOutput = "%s %02x" % (hexOutput,b)

        if chr(b) in printable:
          asciiOutput = "%s%c" % (asciiOutput,chr(b))
        else:
          asciiOutput = "%s." % (asciiOutput)
        lineIndex=lineIndex+1

        #If it's time to output the line
        if lineIndex >= bytesPerLine:
          lines.append("%08x: %s  %s" % (address, hexOutput, asciiOutput) )
          hexOutput=""
          asciiOutput=""
          lineIndex=0
          address = address+bytesPerLine

      #Print anything left
      hexOutputLen = len(hexOutput)
      if len(hexOutput) > 0:
        spaceCharCount = (16*3)-hexOutputLen
        if spaceCharCount > 0:
          while spaceCharCount > 0:
            hexOutput = "%s " % (hexOutput)
            spaceCharCount=spaceCharCount-1
        lines.append("%08x: %s  %s" % (address, hexOutput, asciiOutput) )

      for line in lines:
        self.debug(line, debugLevel)

  def __displayMenu(self, menuTitle, menuOptionList):
    """Display a menu"""
    self._print('')
    self.info(menuTitle)
    userOption=1
    for menuOption in menuOptionList:
      self.info("%2d : %s" % (userOption, menuOption.description) )
      userOption=userOption+1

  def getUsername(self, prompt="SSH username"):
    """Enter a username on the command line"""
    _username = getpass.getuser()
    self.info("Press enter to use the your current username (%s)." % (_username) )
    username = self.getInput(prompt)
    if len(username) == 0:
      username = _username
    return username

  def getPassword(self):
    """Get a password on the command line"""
    return self.getInput("SSH password", noEcho=True)

  def getInput(self, prompt="", noEcho=False, stripEOL=True):
    """Get input from user"""
    if prompt == None or len(prompt) ==0:
      p = "INPUT: "
    else:
      p = "INPUT: %s: " % (prompt)
    if noEcho:
      ip=getpass.getpass(p, sys.stdout)
      if stripEOL:
        ip=ip.rstrip('\n')
        ip=ip.rstrip('\r')
      return ip
    ip = raw_input(p)
    if stripEOL:
      ip=ip.rstrip('\n')
      ip=ip.rstrip('\r')
    return ip

  def getDecimalInteger(self, prompt, minValue=None, maxValue=None):
    """Allow the user to enter a decimal number"""
    while True:
      ip = self.getInput(prompt)
      #If nothin is entered by the user return None
      if len(ip) == 0:
        return None
      try:
        v = int(ip)
        if minValue != None and v < minValue:
          self.error("%d is not valid (min = %d)." % (v, minValue) )
          continue

        if maxValue != None and v > maxValue:
          self.error("%d is not valid (max = %d)." % (v, maxValue) )
          continue

        return v

      except ValueError:
        self.error("%s is not a valid decimal integer." % (ip) )

  def errorException(self):
    """Show an exception.
       If debugging is not off then a tracback is displayed.
       If debugging is off then the exception error value is displayed.
       This should only be called when an exception has occured."""
    if self.debugLevel != UIO.DEBUG_OFF:
      lines = traceback.format_exc().split('\n')
      for l in lines:
        self.error(l)
    else:
      lines = traceback.format_exc().split('\n')
      for l in lines:
        self.update_syslog(LOG_ERR, l)
      self.error(sys.exc_info()[1])

  def __quit(self):
    """Quit the menu"""
    sys.exit(0)

  def runMenu(self, menuTitle, menuOptionList, addQuit, menuInitMethod=None):
    """Prompt user with menu"""
    if addQuit:
      menuOptionList.append( MenuOption( self.__quit, "Quit.", None ) )
    validOptions="1-%d" % (len(menuOptionList))
    while True:
      #A method may be called every time the menu is dispalyed if required.
      if menuInitMethod != None:
        menuInitMethod()

      self.__displayMenu(menuTitle, menuOptionList)
      selectedOption = self.getInput()
      try:
        so = int(selectedOption)
      except ValueError:
        self.info("Please enter %s" % (validOptions) )
        continue
      if so >= 1 and so <= len(menuOptionList):
        method=menuOptionList[so-1].method
        args=menuOptionList[so-1].args
        try:
          if args != None:
            method(*args)
          else:
            method()
        except KeyboardInterrupt:
          pass
        except SystemExit:
          return
        except:
          self.errorException()

  def getYes(self, question):
      """@brief Get a yes/no response from the user.
         If user responds quit or q then the program exists.
         @return True if user respons yes or y, False if the user responds no or n."""
      while True:
          response = self.getInput("%s [y]es, [n]o or [q]uit: " % (question) )
          response = response.lower()
          if response in ['y', 'yes']:
              return True
          elif response in ['n', 'no']:
              return False
          elif response in ['q', 'quit']:
              return sys.exit(0)

  def appendDelFile(self, theFile, forceOverwrite=False):
        """@brief Check a file and ask user if the wish to over write or append to it.
                  If the file does not exist then create an empty file.
                  If the file does exist and the user elects to append to it then no action is taken
                  If the file does exist and the user elects to overwtite it then an empty file is created.
           @param theFile
           @param forceOverwrite If True then the file is always overwritten.
           @return 0 = no action
                   1 = Deleted file
                   2 = Appending to file"""
        returnCode = 0
        if os.path.isfile(theFile):
            if forceOverwrite:
                fd = open(theFile,'w')
                fd.close()
            else:
                askUser=True
                while askUser:
                    self.info('%s file already exists.' % (theFile) )
                    response = self.getInput(prompt='Do you wish to (o)verwrite, or (a)ppend to it')
                    response=response.lower()
                    if response == 'o':
                        while True:
                            self.info('%s file already exists.' % (theFile) )
                            response = self.getInput(prompt='Are you sure you wish to overwrite this file [y][n]')
                            response=response.lower()
                            if response == 'y':
                                fd = open(theFile,'w')
                                fd.close()
                                askUser=False
                                returnCode = 1
                                break
                            elif response == 'n':
                                break
                    elif response == 'a':
                        askUser=False
                        returnCode = 2

        else:
            fd = open(theFile,'w')
            fd.close()

        return returnCode

class MenuOption:
  """Responsible for defining a single menu option."""
  def __init__(self, method, description, args=None):
    self.method=method
    self.description=description
    self.args=args

#-------------------------------------------------------------------------------
# UIO EXAMPLE CODE
def do1():
  print "do1 DONE"
def do2():
  print "do2 DONE"
def do3():
  print "do3 DONE"

if __name__ == "__main__":
  uio = UIO(debugLevel=UIO.DEBUG_LEVEL_7)

  pw = uio.getInput(prompt="Please a password", noEcho=True)
  uio.info("Entered: %s" % (pw) )

  uio.info("An info Message")
  uio.warn("An warn Message")
  uio.error("An error Message")
  uio.debug("An debug Message", 1)
  uio.debug("An debug Message", 2)
  uio.debug("An debug Message", 3)
  uio.debug("An debug Message", 4)
  uio.debug("An debug Message", 5)
  uio.debug("An debug Message", 6)
  uio.debug("An debug Message", 7)

  menuOptions=[]
  menuOptions.append( MenuOption( do1, "A description of do1.", None ) )
  menuOptions.append( MenuOption( do2, "A description of do2.", None ) )
  menuOptions.append( MenuOption( do3, "A description of do3.", None ) )
  uio.runMenu("Menu Title", menuOptions, addQuit=True)
