#!/bin/sh
#This test must be run as root and will fail if /dev/spidev0.1 does not exist.
sudo PYTHONPATH=build/lib.linux-x86_64-2.7/ ./test_pspi.py
