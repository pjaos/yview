#!/usr/bin/env python
################################################################################
# 
# Copyright (c) 2010, Paul Austen. All rights reserved.
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301  USA
#
################################################################################

class LinInterpError(Exception):
  pass

class LinTerp(object):
  """Responsible for Linear interpolation."""
  def __init__(self, valDict):
    """@brief constructor
       @param valDict The dict that hols the values
              keys = X values
              values = Y values."""
    self._valDict=valDict

  def getResult(self, xVal, allowOutOfRange=False):
    """Perform a linear interpolation to determine the yVAl associated with the xVal.
       @param xVal  The value on the x axis for which the coresponding y axis value is required.
                    The xVal provided must be within the bounds (inclusive) of thex values stored
                    in the keys of self._valDict.
                    
       @return      The yVal that coresponds to the xVal provided."""
    xList        = self._valDict.keys()
    xList.sort()
    minValue = min(xList)
    if xVal < minValue:
        if allowOutOfRange:
          xVal = minValue
        else:
          raise LinInterpError("%f is less than the min value we have (%f)" % (float(xVal), min(xList)) )

    maxValue = max(xList)
    if xVal > maxValue:
        if allowOutOfRange:
          xVal=maxValue
        else:
          raise LinInterpError("%f is greater than the the max value we have (%f)." % (float(xVal), max(xList)) )

    #If we have the exact value then no linear interpolation is nessasary
    if xVal in xList:
      #Return the yVal from the dict
      return self._valDict[xVal]
    
    lowXValue=None
    highXValue=None
    for x in xList:
      if x < xVal:
        lowXValue=x
      if highXValue == None and lowXValue != None and x > lowXValue:
        highXValue=x
    
    #Not overly bothered about speed here, clarity is more important.
    lowYValue    = float(self._valDict[lowXValue])
    highYValue   = float(self._valDict[highXValue])
    n1=(highXValue-lowXValue)
    n2=(highYValue-lowYValue)
    return lowYValue+((xVal-lowXValue)*n2/n1)
   
if __name__=='__main__':  
  """Some test code to the lin interp"""
  valDict={}
  valDict[10]=100
  valDict[20]=200
  valDict[30]=300
  valDict[40]=400
  valDict[50]=600

  lineInterp = LinTerp(valDict)
  print 'PJA: RESULT=',lineInterp.getResult(10)
  print 'PJA: RESULT=',lineInterp.getResult(15)
  print 'PJA: RESULT=',lineInterp.getResult(20)
  print 'PJA: RESULT=',lineInterp.getResult(25)
  print 'PJA: RESULT=',lineInterp.getResult(30)
  print 'PJA: RESULT=',lineInterp.getResult(35)
  print 'PJA: RESULT=',lineInterp.getResult(40)
  print 'PJA: RESULT=',lineInterp.getResult(45)
  print 'PJA: RESULT=',lineInterp.getResult(50)
  
  try:
    lineInterp.getResult(5)
    print 'TEST FAILED'
  except LinInterpError:
    pass
  
  try:
    lineInterp.getResult(55)
    print 'TEST FAILED'
  except LinInterpError:
    pass

