#!/usr/bin/env python

import  unittest

from    conduit import Conduit

class TestQueueITC(unittest.TestCase):
    
    def setUp(self):
        self._conduit = Conduit()
            
    def test_putA(self):
        data = "A-B DATA"
        self._conduit.putA(data)

    def test_putB(self):
        data = "B-A DATA"
        self._conduit.putA(data)

    def test_getA(self):
        txData = "B-A DATA"
        self._conduit.putB(txData)
        rxData=self._conduit.getA()
        assert(txData == rxData)
        
    def test_getB(self):
        txData = "A-B DATA"
        self._conduit.putA(txData)
        rxData=self._conduit.getB()
        assert(txData == rxData)

    def test_getA_100(self):
        txData = "B-A DATA"
        for _ in range(0,100):
            self._conduit.putB(txData)

        rxCount = 0
        while self._conduit.aReadAvailable():
            rxData=self._conduit.getA()
            assert(txData == rxData)
            rxCount=rxCount+1         
        
        assert(rxCount == 100)
        
    def test_getB_100(self):
        txData = "A-B DATA"
        for _ in range(0,100):
            self._conduit.putA(txData)

        rxCount = 0
        while self._conduit.bReadAvailable():
            rxData=self._conduit.getB()
            assert(txData == rxData)
            rxCount=rxCount+1         
        
        assert(rxCount == 100)
        
if __name__== '__main__':
    unittest.main()
    
    
    