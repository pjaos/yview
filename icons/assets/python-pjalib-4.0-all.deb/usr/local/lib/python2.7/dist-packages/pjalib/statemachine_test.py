#!/usr/bin/env python

from   statemachine import StateMachine
from   time import sleep
from   min_uio import UserIO

#This file provides some examples of how the fsm module should be used.

class StateControllerExample1(object):
    """@brief Example of a state machine implementation.
              This state machine implements two states fullBucket and
              emptyBucket.
              This state machine will run indefinitely until the user
              stops it (E.G presses CTRL C.)"""

    def __init__(self):
        """@brief Constructor."""
        #The initialStateMethod must be defined and must hold a reference to
        #the method to be called when the state machine starts.
        self.initialStateMethod = self.fullBucket_Enter

    def fullBucket_Enter(self):
        """@brief fullBucket state entry method.
                  The method name must end _Enter.
                  All state entry methods are optional.
                  No return object is required."""
        sleep(1)

    def fullBucket_Check(self):
        """@brief fullBucket state check method.
                  This method is called when in the state and should only exit
                  on transition to another state.
                  The method name must end _Check.
                  The method should return the next method in the state machine
                  to be executed, or None to exit the state machine."""
        #Do something to empty the bucket...
        sleep(1)
        return self.emptyBucket_Enter

    def fullBucket_Exit(self):
        """@brief fullBucket state exit method.
                  The method name must end _Exit.
                  All state exit methods are optional.
                  No return object is required."""
        sleep(1)

    def emptyBucket_Enter(self):
        """@brief emptyBucket state entry method.
                  The method name must end _Enter.
                  All state entry methods are optional.
                  No return object is required."""
        sleep(1)

    def emptyBucket_Check(self):
        """@brief emptyBucket state check method.
                  This method is called when in the state and should only exit
                  on transition to another state.
                  The method name must end _Check.
                  The method should return the next method in the state machine
                  to be executed, or None to exit the state machine."""
        #Do something to fill the bucket...
        sleep(1)
        return self.fullBucket_Enter

    def emptyBucket_Exit(self):
        """@brief emptyBucket state exit method.
                  The method name must end _Exit.
                  All state exit methods are optional.
                  No return object is required."""
        sleep(1)

class StateControllerExample2(object):
    """@brief Example of a state machine implementation.
              This is a minimal state machine as no state entry of exit methods
              are defined.
              This state machine will stop after the sitting_CheckState() method
              has been called five times."""

    def __init__(self):
        """@brief Constructor."""
        #The initialStateMethod must be defined and must hold a reference to
        #the method to be called when the state machine starts.
        self.initialStateMethod = self.sitting_Check

        self.sittingCount = 0

    def sitting_Check(self):
        """@brief sitting state check method.
                  This method is called when in the state and should only exit
                  on transition to another state.
                  The method name must end _Check.
                  The method should return the next method in the state machine
                  to be executed, or None to exit the state machine."""
        #Do something to move to the standing state
        sleep(1)

        self.sittingCount = self.sittingCount + 1
        #Exit the state machine if we have reach 5 sitting counts
        if self.sittingCount == 5:
            return None

        return self.standing_Check

    def standing_Check(self):
        """@brief standing state check method.
                  This method is called when in the state and should only exit
                  on transition to another state.
                  The method name must end _Check.
                  The method should return the next method in the state machine
                  to be executed, or None to exit the state machine."""
        #Do somthing to move to the sitting state
        sleep(1)
        return self.sitting_Check

    def _dummyMethod(self):
        """@brief This methis is not required. It was added to the test in order
                  to check that non state machine methods could be added without
                  breaking the tate machine SW."""
        pass

if __name__== "__main__":

    uo = UserIO()

    #stateController = StateControllerExample1()

    stateController = StateControllerExample2()

    stateMachine = StateMachine(stateController, uo)
    stateMachine.logStates()
    stateMachine.run()
