#!/usr/bin/env python

from    optparse import OptionParser
import  sys
from    time import sleep
from    uio import UIO
#The GPIO module is installed on the default Raspberry PI raspbian installation.
try:
  import  RPi.GPIO as GPIO
except ImportError:
  from dummy_gpio import GPIO
      
class ULN2003HLYError(Exception):
  pass
        
class ULN2003HLY(object):
  """Responsible for the control of a 28BYJ-48 stepper motor using a ULN2003 HLY driver board."""
  def __init__(self, pressKeyStep=False, uio=None):
    self._pressKeyStep=pressKeyStep
    self._uio=uio
    
    self._running = False
    self._step=0
    self._initilised=False
    
  def _initGPIO(self):
    """Initialize the interface to the GPIO pins."""
    # to use Raspberry Pi board pin numbers
    GPIO.setmode(GPIO.BOARD)
    GPIO.setwarnings(False)
    
    # Setup LSB
    GPIO.setup(21, GPIO.OUT)
    # Setup LSB + 1
    GPIO.setup(23, GPIO.OUT)
    # Setup LSB + 2
    GPIO.setup(24, GPIO.OUT)
    # Setup LSB + 3
    GPIO.setup(26, GPIO.OUT)
    #Set flag to indicate we have initialised the GPIO pins.
    self._initilised=True
    self._setStep(self._step)

  def _setPinState(self, b0, b1 ,b2, b3):
    """Set the output poins states
       @param b0 Bit 0 to the ULN2003 HLY driver board
       @param b1 Bit 0 to the ULN2003 HLY driver board
       @param b2 Bit 0 to the ULN2003 HLY driver board
       @param b3 Bit 0 to the ULN2003 HLY driver board
    """
    GPIO.output(21, b0)
    GPIO.output(23, b1)
    GPIO.output(24, b2)
    GPIO.output(26, b3)
    
  def _setStep(self, step):
    """Set the state of the output pins.
       @param step The step count (0-7)
    """
    if step == 0:
      self._setPinState(0,0,0,1) 
    elif step == 1:
      self._setPinState(0,0,1,1) 
    elif step == 2:
      self._setPinState(0,0,1,0) 
    elif step == 3:
      self._setPinState(0,1,1,0) 
    elif step == 4:
      self._setPinState(0,1,0,0) 
    elif step == 5:
      self._setPinState(1,1,0,0) 
    elif step == 6:
      self._setPinState(1,0,0,0) 
    elif step == 7:
      self._setPinState(1,0,0,1) 
    else:
      self._setPinState(0,0,0,0)   
    
  def move(self):
    """Move the motor one step in the current direction.
    """
    if not self._initilised:
      self._initGPIO()
    else:
      self._setStep(self._step)
      
    if self._clockwise:
      if self._step == 7:
        self._step=0
      else:
        self._step=self._step+1

    else:
      if self._step == 0:
        self._step=7
      else:
        self._step=self._step-1
        
    sleep(0.0008)
    
  def powerOff(self):
    """Turn off power to motor coils."""
    #Turn off power to motor coils by setting an invalid step
    self._setStep(8)
      
  def setClockwise(self, clockwise):
    """Set the direction that the motor will move."""
    self._clockwise=clockwise
    
  def clockWise(self):
    """Move the motor clockwise one step repeatedly"""
    self._clockwise=True
    self._running = True
    try:
      while self._running:
        stepSet=self._step
        self.move()
        if self._pressKeyStep:
          if self._uio == None:
            raise ULN2003HLYError("A UIO object os required for user input.")
          self._uio.getInput("Step = %d. Press any key for the next step." % (stepSet))
    finally:
      self._cleanUP()
  
  def antiClockWise(self):
    """Move the motor clockwise one step repeatedly"""
    self._clockwise=False
    self._running = True
    try:
      while self._running:
        stepSet=self._step
        self.move()
        if self._pressKeyStep:
          if self._uio == None:
            raise ULN2003HLYError("A UIO object os required for user input.")
          self._uio.getInput("Step = %d. Press any key for the next step." % (stepSet))
    finally:
      self._cleanUP()

  def _cleanUP(self):
    """Called when shutting down the motor control to release control of the GPIO pins."""
    GPIO.cleanup()    
  
if __name__=='__main__':    
    uio = UIO()
    opts=OptionParser(usage='This program allows the user to control a 28BYJ-48 stepper motor using a ULN2003 HLY driver board from a raspberry PI.')
    opts.add_option("-c",       help="Move the clockwise.", default=False, action="store_true")
    opts.add_option("-a",       help="Move the anti clockwise.", default=False, action="store_true")
    opts.add_option("-e",       help="Press enter between increments.", default=False, action="store_true")
    opts.add_option("--debug",  help="Enable debug.", action="store_true")

    try:
        (options, args) = opts.parse_args()
        if options.debug:
            debug=True
            
        uln2003hly = ULN2003HLY(pressKeyStep=options.e, uio=uio)
        
        if options.c:
          uln2003hly.clockWise()
      
        if options.a:
          uln2003hly.antiClockWise()
      
    #If the program throws a system exit exception
    except SystemExit:
      pass
    #Don't print error information if CTRL C pressed
    except KeyboardInterrupt:
      pass
    except:
     if options.debug:
       raise
       
     else:
       uio.error(sys.exc_value)



