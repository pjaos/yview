# Raspberry PI spi module

# Building
Ensure that the python-dev is installed on the Raspberry PI.

- Run ```make``` command to build the native_pspi.so module. 
  
# Testing
- Connect the MOSI and MOSO pins together on the raspberry pi interface connector.
- Run the run_raspberry_pi_tests.sh script to test pspi is working.
