#!/usr/bin/python
################################################################################
#
# Copyright (c) 2010, Paul Austen. All rights reserved.
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301  USA
#
################################################################################

from uio import UIO, MenuOption

import Tkinter
from threading import Thread
from time import sleep
import sys
import Queue
from   cmd_helper import getHomePath
import os
import string

#Click X in window corner

class UIO_TKInter():
  """A GUI that emulates the normal command line interface.
     It presents a large text area to display text with a input
     field at the bottom. The input field stores history accessable using the
     up/down arrow keys."""
  MAX_INPUT_HISTORY=100

  #The following is alist of commnds that can be passed in the queue object
  SHOW              = "SHOW:"
  SET_PASSWORD_MODE = "SET_PASWORD_MODE:"

  """Extend the UIO to a GUI
     All methods starting _, should be called from the TkInter thread
  """
  def __init__(self, lines=25, columns=80, title=""):
    self._title              = title
    self._lines              = lines
    self._columns            = columns
    self._inputHistoryIndex  = 0
    self._inputHistory       = []
    self.running             = False
    #This queue is used for passing messages to the GUI in order
    #to make it thread safe
    self._queue_to_gui       = Queue.Queue()
    self._queue_from_gui     = Queue.Queue()

    self.root = Tkinter.Tk()
    self.root.geometry("+0+0")
    self.root.protocol("WM_DELETE_WINDOW", self._windowCloseHandler)
    self.T = Tkinter.Text(self.root, height=self._lines, width=self._columns)
    #Explicitly set focus, so user can select and copy text
    self.T.bind("<1>", self._set_focus)
    self.s = Tkinter.Scrollbar(self.root)
    self.E = Tkinter.Entry(self.root)

    self.E.pack(side=Tkinter.BOTTOM,padx=3,pady=3, fill=Tkinter.X)
    self.s.pack(side=Tkinter.RIGHT, fill=Tkinter.Y)
    self.T.pack(side=Tkinter.LEFT, fill=Tkinter.Y)

    self.s.config(command=self.T.yview)
    self.T.config(yscrollcommand=self.s.set)
    self.E.focus_set()
    #We accept input when the user has the entry or text widgets in focus
    self.T.bind('<Key>', lambda event: self._keyHandler(event))
    self.T.bind('<Return>', lambda event: self._returnHandler(event))
    self.E.bind('<Key>', lambda event: self._keyHandler(event))
    self.E.bind('<Return>', lambda event: self._returnHandler(event))
    self.T.configure(state="disabled")
    self._setWindowTitle(self._title)
    self.loadWinSizePos()
    #Add spaces so that text is presented at the bottom of the textarea
    #so as to be near the input field
    for _ in range(self._lines-1):
      #Add to the queue so that when ready these can be displayed
      self.printMessage("\n")
    self.root.after(100, self._updateView)

  def _updateView(self):
    """Called periodically to update the view from the queue"""
    try:
      #Stay in this loop until the queue is empty
      while True:
        rxMsg = self._queue_to_gui.get(False)
        if rxMsg != None and len(rxMsg) > 0:
          if rxMsg.startswith(UIO_TKInter.SHOW):
            text = rxMsg[len(UIO_TKInter.SHOW):]
            self._printMessage(text)
          if rxMsg.startswith(UIO_TKInter.SET_PASSWORD_MODE):
            state = rxMsg[len(UIO_TKInter.SET_PASSWORD_MODE):]
            if state == "True":
              self._setPasswordMode(True)
            elif state == "False":
              self._setPasswordMode(False)
            else:
              self._printMessage("Invalid password mode message: "+rxMsg+"\n")

    except Queue.Empty:
      pass
    self.root.after(100, self._updateView)

  def showWindow(self):
    """This method displays the window. It also blocks until the window is closed"""
    self.running=True
    Tkinter.mainloop()

  def _set_focus(self, _):
    '''Explicitly set focus, so user can select and copy text'''
    self.T.focus_set()

  def getConfigFile(self):
    """Get the absolute name of the config file."""
    return os.path.join( getHomePath(), '.'+self._title)

  def saveWinSizePos(self):
    """Save the size and position of the current root window to
       a text file in the users home dir. The file will have the
       of the window title prefixed by a period character."""
    cfgFile = self.getConfigFile()
    fd = open(cfgFile ,'w')
    fd.write(""+self.root.geometry())
    fd.close()

  def setWindSizePos(self, geometryStr):
    """Set the window size and position using the geometry string.
       width, height, xoffset, yoffset."""
    self.root.geometry(geometryStr)

  def loadWinSizePos(self):
    """Load the window size and position from a config file, if it exists."""
    cfgFile = self.getConfigFile()
    try:
      fd = open(cfgFile, 'r')
      lines = fd.readlines()
      fd.close()
      if len(lines) > 0:
        self.setWindSizePos(lines[0])
    except IOError:
      pass

  def _windowCloseHandler(self):
    """Called when the window is closed"""
    #Save the win size and pos to a file
    #so that when re opened it retains it's properties.
    self.saveWinSizePos()
    self.root.destroy()
    self.running = False
    #Send something back to the src process to get it to process the text and
    #check if the window has closed
    self._queue_from_gui.put("")

  def _setWindowTitle(self, title):
    """Set the title of the window"""
    self.root.title(title)

  def _deleteInput(self):
    """Delete all text from the inpuit field"""
    text = self.E.get()
    self.E.delete(0,len(text))

  def _setPasswordMode(self, passwordMode):
    """Set to password mode. In this mode the text that the user inputs is
       hidden"""
    if passwordMode:
      self._deleteInput()
      self.E.configure(show="*")
    else:
      self.E.configure(show="")

  def _addInputHistory(self, text):
    """Add the text to the input history"""
    self._inputHistory.append(text)
    self._inputHistoryIndex=self._inputHistoryIndex+1
    if len(self._inputHistory) > UIO_TKInter.MAX_INPUT_HISTORY:
      del self._inputHistory[0]
      self._inputHistoryIndex=self._inputHistoryIndex-1

  def _showNewInput(self):
    """Called when the up/down arrow keys are pressed to view history input"""
    self._deleteInput()
    self.E.insert(0, self._inputHistory[self._inputHistoryIndex])

  def _keyHandler(self, event):
    """Called whenever a key is pressed to handle up down arrow key presses"""
    #If the Text field was in focus when the user pressed a key
    if event.widget == self.T:
      #If backspace is pressed then remove the last char from the Entry field
      if event.keysym == 'BackSpace':
        text=self.E.get()
        if len(text) > 0:
          self.E.delete(len(text)-1,len(text))
      else:
        if event.char in string.printable:
          #Insert the key at the end of the Entry field
          self.E.insert(len(self.E.get()), event.char)

    #If in password mode then we don't show history
    if self.E.cget("show") == "*":
      return

    #Up arrow key press
    if event.keysym == 'Up':
      if self._inputHistoryIndex > 0:
        self._inputHistoryIndex=self._inputHistoryIndex-1
        self._showNewInput()
    #Down arrow key press
    elif event.keysym == 'Down':
      if self._inputHistoryIndex < len(self._inputHistory)-1:
        self._inputHistoryIndex=self._inputHistoryIndex+1
        self._showNewInput()
      elif self._inputHistoryIndex < len(self._inputHistory):
        self._deleteInput()

  def _returnHandler(self, _):
    text = self.E.get()

    #If we have some text are are not in password mode
    if len(text) > 0 and self.E.cget("show") != "*":
      self._addInputHistory(text)
    self.E.delete(0,len(text))
    #Push the user text down the queue back to the process reading user input
    self._queue_from_gui.put(text)
    #PJA
    #The user has just entered some text add a line to the text area so that
    #the next text appears on its own line
    self._printMessage('\n')

  def _printMessage(self, msg):
    """Print the mesage on the textarea, """
    self.T.configure(state="normal")
    self.T.insert(Tkinter.END, msg)
    self.T.see(Tkinter.END)
    self. T.configure(state="disabled")

  def printMessage(self, msg):
    """Print the message on the textarea. This method is thread safe."""
    self._queue_to_gui.put(UIO_TKInter.SHOW+msg)

  def setPasswordMode(self, passwordMode):
    """Set to password mode if passwordMode == True."""
    state="False"
    if passwordMode:
      state="True"
    self._queue_to_gui.put(UIO_TKInter.SET_PASSWORD_MODE+state)

  def getInput(self):
    """Get input from the user, This method is blocking and thread safe."""
    while self._queue_from_gui.empty():
      sleep(0.1)
    return self._queue_from_gui.get()

class GUI_UIO(UIO):
  """The UIO class allows user input and output on the command line using text.
     GUI_UIO provides a GUI with similar features and allows command line
     programs to have a GUI interface simply by replacing the UIO object
     with a GUI_UIO object.

     Note that this requires TKInter to be installed on the target machine."""
  def __init__(self, lines=25, columns=80, title="", infoEnabled=True, warnEnabled=True, errorEnabled=True, syslogEnabled=False, quiet=False, debugLevel=UIO.DEBUG_OFF, logFile=None):
    UIO.__init__(self,
                 infoEnabled,
                 warnEnabled,
                 errorEnabled,
                 syslogEnabled,
                 quiet,
                 debugLevel,
                 logFile)
    #Start a thread to display the GUI and process events etc
    self.uioTKInter=None
    t = Thread(target=self.buildGUI, args=(lines, columns, title))
    t.setDaemon(True)
    t.start()
    #Wait for the GUI to be displayed
    while self.uioTKInter == None or not self.uioTKInter.running:
      sleep(0.1)

  def buildGUI(self, lines, columns, title):
    self.uioTKInter = UIO_TKInter(lines=lines, columns=columns, title=title)
    self.uioTKInter.showWindow()

  #-----------------------------------------------------------------------------
  # These are the methods we override from UIO
  #
  def _print(self, msg):
    """All user output goes through here"""
    self._doPrint(msg)

  def _doPrint(self, msg, addEOL=True):
    """All user output goes through here"""
    #Shutdown if the GUI is no longer running
    if not self.uioTKInter.running:
      sys.exit(0)

    UIO.StdoutLock.acquire()
    if addEOL:
      self.uioTKInter.printMessage(msg+'\n')
    else:
      self.uioTKInter.printMessage(msg)

    if UIO.StdoutLock.locked():
      UIO.StdoutLock.release()

  def getInput(self, prompt="", noEcho=False, stripEOL=True):
    """Get input from user"""
    #Shutdown if the GUI is no longer running
    if not self.uioTKInter.running:
      sys.exit(0)

    if prompt == None or len(prompt) ==0:
      p = "INPUT: "
    else:
      p = "INPUT: %s: " % (prompt)
    self._doPrint(p, addEOL=False)

    self.uioTKInter.setPasswordMode(noEcho)

    #Wait for user to enter text
    #This will block until the user presses enter in the GUI
    text = self.uioTKInter.getInput()

    #Shutdown if the GUI is no longer running
    if not self.uioTKInter.running:
      sys.exit(0)

    if stripEOL:
      text=text.rstrip('\n')
      text=text.rstrip('\r')

    return text

if __name__ == "__main__":
  uio = GUI_UIO(title="A TITLE", lines=40, columns=132, debugLevel=UIO.DEBUG_LEVEL_7)

  pw = uio.getInput(prompt="Please a password", noEcho=True)
  uio.info("Entered: %s" % (pw) )

  ip = uio.getInput(prompt="Please enter input 1", noEcho=False)
  uio.info("Entered: %s" % (ip) )

  ip = uio.getInput(prompt="Please enter input 2", noEcho=False)
  uio.info("Entered: %s" % (ip) )

  ip = uio.getInput(prompt="Please enter input 3", noEcho=False)
  uio.info("Entered: %s" % (ip) )

  uio.info("An info Message")
  uio.warn("An warn Message")
  uio.error("An error Message")
  uio.debug("A debug Message", 1)
  uio.debug("A debug Message", 2)
  uio.debug("A debug Message", 3)
  uio.debug("A debug Message", 4)
  uio.debug("A debug Message", 5)
  uio.debug("A debug Message", 6)
  uio.debug("A debug Message", 7)

  def do1():
    uio.info("do1 DONE")
  def do2():
    uio.info("do2 DONE")
  def do3():
    uio.info("do3 DONE")

  menuOptions=[]
  menuOptions.append( MenuOption( do1, "A description of do1.", None ) )
  menuOptions.append( MenuOption( do2, "A description of do2.", None ) )
  menuOptions.append( MenuOption( do3, "A description of do3.", None ) )
  uio.runMenu("Menu Title", menuOptions, addQuit=True)
