from distutils.core import setup, Extension

module1 = Extension('native_pspi',
                    sources = ['native_pspi.c'])

setup (name = 'native_pspi',
       version = '1.0',
       description = 'C module to provide Python with access to the Linux SPI interface.',
       ext_modules = [module1])
