#!/usr/bin/env python

from cmd_helper import saveDict, getDict

if __name__== '__main__':
        
    testDict1 = {}
    testDict1[1]="ABCDE"
    testDict1["STAND"]="YES"
    testDict1["HEIGHT"]=12
    
    dictFile="/tmp/testDict1.txt"
    saveDict(testDict1, dictFile)
    testDict2 = getDict(dictFile)
    
    print testDict1
    print testDict2
    
    dictFile="/tmp/testDict1.txt"
    saveDict(testDict1, dictFile,jsonFmt=True)
    testDict2 = getDict(dictFile,jsonFmt=True)
    
    print testDict1
    print testDict2