#!/usr/bin/env python

################################################################################
# 
# Copyright (c) 2013, Paul Austen. All rights reserved.
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301  USA
#
################################################################################

#The GPIO module is installed on the default Raspberry PI raspbian installation.
try:
  import  RPi.GPIO as GPIO
except ImportError:
  from dummy_gpio import GPIO

class RpiDCPowerInterfaceError(Exception):
  pass

class RpiDCPowerInterface(object):
    """Responsible for turning the power on/off on each of the 8 
       available power output pins on the dc_pwr_ctrl board 
       connecte to the local Raspberry PI."""
    
    OUTPUT_1 = 1
    OUTPUT_2 = 2
    OUTPUT_3 = 3
    OUTPUT_4 = 4
    OUTPUT_5 = 5
    OUTPUT_6 = 6
    OUTPUT_7 = 7
    OUTPUT_8 = 8
    
    ON       = True
    OFF      = False
    
    #Define GPIO pin functions
    _OE_PIN    = 12
    IP_CLK_PIN = 13
    DATA_PIN   = 7
    OP_CLK_PIN = 11
    
    OUTPUT_LIST   = [ OUTPUT_1,\
                      OUTPUT_2,\
                      OUTPUT_3,\
                      OUTPUT_4,\
                      OUTPUT_5,\
                      OUTPUT_6,\
                      OUTPUT_7,\
                      OUTPUT_8]
    
    def __init__(self):
        self._outputEnable   = False
        self._outputByteMask=0
        self._init()
    
    def _init(self):
        """Init the interface to it's initial sstate."""
        GPIO.setmode(GPIO.BOARD)
        
        GPIO.setup(RpiDCPowerInterface._OE_PIN,    GPIO.OUT)
        GPIO.setup(RpiDCPowerInterface.IP_CLK_PIN, GPIO.OUT)
        GPIO.setup(RpiDCPowerInterface.DATA_PIN,   GPIO.OUT)
        GPIO.setup(RpiDCPowerInterface.OP_CLK_PIN, GPIO.OUT)
        #Set the clock pin to low state, ready for the first bit to be 
        #clocked out
        GPIO.output(RpiDCPowerInterface.IP_CLK_PIN, GPIO.LOW)
        GPIO.output(RpiDCPowerInterface.OP_CLK_PIN, GPIO.LOW)
        
    def _setBit(self, bit):
        """Called to clock a single bit into the shift register.
           @param bit   The bit to be set/reset starting at 0"""
        #If the bit is high
        if self._outputByteMask&(1<<bit):
            GPIO.output(RpiDCPowerInterface.DATA_PIN, GPIO.HIGH)
            #print "PJA: set bit %d HIGH" % (bit)
        else:
            GPIO.output(RpiDCPowerInterface.DATA_PIN, GPIO.LOW)
            #print "PJA: set bit %d LOW" % (bit)
        
        #Clock on +ve edge of clock to the input shift reg
        GPIO.output(RpiDCPowerInterface.IP_CLK_PIN, GPIO.HIGH)
        
        #And return the clock pin to low state ready for the next bit
        GPIO.output(RpiDCPowerInterface.IP_CLK_PIN, GPIO.LOW)
                            
    def _setOutput(self, output, state):
        """Set output on/of.
           @param bit   The bit to be set/reset starting at 0
           @param state The state of the above bit True/False = 1/0"""
        #Outputs start at 1, bits start at 0
        bit=output-1
        
        #Set the state of the bit in the value we send to the hardware.
        if state:
            self._outputByteMask=self._outputByteMask|1<<bit
        else:
            self._outputByteMask=self._outputByteMask&~(1<<bit)
            
        for bit in reversed( range(0, len(RpiDCPowerInterface.OUTPUT_LIST) ) ):
            self._setBit(bit)
            
        #Clock on +ve edge of clock to load the shift reg to the output 
        #register.
        GPIO.output(RpiDCPowerInterface.OP_CLK_PIN, GPIO.HIGH)
        #And return the clock pin to low state ready for the next byte
        GPIO.output(RpiDCPowerInterface.OP_CLK_PIN, GPIO.LOW)
    
        #If outputs have not been enabled then enable them now
        if not self._outputEnable:
            GPIO.output(RpiDCPowerInterface._OE_PIN, GPIO.LOW)
            self._outputEnable=True
            
    def setPower(self, output, state):
        """Set the power output state.
         @param output An int value (1-8) for each available power output.
         @param stare  The Output state. True = ON."""

        #Allow conversion from strings
        if not isinstance(output, int):
            output=int(output)
            
        if not isinstance(state, bool):
            state=bool(state)

        if output not in RpiDCPowerInterface.OUTPUT_LIST:
            raise RpiDCPowerInterfaceError("%s is not a valid power output." % (str(output)) )
            
        self._setOutput(output, state)

    def getPower(self, output):
        """Return the state of a power output.
         @param output An int value (1-8) for each available power output.
         @return True if the power output is on."""
        if self._outputByteMask&1<<output-1:
            return True
        return False
        
        
