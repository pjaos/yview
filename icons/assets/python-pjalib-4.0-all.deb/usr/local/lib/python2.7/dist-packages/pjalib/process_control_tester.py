#!/usr/bin/env python

from optparse import OptionParser
from process_control import ProcessDescriptor, ProcessManager
from min_uio import UserIO

if __name__== '__main__':
    uio = UserIO()

    opts=OptionParser(usage='Test the process_control module and provide an example of how it may be used.')

    (options, args) = opts.parse_args()

    sleep = "/bin/sleep"

    processManager = ProcessManager(restartType=ProcessManager.RESTART_TYPE_ALL, uio=uio)
    processManager.add( ProcessDescriptor("%s 4" % (sleep)) )
    processManager.add( ProcessDescriptor("%s 3" % (sleep)) )
    processManager.add( ProcessDescriptor("%s 6" % (sleep)) )
    processManager.manage()

