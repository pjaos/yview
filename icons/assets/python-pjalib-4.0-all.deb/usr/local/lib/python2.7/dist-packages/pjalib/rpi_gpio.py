import RPi.GPIO as GPIO

class RPI_GPIODriver(object):
    """@brief Allow CPIO control using the Raspberry PI.
              USe the GPIO pin number rather than the interface pin number."""

    def __init__(self):
            #We'll use the GPIO pin number rather than the raspberry PI interface pin number
            GPIO.setmode(GPIO.BCM)

    def setupOutputPin(self, pin):
        """@brief Setup a GPIO pin
           @param pin The pin number
           @param pullUpDown GPIO.PUD_DOWN or GPIO.PUD_UP (default)"""
        GPIO.setup(pin, GPIO.OUT)

    def setupInputPin(self, pin, pullUP):
        """@brief Setup a GPIO pin
           @param pin The pin number
           @param pullUP If True apply pullup to pin. IF False pull down"""
        if pullUP:
            pull = GPIO.PUD_UP
        else:
            pull = GPIO.PUD_DOWN
        GPIO.setup(pin, GPIO.IN, pull_up_down=pull)

    def setPin(self, pin, state):
        """@brief Set the state of a pin.
           @param pin The pin number.
           @param state If True state the pin high. If False set it low."""
        GPIO.output(pin, state)

    def getPin(self, pin):
        """@brief Get the state of a pin.
           @param pin The pin number.
           @return True if high, False if low."""
        return GPIO.input(pin)

    def addPinCallback(self, pin, fallingEdge, method, deBounceTime):
        """@brief Add a method to be called in the event of a change in state of the pin
           @param pin The pin number
           @param fallingEdge IF True then trigger on falling edge. If False rising edge.
           @param method The method to be called when event occurs.
           @param deBounceTime The de bounce time in milli seconds."""
        if fallingEdge:
            event = GPIO.FALLING
        else:
            event = GPIO.RISING
        GPIO.add_event_detect(pin, event, callback=method, bouncetime=deBounceTime)

    def waitForEdge(self, pin, rising):
        """@brief Wait for a pin state to change.
           @param pin The pin number
           @param rising If True block until a rising edge is detected.
                         If False block until a falling edge is detected."""
        if rising:
            edge=GPIO.RISING
        else:
            edge=GPIO.FALLING
        GPIO.wait_for_edge(pin, edge)

    def removePinCallbak(self, pin):
        """@brief remove a callback for a pin
           @param pin The pin number."""
        GPIO.remove_event_detect(pin)

    def cleanUp(self):
        """@brief release the GPIO pins."""
        GPIO.cleanup()
