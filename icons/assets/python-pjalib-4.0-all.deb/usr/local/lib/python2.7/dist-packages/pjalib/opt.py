#!/usr/bin/env python
################################################################################
#
# Copyright (c) 2010, Paul Austen. All rights reserved.
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301  USA
#
################################################################################

from optparse import OptionParser, TitledHelpFormatter, OptParseError

class DefaulTitledHelpFormatter(TitledHelpFormatter):
  """Responsible for placing the program description in the usage
      text
  """
  def __init__(self, descripLines):
    TitledHelpFormatter.__init__(self)
    self._descripLines=descripLines
    #We call this so that an OptParseError is thrown in the constructior if the
    #description lines are to long
    self.getDescription()

  def format_usage(self, usage):
    return "%s%s\n%s  %s\n" % (self.format_heading(("Description")), self.getDescription(), self.format_heading(("Usage")), usage)

  def getDescription(self, maxLineLength=80):
    """Return the program description as a string"""
    if self._descripLines == None or len(self._descripLines) == 0:
      raise OptParseError("Please supply a description for the program.")
    descripLines=[]
    for line in self._descripLines:
      if len(line) > maxLineLength:
        raise OptParseError("The description line '%s' is to long (max %d characters)." % (line, maxLineLength) )
      descripLines.append("%s\n" % (line) )
    return "".join(descripLines)

class DefaultOptionParser(OptionParser):
  """This provides a standard interface for all out command line programs.
     It adds
      - The ability to provide a user output object to optparse callbacks.
      - Forces the inclusion of a program description (list of lines of text)
        that describes the use of the program.
  """

  def __init__(self, uio, descripLines):
    OptionParser.__init__(self, formatter=DefaulTitledHelpFormatter(descripLines))
    #Not really the place to store this but the callback then have access to
    #the user output object
    self.uio=uio

#--------------------------------------------------------------------------------
# Example usage of DefaultOptionParser
#

DOIT_ARG="--doit"

def doit(option, opt_str, value, parser):
  """An example of a command lines execution"""
  #In this case --store is a callback and so we want to ensure that all command
  #line arguments have been processed before this is called. If we don't do this then
  #we could end up with a default arg value for a command line argument that is
  #specified after the callback argument on the command line.
  parser.ensureLastArg(DOIT_ARG)
  print parser.values.boolean
  print parser.values.int
  print parser.values.float
  print parser.values.logFile
  print parser.values.point
  parser.uio.info("present some text to the user using the UserOutput object.")

class UIO():
  """A stub for the user input/output lib object"""
  def info(self, line):
    print 'INFO:  %s' % (line)

if __name__ == "__main__":
  global options
  uio = UIO()

  parser = DefaultOptionParser(uio, ["This program does something and this text", "lets the user know what."])
  parser.add_option("--logf", default="/tmp/b.txt", dest="logFile", help="Followed by the log file argument.")
  parser.add_option("-b", action="store_true", dest="boolean", help="Define a boolean value.", default=False)
  parser.add_option("-i", type="int", default=1, dest="int", help="Any int value.")
  parser.add_option("-f", type="float", default=1.1, dest="float", help="Any float value.")
  parser.add_option("-p", type="float", nargs=3, dest="point", help="Three float values.")
  parser.add_option(DOIT_ARG, action="callback", callback=doit, help="Execute the doit() method.")
  parser.parse_args()
