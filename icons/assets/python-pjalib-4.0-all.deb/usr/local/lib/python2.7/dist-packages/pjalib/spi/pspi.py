#!/usr/bin/env python

from    native_pspi import spi_open, spi_close, spi_transfer, spi_debug
from    array import array

class PSPIError(Exception):
    """SPI related errors"""
    pass

class PSPI(object):
  """Responsible for providing a python API for SPI access.
     This loads the pspy.so native C module. Therefore this file must be present
     in the python path."""

  SPI_CPHA       = 0x01                    # clock phase
  SPI_CPOL       = 0x02                    # clock polarity
  SPI_MODE_0     = (0|0)                   # (original MicroWire)
  SPI_MODE_1     = (0|SPI_CPHA)
  SPI_MODE_2     = (SPI_CPOL|0)
  SPI_MODE_3     = (SPI_CPOL|SPI_CPHA)
  SPI_CS_HIGH    = 0x04                    # chipselect active high
  SPI_LSB_FIRST  = 0x08                    # per-word bits-on-wire
  SPI_3WIRE      = 0x10                    # SI/SO signals shared
  SPI_LOOP       = 0x20                    # loopback mode
  SPI_NO_CS      = 0x40                    # 1 dev/bus, no chipselect
  SPI_READY      = 0x80                    # slave pulls low to pause

  def __init__(self, spiDev, mode, bits, speed, delay, debug):
    self._spiDev=spiDev
    self._mode  = mode
    self._bits  = bits
    self._speed = speed   #In Hz
    self._delay = delay
    self._debug = debug

  def open(self):
    """Open an SPI device and return the file descriptor"""
    return spi_open(self._spiDev, self._mode, self._bits, self._speed, self._delay, self._debug)

  def close(self, fd):
    """Close an open SPI device"""
    spi_close(fd)

  def setDebug(self, debug):
    """Enable/Disable debugging
       SPI debug data appears on stdout."""
    self._debug = debug
    spi_debug(self._debug)

  def transfer(self, fd, intList):
    """Transfer to/from an open SPI device.
       Note that the chip select for the device must be asserted separtatly.
       @param fd"""
    #Convert the list of int values to a string
    data = array('B', intList).tostring()
    data, dataLen = spi_transfer(fd, data)
    #Convert string back to a list of int values.
    #Not sure if there is a more efficient way to do this.
    retIntList=[]
    for b in data:
      retIntList.append(ord(b))
    return retIntList
