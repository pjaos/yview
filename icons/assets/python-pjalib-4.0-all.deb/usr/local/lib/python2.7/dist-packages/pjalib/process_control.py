from subprocess import  Popen
from time import sleep
import os
import signal
import sys
import socket

class FreeMemLinux(object):
    """
    Non-cross platform way to get free memory on Linux. Note that this code
    uses the `with ... as`, which is conditionally Python 2.5 compatible!
    If for some reason you still have Python 2.5 on your system add in the
head of your code, before all imports:
    from __future__ import with_statement
    """

    def __init__(self, unit='MB'):

        with open('/proc/meminfo', 'r') as mem:
            lines = mem.readlines()

        self.unit = unit
        self._convert = self._factor()
        
        self.tot = int(lines[0].split()[1])*self._convert
        self.free = int(lines[1].split()[1])*self._convert
        self.buff = int(lines[2].split()[1])*self._convert
        self.cached = int(lines[3].split()[1])*self._convert
        self.shared = int(lines[20].split()[1])*self._convert
        self.swapt = int(lines[14].split()[1])*self._convert
        self.swapf = int(lines[15].split()[1])*self._convert
        self.swapu = self.swapt - self.swapf


    def _factor(self):
        """determine the convertion factor"""
        if self.unit == 'kB':
            return 1.0
        if self.unit == 'k':
            return 1024.0
        if self.unit == 'MB':
            return 1/1024.0
        if self.unit == 'GB':
            return 1/1024.0/1024.0
        if self.unit == '%':
            return 1.0/self.tot
        
    def __repr__(self):
        """@return A string representation of this object."""
        elems = []
        elems.append("TOTAL: %.2f" % (self.tot) )
        elems.append("FREE: %.2f" % (self.free) )
        elems.append("BUFF: %.2f" % (self.buff) )
        elems.append("CACHE: %.2f" % (self.cached) )
        elems.append("SHARED: %.2f" % (self.shared) )
        elems.append("SWAPT: %.2f" % (self.swapt) )
        elems.append("SWAPF: %.2f" % (self.swapf) )
        elems.append("SWAPU: %.2f" % (self.swapu) )
        return ",".join(elems)
        
class ProcessDescriptor(object):
    """@brief Responsible for providing the functionality to run a process."""

    def __init__(self, cmdLine):
        self._cmdLine = cmdLine
        self._proc    = None

    def fork(self):
        """@brief Start a process with the command line provided."""
        self._proc = Popen( self._cmdLine, shell = True, stdout = None, stderr = None)

    def isRunning(self):
        """@brief Determine if the process is running.
           @return True if the process is running."""
        if self._proc and self._proc.poll() == None:
            return True
        return False

    def kill(self):
        """@brief Kill the process if running."""
        if self.isRunning():
            self._proc.kill()

    def getPid(self):
        """@return The PID of the process of 0 if not running."""
        if self.isRunning():
            return self._proc.pid
        return 0

    def __repr__(self):
        """@return A string representation of the object."""
        return self._cmdLine

    def getPythonFile(self):
        """@breif Get the python file being executed.
           @return The name of the file or None if a python file is not in the command line."""
        elems = self._cmdLine.split()
        for elem in elems:
            if elem.endswith(".py"):
                return elem
        return None

class ProcessManager(object):
    """@brief Responsible for creating and managing a list of ProcessDescriptor instances."""

    RESTART_TYPE_SINGLE                 = 1
    RESTART_TYPE_ALL                    = 2

    def __init__(self, applicationName=None, restartType=RESTART_TYPE_SINGLE, uio=None, minFreeMemMB=10.0):
        """@brief Constructor
           @param applicationName The name of the application being executed. Only required to ensure a single instance of the application runs.
           @param restartType Determines if just the process that died
                  is restarted or if all processes are restarted.
                  RESTART_TYPE_SINGLE (default)
                  RESTART_TYPE_ALL
            @param uio A min_uio instance.
            @param minFreeMemMB The min memory left that will caused the process manager to shutdown (when a process starts or stops."""
        self._applicationName       = applicationName
        self._processDescriptorList = []
        self._uio                   = uio
        self._restartType           = restartType
        self._minFreeMemMB          = minFreeMemMB

        self._appLockSocket         = None
        
    def _info(self, line):
        """@brief Display an info level message."""
        if self._uio:

            self._uio.info(line)

    def add(self, processDescriptor):
        """@brief Add to the list of processes to manage.
                  This method can only be called before the manage() method is called.#
           @param processDescriptor A ProcessDescriptor instance."""
        self._processDescriptorList.append( processDescriptor )

    def _stopProcesses(self):
        """@brief Stop all the processes that are running."""
        for processDescriptor in self._processDescriptorList:
            if processDescriptor.isRunning():
                processDescriptor.kill()
                self._info("Process killed: %s (PID=%d)" % (processDescriptor, processDescriptor.getPid()))

    def _startProcesses(self):
        """@brief Start all the processes.
                  If any process is already running then it is not restarted."""
        for processDescriptor in self._processDescriptorList:
            if not processDescriptor.isRunning():
                processDescriptor.fork()
                self._info("Process started: %s (PID=%d)" % (processDescriptor, processDescriptor.getPid()))

    def stopAllPythonProcesses(self):
        """@brief Shutdown all Python processes that are managed by a process manager with the same ProcessDescriptors."""

        pythonFileList = []
        for processDescriptor in self._processDescriptorList:
            pythonFileList.append( processDescriptor.getPythonFile() )

        for pid in os.listdir('/proc'):
            if pid.isdigit():
                pidCmdLine = "/proc/%s/cmdline" % (pid)
                fd = open(pidCmdLine, 'r')
                cmdLine = fd.readline()
                for pythonFile in pythonFileList:
                    if cmdLine.find(pythonFile) != -1:
                        intPid = int(pid)
                        #Make sure we are not attempting to kill ourself
                        if intPid != os.getpid():
                            os.kill(intPid, signal.SIGKILL)
                            self._uio.info("%s stopped." % (pythonFile) )

    def _recordMemInfo(self):
        """@brief Record (stdout and or syslog the memory used."""
        freeMemLinux = FreeMemLinux()
        
        self._info("RAM (MB): %s" % ( str(FreeMemLinux()) ) )
        if freeMemLinux.free < self._minFreeMemMB:
            self._uio.error("!!! minimum free system memory (%.2f MB) limit reached. Exit now !!!" % (self._minFreeMemMB) )
            sys.exit(0)
                   
    def _aquireAppLock(self):
        """@brief Aquire the application lock. This ensures only one instance of the application is running."""
        
        if self._applicationName:
            
            try:
                
                self._appLockSocket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                # Create an abstract socket, by prefixing it with null. 
                self._appLockSocket.bind( '\0%s' % (self._applicationName) )
                
            except socket.error:
                raise Exception("Another instance of %s is running." % (self._applicationName) )
                    
    def _releaseAppLock(self):
        """@brief remove the lockfile if it exists."""
        if self._appLockSocket:
            self._appLockSocket.close()

             
    def manage(self, polTime, maxRestartCount=float('inf')):
        """@brief Manage all the processes.
                  If any process dies then it is restarted.
           @param polTime The process poll time in seconds.
           @param maxRestartCount The max number of times to restart a process."""
        
        try:
            self._aquireAppLock()
            
            self._recordMemInfo()
            self._startProcesses()
            sleep(polTime)
            restartCount = 0
            while restartCount < maxRestartCount:
                for processDescriptor in self._processDescriptorList:
    
                    if not processDescriptor.isRunning():
                        self._recordMemInfo()
                        self._info("Process stopped: %s (PID=%d)" % (processDescriptor, processDescriptor.getPid() ) )
    
                        if self._restartType == ProcessManager.RESTART_TYPE_SINGLE:
                            processDescriptor.fork()
                            self._info("Process started: %s (PID=%d)" % (processDescriptor, processDescriptor.getPid()))
                            self._recordMemInfo()
    
                        elif self._restartType == ProcessManager.RESTART_TYPE_ALL:
                            self._stopProcesses()
                            self._recordMemInfo()
                            sleep(polTime)
                            self._startProcesses()
                            self._recordMemInfo()
    
                        restartCount = restartCount+1
                        
    
                sleep(polTime)
            
        finally:
            self._releaseAppLock()
