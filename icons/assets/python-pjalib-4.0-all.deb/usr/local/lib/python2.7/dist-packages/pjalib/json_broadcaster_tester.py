#!/usr/bin/env python

from json_broadcaster import JsonBroadcaster
from optparse import OptionParser
from json_networking import JSONClient
from min_uio import UserIO

# This files shows how the JSON broadcaster may be used.
# JSON messages from all source clients are sent to all dest clients.
#
# The command line allows you to
# - create a server instance.
# - create an example src client. This generates json traffic as fast as the PC will allow in order to test
#   the robustness of the message transfer.
# - create an example dest client


class JsonSrcClient(JSONClient):
    """@brief An example of a JSON source client generating JSON messages."""
    def __init__(self, uo, options):
        JSONClient.__init__(self, options.server, options.src_port)
        self._uo = uo
        self._uo.info("Connected to %s:%d" % (options.server, options.src_port) )

    def start(self):
        """@brief start the client running."""
        try:
            counter = 0
            embeddedDict = {"One": 1, "Two": 2}
            txDict = {"A": counter, "B": counter+1, "C": counter+2, "D": embeddedDict}

            while True:
                self.tx(txDict)
                counter=counter+1
                txDict["A"]=counter
                txDict["B"]=counter+1
                txDict["C"]=counter+2
                embeddedDict["One"] = counter-1000

        finally:
            self.close()

class JsonDestClient(JSONClient):
    """@brief An example of a JSON dest client receiving json broadcast messages."""
    def __init__(self, uo, options):
        JSONClient.__init__(self, options.server, options.dest_port)
        self._uo = uo
        self._uo.info("Connected to %s:%d" % (options.server, options.dest_port) )

    def rxDicts(self):
        """@brief RX multiple dicts"""
        #RX data thread
        while True:
            rxDict = self.rx()
            if rxDict:
                self._uo.info("JsonDestClient: RX: %s" % (repr(rxDict)) )

    def start(self):
        self.rxDicts()


if __name__== '__main__':
    uo = UserIO()

    src_port = 12345
    dest_port = src_port+1

    opts=OptionParser(usage='A JSON bus communication service. A TCP Server accepts messages in json format on source connections and forwards each message received to all connected destination connections.')
    opts.add_option("--server",          help="The server address (default=localhost).", default="localhost")
    opts.add_option("--src_port",        help="The src server port. Clients connect to this port to forward messages to all dest clients (default=%d)." % (src_port) , type="int", default=src_port)
    opts.add_option("--dest_port",       help="The dest server port. Clients connect to this port to receive messages from all sources (default=%d)." % (dest_port) , type="int", default=dest_port)

    opts.add_option("--run_server",      help="Run the json server.", action="store_true", default=False)
    opts.add_option("--run_src_client",  help="Run the json source client.", action="store_true", default=False)
    opts.add_option("--run_dest_client", help="Run the json source client.", action="store_true", default=False)

    (options, args) = opts.parse_args()

    if options.run_server:
        jsonBroadcaster = JsonBroadcaster(src_port, dest_port, serverAddress=options.server)
        jsonBroadcaster.run()

    elif options.run_src_client:
        jsonSrcClient = JsonSrcClient(uo, options)
        jsonSrcClient.start()

    elif options.run_dest_client:
        jsonDestClient = JsonDestClient(uo, options)
        jsonDestClient.start()
