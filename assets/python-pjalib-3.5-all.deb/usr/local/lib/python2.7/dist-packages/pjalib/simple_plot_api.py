#!/usr/bin/env python

import  matplotlib.pyplot as pyplot
from    mpldatacursor import datacursor
import  matplotlib.dates as mdates


class SPlot(object):
    """@brief Simple (at least the original aim) plotting API uses matplotlib.
              Also uses mpldatacursor (https://github.com/joferkington/mpldatacursor)"""
    
    def __init__(self, windowTitle="", subTitle=""):
        """@brief Constructor"""
        #pyplot.xticks(rotation='vertical')
        self._fig = pyplot.figure()
        self._fig.canvas.set_window_title(windowTitle)
        self._fig.suptitle(subTitle)
        self._fig.autofmt_xdate()
        
        self._initXYList()
        
    def _initXYList(self):
        """@brief Init the local value lists"""
        self._xValueList = []
        self._yValuesList = []

    def addXYPlot(self, xValList, yValList, plotLabel, xAxisLabel=None, yAxisLabel=None):
        """@brief Add data to an X/Y plot.
           @param xValList List of X axis values. Can be numbers or a datetime object for a time series plot.
           @param yValList List of Y values.
           @param plotLabel The label for the plot. A user can click on a plot line to view the label/legend.
           @param xAxisLabel The X axis label text.
           @param yAxisLabel The Y axis label text."""

        pyplot.plot(xValList, yValList, label=plotLabel)
        
        if xAxisLabel:
            pyplot.xlabel(xAxisLabel)
            
        if yAxisLabel:
            pyplot.ylabel(yAxisLabel)

        formatter = mdates.DateFormatter('%d-%b-%Y %H:%M:%S')
        pyplot.gcf().axes[0].xaxis.set_major_formatter(formatter)
        pyplot.setp( pyplot.gcf().axes[0].xaxis.get_majorticklabels(), rotation=90 )
        
    def draw(self, maximize=True):
        """@brief draw the plot on the GUI.
           @param maximize Maximize the size of the window."""
        
        # Use a DataCursor to interactively display the label for a selected line...
        datacursor(formatter='{label}'.format)

        if maximize:
            manager = pyplot.get_current_fig_manager()
            manager.resize(*manager.window.maxsize())
        
        pyplot.show()

#-----------------------------------EXAMPLES -----------------------------------

import datetime
import random
import time


def example1():
    """@brief Example of two time series plots on the same axis."""
    plot = SPlot(windowTitle="Frame Title", subTitle="Plot Title")
    
    x=[]
    y=[]
    yValue = 0
    for min in range (60):
        x.append( datetime.datetime(2013, 9, 28, 1, min) )
        yValue = yValue + 1
        y.append(yValue)
        
    plot.addXYPlot(x, y, "plot 1", xAxisLabel="Time1", yAxisLabel="Value1")
    
    x=[]
    y=[]
    yValue = 0
    for hour in range (4):
        x.append( datetime.datetime(2013, 9, 28, hour, 0) )
        yValue = yValue + 1
        y.append(yValue)
        
    plot.addXYPlot(x, y, "plot 2")
    
    plot.draw()

def main():
    """@brief example code."""
    example1()
    
if __name__ == "__main__":
  main()
