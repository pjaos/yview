#We use a pure pyhton syslog impl as the logger module is not avaialble on the
#Omega2 platform.
from syslogger import syslog, PRIORITY
LOG_ERR     = PRIORITY.ERROR
LOG_WARNING = PRIORITY.WARNING
LOG_INFO    = PRIORITY.INFO
LOG_DEBUG   = PRIORITY.DEBUG

import os
import getpass
import thread
import traceback
import sys
import socket

class UserIO(object):
    """@brief This was written to provide a minimal implemntation of the
              functionality to allow command line useer output and input
              and was used on the Omega2 platfrom.
              The Omega2 platform does not have some of the modules used
              by the UIO implementation.
              The responsibilities of this object are
              - Display info, debug and warning level messages
              - Optionally send syslog messages.

       @param minMsgLevel The minimum message level that we will display.
       @param syslogHost The host address of the syslog server. By default this
              is not set and so no syslog messages are generated.
              By default syslog messages contain the hostname of the source.
              The syslogHost may include the source hostname for syslog messages.
              This is done by using a : character to separate the syslog server
              address from the text (E.G local IP address) to be placed
              sent in the syslog message.
       @param disableStdout If True then messages to std out ar disabled. 
                            This is only useful if you only wish to only send 
                            syslog messages."""

    MESSAGE_LEVEL_OFF     = 0
    MESSAGE_LEVEL_INFO    = 1
    MESSAGE_LEVEL_WARNING = 2
    MESSAGE_LEVEL_ERROR   = 3
    MESSAGE_LEVEL_DEBUG   = 4

    INFO_MSG_PREFIX       = "INFO:  "
    WARNING_MSG_PREFIX    = "WARN:  "
    ERROR_MSG_PREFIX      = "ERROR: "
    DEBUG_MSG_PREFIX      = "DEBUG: "

    SYSLOG_SEPARATOR_CHAR = ":"
    
    SyslogLock = thread.allocate_lock()

    #Used this to debug syslog not being sent after system reboot
    #You shouldn't use this as the local disk space will run out quickly
    #if on platforms like Omega2
    DEBUG_SYSLOG          = False
    DEBUG_SYSLOG_FILE     = "/tmp/syslog.txt"

    def __init__(self, minMsgLevel=MESSAGE_LEVEL_DEBUG, syslogHost=None, disableStdout=False):
        self._minMsgLevel   = minMsgLevel
        self._syslogHost    = syslogHost
        self._disableStdout = disableStdout
        
        self.setSyslogServer(syslogHost)
        
        self._username = self._getCurrentUsername()

    def enableStdOut(self, enabled):
        """@brief Enable/disable stdout."""
        self._disableStdout = not enabled

    def setSyslogServer(self, syslogHost):
        """@brief Set the syslog server address.
           @param syslogServerAddress If set to None then syslogging is disabled."""
        self._syslogHost = syslogHost
        
    def _getCurrentUsername(self):
        """Get the current users username or return unknown_user if not able to read it.
           This is required as getpass.getUser() does not always work on windows platforms."""
        username="unknown_user"
        try:
          username=getpass.getuser()
        except:
          pass
        return username

    def _print(self, message):
        """@brief Send a message to stdout.
           @param message The message to be displayed."""
        if not self._disableStdout:
            print message

    def _sendToSyslog(self, pri, msg):
        """@brief Send a message to a syslog host if syslog is enabled.
           Syslog messages will have the following components
           0 = time/date stamp
           1 = hostname
           2 = main python file name
           3 = PID
           4 = username under which the program is being executed
           5 = The syslog message.

           @param pri The syslog message priority. Mapped to info, warn error
                  and debug.
           @param msg The message text to be sent."""

        if UserIO.DEBUG_SYSLOG:
            fd = open(UserIO.DEBUG_SYSLOG_FILE, 'a')
            fd.write( "%s\n" % (msg) )
            fd.close()
        
        if self._syslogHost and len(self._syslogHost) > 0:
            
          self._syslogHost = ''.join([i if ord(i) < 128 else ' ' for i in self._syslogHost])

          UserIO.SyslogLock.acquire()

          try:
              try:

                  # Ensure we have no zero characters in the message. syslog will
                  # throw an error if it finds any.
                  if "\x00" in msg:
                      msg = msg.replace("\x00", "")

                  # Strip non asci characters of syslog will error
                  msg = ''.join([i if ord(i) < 128 else ' ' for i in msg])

                  # send aMsg to syslog with the current process ID and username
                  syslog(pri, "%s,%d: %s" % (str(self._getCurrentUsername()), os.getpid(), str(msg)), host=self._syslogHost)

              # We may get a type error if the caller passes a non itterable msg instance
              except TypeError as e:
                  self._print('%s%s' % (UserIO.ERROR_MSG_PREFIX, str(e)))

          # We may get a socket error if the network is not available (E.G wifi has yet to come up).
          except socket.error as e:
              self._print('%s%s' % (UserIO.ERROR_MSG_PREFIX, str(e)))

          if UserIO.SyslogLock.locked():

            UserIO.SyslogLock.release()

    def info(self, line):
        """@brief display an info level message.
           @param line The line of text to display to the user."""
        self._print('%s%s' % (UserIO.INFO_MSG_PREFIX, line) )
        self._sendToSyslog(LOG_INFO, line)

    def warn(self, line):
        """@brief display a warning level message.
           @param line The line of text to display to the user."""
        self._print('%s%s' % (UserIO.WARNING_MSG_PREFIX, line) )
        self._sendToSyslog(LOG_WARNING, line)

    def error(self, line):
        """@brief display an error level message.
           @param line The line of text to display to the user."""
        self._print('%s%s' % (UserIO.ERROR_MSG_PREFIX, line) )
        self._sendToSyslog(LOG_ERR, line)

    def debug(self, line):
        """@brief display a debug level message.
           @param line The line of text to display to the user."""
        self._print('%s%s' % (UserIO.DEBUG_MSG_PREFIX, line) )
        self._sendToSyslog(LOG_DEBUG, line)
        
    def errorException(self):
        """Show an exception. 
           If debugging is not off then a tracback is displayed.
           If debugging is off then the exception error value is displayed.
           This should only be called when an exception has occurred."""
        traceBackObj = traceback.format_exc()
        if traceBackObj:
            lines = traceBackObj.split('\n')
            for l in lines:
                self.error(l)    
        else:
            self.error("No Exception found.")    
        
    def getInput(self, prompt="", noEcho=False, stripEOL=True):
        """@brief Get input from user"""
        if prompt == None or len(prompt) ==0:
            
          p = "INPUT: "
          
        else:
            
          p = "INPUT: %s: " % (prompt)
          
        if noEcho:
          ip=getpass.getpass(p, sys.stdout)
          if stripEOL:
            ip=ip.rstrip('\n')
            ip=ip.rstrip('\r')
          return ip
          
        ip = raw_input(p)
        if stripEOL:
          ip=ip.rstrip('\n')
          ip=ip.rstrip('\r')
        return ip