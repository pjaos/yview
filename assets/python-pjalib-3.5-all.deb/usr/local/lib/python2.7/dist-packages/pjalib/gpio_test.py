#!/usr/bin/env python

from gpio import GPIO

def main():

    gpio = GPIO(False)
    
    error=False
    pin = 0
    for setState in [0,1]:
        gpio.setPin(pin, setState)
        stateRead = gpio.getPin(pin)
        if stateRead != setState:
            print 'Set GPIO pin %d to %d and read %d' % (pin, setState, stateRead) 
            error=True
            
    if not error:
        print 'Set GPIO pin %d high and low and read back the pin state in each case.' % (pin)

if __name__== '__main__':
    main()