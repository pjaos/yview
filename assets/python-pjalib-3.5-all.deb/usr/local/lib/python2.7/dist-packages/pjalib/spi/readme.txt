- Run make to build the native_pspi.so module. 
  If testing on the raspberry pi then do this on the raspberry pi.
  You'll need the python-dev package installed on the raspberry pi for this.
- Connect the MOSI and MOSO pins together on the raspberry pi.
- You can then run the run_raspberry_pi_tests.sh script to test pspi is working.
