#!/usr/bin/env python

################################################################################
# 
# Copyright (c) 2010, Paul Austen. All rights reserved.
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301  USA
#
################################################################################
import  sys
from    SimpleXMLRPCServer import SimpleXMLRPCServer, SimpleXMLRPCRequestHandler
import  xmlrpclib

class XMLRequestHandler(SimpleXMLRPCRequestHandler):
  rpc_paths = ('/RPC2',)
  
class XMLRPCServer(object):
  
  def __init__(self, serverObject, port, uio=None):
    """Constructor
       @param serverObject  The object whose methods we will server via the RPC server.
       @param port          The TCP/IP port to serve over
       @param uio           The optional uio object to display connection messages."""
    self._port=port
    self._uio=uio
    # Create server, listening on all addresses
    self._server = SimpleXMLRPCServer(("", port), requestHandler=XMLRequestHandler, allow_none=True)
    self._server.register_introspection_functions()
    #All public methods will be available to call remotely
    self._server.register_instance(serverObject)

  def serve_forever(self):
    try:             
      if self._uio != None:
        self._uio.info("RPC server is now running on port %d." % (self._port) )
        self._server.serve_forever()
    except KeyboardInterrupt:
        self._uio.info('^C received, shutting down server')
        self._server.socket.close()
     
class XMLRPCClient(object):
    """Repsonsible for RPC's to the above server."""
    def __init__(self, uio, host, port):
        self._uio=uio
        #Create an RPC client to be used to invoke the methods on the server.
        self._rpcClient = xmlrpclib.ServerProxy('http://%s:%d' % (host, port) )
          
    def getRPCInfoLines(self):
        """Return the RPC method information as a list of lines of text."""
        lines=[]
        methodList = self._rpcClient.system.listMethods()
        methodList.sort()
        for m in methodList:
          lines.append("=" * 80)
          lines.append("%s" % (m) )
          lines.append("-" * 80)    
          t = self._rpcClient.system.methodHelp(m)
          _lines = t.split('\n')
          for l in _lines:
            lines.append(l)
        return lines
       
       
    def showRPCList(self):
        """Show the user the RPC info."""
        lines = self.getRPCInfoLines()
        for l in lines:
          self._uio.info(l)
      
        
