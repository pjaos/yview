#!/usr/bin/env python
################################################################################
# 
# Copyright (c) 2010, Paul Austen. All rights reserved.
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301  USA
#
################################################################################

# Requires several python packages 
# sudo apt-get install python-numpy
# sudo apt-get install python-matplotlib
#
# You may need the latest version of matplotlib
# - sudo apt-get install python-dev libfreetype6-dev
# - Download and deflate matplotlib-1.2.0.tar.gz
# - cd matplotlib
# - python setup.py build
# - sudo python setup.py install

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from   time import sleep
import threading 
import Queue
import random
from   time import time

DISPLAY_POINT_COUNT=100

class PlotSet():
  """Hold a set of X and Y points to be plotted at once
  """
  def __init__(self, xValues, yValues):
    self.xValues=xValues
    self.yValues=yValues    

class Scale():
  """Holds the min and max scale values"""
  def __init__(self):
    self.min=0
    self.max=1    

class XYPlot(threading.Thread):
  """A simple line graph X/Y plot
     queue = A queue object containing PlotSet objects
     numPlotPoints = The number of plot points to be plotted
     xScale = A Scale object defining the min and max values of the X scale
     yScale = A Scale object defining the min and max values of the Y scale
  """
  def __init__(self, queue, numPlotPoints, xScale, yScale ):
    threading.Thread.__init__(self)
    self.queue=queue
    self.fig = plt.figure()
    self.ax = self.fig.add_subplot(111)
    self.line, = self.ax.plot(range(0,numPlotPoints))
    #For fast plotting, don't use autoscale
    self.ax.set_xlim(xScale.min, xScale.max)
    self.ax.set_ylim(yScale.min, yScale.max)
    self.isVisible=False
    self.setDaemon(True)
    plt.minorticks_off()

  def setTitle(self, title):
    """Set plot title"""
    self.ax.set_title(title)

  def setXAxisLabel(self, text):
    """Set the X axis label text"""
    self.ax.set_xlabel(text)

  def setYAxisLabel(self, text):
    """Set the Y axis label text"""
    self.ax.set_ylabel(text)

  def update(self, plotSet):
    if plotSet == None:
      return self.line
    self.line.set_xdata(plotSet.xValues)
    self.line.set_ydata(plotSet.yValues)
    return self.line,

  def data_gen(self):
    while True:
      if self.queue.qsize() > 0:
        plotSet=self.queue.get()
        yield plotSet
      yield None

  def run(self):
    self.isVisible=True
    ani = animation.FuncAnimation(self.fig, self.update, self.data_gen, interval=1)
    ani.new_frame_seq()
    plt.show(block=False)
    self.isVisible=False
    
  def displayAndBlock(self):
    """This should be called from the main thread and will block until the
       window is closed."""
    plt.show()
    
class QueueWriterThread(threading.Thread):
  """Simulate some process producing points to plot"""
  def __init__(self, queue):
    threading.Thread.__init__(self)
    self.queue = queue
          
  def run(self):
    while True:
      valueList=[]
      xvals=[]
      yvals=[]
      xVal=1
      while len(xvals) < DISPLAY_POINT_COUNT:
        xvals.append(xVal)
        xVal=xVal+1
        yvals.append(random.random())

      plotSet = PlotSet(xvals, yvals)

      #Only load data into the plot queue if the plot thread can plot the points
      if queue.qsize() < 20:
        self.queue.put(plotSet)
      if queue.qsize() > 1:
        #Show if the queue starts to fill because the plotting of points is to
        #slow.
        print "PJA: queue.qsize()=",queue.qsize()
      #Add a set of plot points every 0.1 second
      sleep(0.2)


#Example code
if __name__ == "__main__":
  #We need a queue to pass PlotPoints through from producer to consumer (XYPlot)
  queue = Queue.Queue()
  
  #Create and start an example thread to produce PlotSet objects and add them to the queue
  qwt = QueueWriterThread(queue)
  qwt.setDaemon(True)
  qwt.start()
  
  #Define the X scale
  xScale = Scale()
  xScale.min=0
  xScale.max=DISPLAY_POINT_COUNT
  
  #Define the Y scale
  yScale = Scale()
  yScale.min=0
  yScale.max=1.0
  
  #Create an object to start displaying data
  xyPlot = XYPlot(queue, DISPLAY_POINT_COUNT, xScale, yScale)
  xyPlot.setTitle("The plot title")
  xyPlot.setXAxisLabel("X Axis label")
  xyPlot.setYAxisLabel("Y Axis label")
  xyPlot.start()

  xyPlot.displayAndBlock()

  

