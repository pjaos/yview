# ssh related classes and methods library
################################################################################
#
# Copyright (c) 2010, Paul Austen. All rights reserved.
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301  USA
#
################################################################################

import os
import sys
import socket
import getpass
import platform
import warnings
import paramiko
import logging
import threading
import SocketServer
import select

from cmd_helper import getLines, getAddrPort, getIntUserResponse, getBoolUserResponse
from uio import UIO
from texttable import Texttable
from subprocess import call
from getpass import getuser

LOCAL_SSH_CONFIG_PATH = os.path.join(os.path.expanduser("~"), ".ssh")
DEFAULT_REMOTE_SSH_AUTH_KEYS_FILE = "~/.ssh/authorized_keys"
DROPBEAR_DIR = "/etc/dropbear"
DROPBEAR_AUTH_KEYS_FILE = "%s/authorized_keys" % (DROPBEAR_DIR)
SSH_COPY_PROG = "/usr/bin/ssh-copy-id"

# Suppress
# /usr/lib/python2.7/dist-packages/Crypto/Cipher/blockalgo.py:141: FutureWarning: CTR mode needs counter parameter, not IV
#  self._cipher = factory.new(key, *args, **kwargs)
# NEed a better way to do this, this will have to do for now.
warnings.simplefilter("ignore")


class SSHError(Exception):
    pass


# Ensure paramiko is installed on this computer
try:
    import warnings

    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=DeprecationWarning)
        from paramiko import SSHClient, AutoAddPolicy, RSAKey, util
    # Workaround for paramiko issue which can give
    # No handlers could be found for logger "paramiko.transport"
    # message on stderr
    if not platform.system() == "Windows":
        util.log_to_file('/dev/null')

except ImportError:
    print
    'ERROR: paramiko is not installed on this computer.'
    print
    'INFO:  paramiko must be installed in order to use sshpf.py.'
    print
    'INFO:'
    print
    'INFO:  Installing Paramiko'
    print
    'INFO:'
    print
    'INFO:  Linux, debian systems'
    print
    'INFO:  - sudo apt-get install python-paramiko'
    print
    'INFO:'
    print
    'INFO:  Windows'
    print
    'INFO:  - Install pycrypto for the python version you have.'
    print
    'INFO:    - Download from http://www.voidspace.org.uk/python/modules.shtml#pycrypto'
    print
    'INFO:    - Double click on the installer.'
    print
    'INFO:  - Install paramiko for windows'
    print
    'INFO:    - Ensure Mingw is installed (see http://www.mingw.org/).'
    print
    'INFO:    - Download from http://www.lag.net/paramiko/download/paramiko-1.7.4.zip'
    print
    'INFO:    - Unzip the above file.'
    print
    'INFO:    - Open a command prompt in where the file was unzipped.'
    print
    "INFO:    - run 'python setup.py build --compiler=mingw32 bdist_wininst'"
    print
    "INFO:    - Manually copy the paramiko dir to the python site-packages path.'"
    sys.exit(-1)


# -------------------------------------------------------------------------------
# The ssh client class

class ExtendedSSHClient(SSHClient):

    def __init__(self):
        super(ExtendedSSHClient, self).__init__()
        self.set_missing_host_key_policy(AutoAddPolicy())

    def __exec_command(self, command, bufsize=-1):
        """
        Execute a command on the SSH server.  A new L{Channel} is opened and
        the requested command is executed.  The command's input and output
        streams are returned as python C{file}-like objects representing
        stdin, stdout, and stderr.

        @param command: the command to execute
        @type command: str
        @param bufsize: interpreted the same way as by the built-in C{file()} function in python
        @type bufsize: int
        @return: the stdin, stdout, and stderr of the executing command
        @rtype: tuple(L{ChannelFile}, L{ChannelFile}, L{ChannelFile})

        @raise SSHException: if the server fails to execute the command
        """
        chan = self._transport.open_session()
        chan.exec_command(command)
        stdin = chan.makefile('wb', bufsize)
        stdout = chan.makefile('rb', bufsize)
        stderr = chan.makefile_stderr('rb', bufsize)
        exitStatus = chan.recv_exit_status()
        return stdin, stdout, stderr, exitStatus

    def runCmd(self, cmd, throwError=True):
        """Run a command over an ssh session and return a tuple with the following threee elements
          0 - the return code/exit status of the command
          1 - Lines of text from stdout
          2 - lines of text from stderr

          If throwError is true and the exit status of the copmmand is not 0 then an
          SSHError will be thrown
        """
        stdin, stdout, stderr, exitStatus = self.__exec_command(cmd)
        if throwError and exitStatus != 0:
            errorText = stderr.read()
            if len(errorText) > 0:
                raise SSHError(errorText)
            raise SSHError("The cmd '%s' return the error code: %d" % (cmd, exitStatus))
        return [exitStatus, getLines(stdout.read()), getLines(stderr.read())]

    def getFileLines(self, f):
        # Check the file exists
        rc, stdoutLines, stderrLines = self.runCmd("test -f %s" % (f), throwError=False)
        # If it does rad its contents
        if rc == 0:
            rc, stdoutLines, stderrLines = self.runCmd("cat %s" % (f))
        else:
            stdoutLines = []
        return stdoutLines


# -------------------------------------------------------------------------------
# ssh autologin code

PUBLIC_KEY_FILE_LIST = ["id_rsa.pub", "id_dsa.pub", 'id_ecdsa.pub']


def createSSHKeys(uio, sshDir):
    """Create a public/private ssh key pair in sshDir"""
    uio.info("Generating ssh RSA private/public key pair")
    publicKeyFilename = PUBLIC_KEY_FILE_LIST[0]
    publicKeyFile = os.path.join(sshDir, publicKeyFilename)
    privateKeyFile = os.path.join(sshDir, publicKeyFile[:-4])
    _hostname = socket.gethostname()
    _username = getpass.getuser()

    key = RSAKey.generate(2048)

    key.write_private_key_file(privateKeyFile)
    base64Key = key.get_base64()
    f = open(publicKeyFile, 'w')
    f.write("ssh-rsa " + base64Key + " " + _username + '@' + _hostname + '\n')
    f.close()

    return publicKeyFilename


def ensureSSHKeysExist(uio):
    """Ensure the SSH keys exist."""
    sshDir = LOCAL_SSH_CONFIG_PATH
    if not os.path.isdir(sshDir):
        # Create the dir
        os.mkdir(sshDir)

    dirList = os.listdir(sshDir)

    # Get a public key file if one exists
    publicKeyFile = None
    for pkf in PUBLIC_KEY_FILE_LIST:
        if pkf in dirList:
            publicKeyFile = pkf
            break

    if publicKeyFile == None:
        publicKeyFile = createSSHKeys(uio, sshDir)

    dirList = os.listdir(sshDir)

    privateKeyFile = publicKeyFile[:-4]
    if privateKeyFile not in dirList:
        raise SSHError("Found %s in %s but failed to find its associated private key file (%s)." % (publicKeyFile, sshDir, privateKeyFile))

    uio.debug("Using %s/%s private/public key pair in %s." % (privateKeyFile, publicKeyFile, sshDir), UIO.DEBUG_LEVEL_1)


def getPublicKeyFile():
    """Get the public key file."""
    sshDir = LOCAL_SSH_CONFIG_PATH
    if not os.path.isdir(sshDir):
        raise SSHError("%s path not found on local computer.\nPlease use the 'ssh-keygen -t rsa' command to create ssh keys." % (sshDir))
    files = os.listdir(sshDir)
    for f in files:
        if f == "id_rsa.pub" or f == "id_dsa.pub" or f == 'id_ecdsa.pub':
            return os.path.join(sshDir, f)
    raise SSHError("Failed to find *.pub key file in the %s local path. Run ssh-keygen -t rsa to create key." % (sshDir))


def getPublicKey():
    """Get the public ssh key from the local machine"""
    pubKeyFile = getPublicKeyFile()

    fd = open(pubKeyFile, 'r')
    lines = fd.readlines()
    fd.close()

    if len(lines) < 1:
        raise SSHError("No public key text found in the %s file on the local computer." % (pubKeyFile))

    publicKey = lines[0]
    publicKey = publicKey.strip('\n')
    publicKey = publicKey.strip('\r')
    publicKey = publicKey.strip()
    return publicKey


def getLocalPublicKey():
    """Get a local public ssh key"""
    return getPublicKey()


def getRemoteAuthorisedKeyFile(ssh):
    """@brief Return the remote authorised key file for the current ssh connection."""

    authKeysFile = DEFAULT_REMOTE_SSH_AUTH_KEYS_FILE

    cmd = "test -d %s" % (DROPBEAR_DIR)
    rc, stdoutLines, stderrLines = ssh.runCmd(cmd, throwError=False)
    if rc == 0:
        authKeysFile = DROPBEAR_AUTH_KEYS_FILE

    return authKeysFile


def getRemoteAuthorisedKeys(ssh):
    """Get the remote authorised keys file over the ssh connection."""
    authKeysFile = getRemoteAuthorisedKeyFile(ssh)
    cmd = "test -f %s" % (authKeysFile)
    rc, stdoutLines, stderrLines = ssh.runCmd(cmd, throwError=False)
    if rc != 0:
        # Auth keys file not found, attempt to create an empty one.
        cmd = "touch %s" % (authKeysFile)
        rc, stdoutLines, stderrLines = ssh.runCmd(cmd, throwError=False)
        cmd = "test -f %s" % (authKeysFile)
        rc, stdoutLines, stderrLines = ssh.runCmd(cmd, throwError=False)
        if rc != 0:
            raise SSHError("!!! Server auth keys file not found (%s). Failed to create it." % (authKeysFile))

    rc, stdoutLines, stderrLines = ssh.runCmd("cat %s" % (authKeysFile), throwError=False)

    # Ensure we only return non empty lines
    authKeyLines = []
    for l in stdoutLines:
        if len(l.strip()) > 0:
            authKeyLines.append(l)
    return authKeyLines


def updateAuthorisedKeys(ssh, publicKey):
    """Update the authorised keys file on the remote ssh server with the
       public ssh key"""
    authKeysFile = getRemoteAuthorisedKeyFile(ssh)
    cmd = "test -d %s" % (authKeysFile)
    rc, stdoutlines, stderrlines = ssh.runCmd(cmd, throwError=False)
    if rc == 0:
        # If this is a dir with nothing in it, delete it and create an empty
        # authorized_keys file.
        ssh.runCmd("rmdir %s" % (authKeysFile))
        ssh.runCmd("touch %s" % (authKeysFile))

    ssh.runCmd("echo \"%s\" >> %s" % (publicKey, authKeysFile))
    ssh.runCmd("chmod 600 %s" % (authKeysFile))
    return authKeysFile


def sshCopyProgExists():
    """@brief Check to see if the local program (part of open ssh) to copy keys exists."""
    if os.path.isfile(SSH_COPY_PROG):
        return True
    return False


def copySSHKeyExternal(host, port, username):
    """@brief Copy a local ssh key to remote using the open ssh key copy program.
       @param host the ssh server host address
       @param port the ssh server port
       @param username The ssh username
       @return True on success"""
    returnCode = False
    if sshCopyProgExists():
        cmd = "ssh-copy-id -p %d %s@%s" % (port, username, host)
        returnCode = call(cmd, shell=True)
    return returnCode


def ensureAutoLogin(ssh, uio):
    """@brief Ensure that ssh auto login is enabled.
       @param ssh A connected ssh connection.
       @param uio A UserIO object."""
    # Get the local public key
    localPublicKey = getLocalPublicKey()
    _hostname, _username, _keytype, _ = getSSHKeyAttributes(localPublicKey)
    if _hostname == None:
        _hostname = socket.gethostname()
    if _username == None:
        _username = getpass.getuser()

    uio.info("Using key: %s@%s" % (_username, _hostname))
    remoteAuthorisedKeys = getRemoteAuthorisedKeys(ssh)
    # Check to see if the remote authorised keys contains the local public key
    updateAuthKeys = True
    for remoteAuthorisedKeys in remoteAuthorisedKeys:
        if remoteAuthorisedKeys.find(localPublicKey) == 0:
            updateAuthKeys = False
            break

    if updateAuthKeys:
        remoteAuthKeysFile = updateAuthorisedKeys(ssh, localPublicKey)
        uio.info("Updated the remote %s file from the local %s file." % (remoteAuthKeysFile, getPublicKeyFile()))
    else:
        uio.info("The server already has the local ssh key (%s) in its authorized_key file." % (getPublicKeyFile()))


def sshConnect(ssh, username, host, port, uio, passwordList, autoAconnectOnly=False, timeoutSecs=15, msgPrefix=""):
    """Attempt to build an ssh session.
       All ssh connections are connected here.
    """
    if username == None:
        raise SSHError("username not defined.")

    uio.info("%sAttempting to build an ssh connection to %s@%s:%d" % (msgPrefix, username, host, port))

    try:
        # Attempt auto login with supplied username and no password
        ssh.connect(host, username=username, port=port, timeout=timeoutSecs, allow_agent=False)
        uio.info("%sConnected to %s:%d" % (msgPrefix, host, port))
    # Ctrl C while connectiing so exit
    except KeyboardInterrupt:
        sys.exit(0)
    except:
        # If auto connect is required to work then raise the error here
        if autoAconnectOnly:
            raise

        # If we have some passwords to try do so
        if passwordList != None and len(passwordList) > 0:
            for password in passwordList:
                uio.info("%sAttempting to build an ssh connection to %s:%d using password ******" % (msgPrefix, host, port))
                try:
                    uio.info("%sAttempting to build an ssh connection to %s@%s:%d using password ******" % (msgPrefix, username, host, port))
                    ssh.connect(host, username=username, password=password, port=port, timeout=timeoutSecs, allow_agent=False)
                    # If we managed to login
                    return
                except:
                    pass

        uio.info("Autologin failed. A password is required.")
        password = uio.getPassword()
        uio.info("%sAttempting to build an ssh connection %s@%s:%d" % (msgPrefix, username, host, port))
        ssh.connect(host, username=username, password=password, port=port, timeout=timeoutSecs, allow_agent=False)
        # If we got in save the password for future login attempts as it may work on other ssh servers
        # thus reducing the need of the user to re enter the same password.
        passwordList.append(password)


def autoLogin(uio, host, username):
    """Attempt to login to the ssh server."""

    host, port = getAddrPort(host)
    ssh = ExtendedSSHClient()
    sshConnect(ssh, username, host, port, uio, [])
    ensureAutoLogin(ssh, uio)
    ssh.close()
    uio.info("Closing ssh connection.")


def getSSHKeyAttributes(authKey):
    """Extract the following from an ssh key and return themn in a tuple
       hostname
       username
       keytype
       key

       If unable to extract the above attributes then None is returned.
    """
    hostname = None

    elems = authKey.split()
    if len(elems) > 2:
        keytype = elems[0]
        key = elems[1]
        tmpElems = elems[2].split("@")
        if len(tmpElems) > 1:
            username = tmpElems[0]
            hostname = tmpElems[1]
        else:
            username = elems[2]
            hostname = "?"

    if hostname != None:
        return (hostname, username, keytype, key)
    return (None, None, None, None)


def editServerAccess(uio, host, username):
    """Allow a user to edit the ssh server auth keys file interactively"""
    uio.info("Building ssh connection to %s" % (host))

    host, port = getAddrPort(host)
    ssh = ExtendedSSHClient()
    sshConnect(ssh, username, host, port, uio, [])
    uio.info("Connected")

    table = Texttable()
    table.set_deco(Texttable.BORDER | Texttable.VLINES)
    table.add_row(["ssh Key", "hostname", "username", "ssh key type"])
    rowNumber = 1

    while True:
        # Display a table containing details of the ssh server authorised keys
        authKeys = getRemoteAuthorisedKeys(ssh)
        for authKey in authKeys:
            # Ignore commented out keys
            if authKey.strip().startswith("#"):
                continue
            hostname, username, keytype, _ = getSSHKeyAttributes(authKey)
            if hostname != None:
                table.add_row([rowNumber, hostname, username, keytype])
            rowNumber = rowNumber + 1

        tableText = table.draw() + "\n"
        lines = tableText.split('\n')
        for l in lines:
            uio.info(l)

        maxRowNumber = rowNumber
        # Enter the key to delete
        while True:
            rowNumber = getIntUserResponse(uio, "Please enter the ssh server key that to remove or [Q]uit")
            if rowNumber == None:
                return
            if rowNumber < 1 or rowNumber > maxRowNumber:
                uio.error("Please enter a valid key number.")
            else:
                break

        proceed = getBoolUserResponse(uio, "Do you wish to remove ssh key %d ? [y/n]" % (rowNumber))
        if not proceed:
            return
        break

    okToUpdateAuthorisedKeys = True

    secondAuthKeys = getRemoteAuthorisedKeys(ssh)
    # Check that the number of authorised keys has not changed
    if len(authKeys) != len(secondAuthKeys):
        uio.error("The authorised keys have been changed by someone else, plese try again.")
        okToUpdateAuthorisedKeys = False

    # Check that the contents of the authorised keys has not changed
    if okToUpdateAuthorisedKeys:
        for authKey in authKeys:
            if authKey not in secondAuthKeys:
                uio.error("The authorised keys have been changed by someone else, plese try again.")
                okToUpdateAuthorisedKeys = False
                break

    if okToUpdateAuthorisedKeys:
        # Delete the authorised key from the list
        del authKeys[rowNumber - 1]
        # Save the auth key list back to the server
        setAuthKeys(ssh, authKeys)
        uio.info("SSH server autologin using key %d has been disabled." % (rowNumber))
    else:
        uio.info("No changes were made to the SSH server autologin." % (rowNumber))


def setAuthKeys(ssh, lines):
    """Set the ssh server authorised key file to contain these lines of text"""
    authKeysFile = getRemoteAuthorisedKeyFile(ssh)
    previousAuthKeysFile = getAuthKeyBackupFile(ssh)
    tmpAuthKeysFile = "%s.tmp" % (authKeysFile)

    # Remove any pre existing tmp auth keys file
    ssh.runCmd("rm -f %s" % (tmpAuthKeysFile), throwError=False)

    # Create empty tmp auth keys file
    ssh.runCmd("touch %s" % (tmpAuthKeysFile))

    # Write each line to the file
    for l in lines:
        ssh.runCmd("echo \"%s\" >> %s" % (l, tmpAuthKeysFile), throwError=False)

    # Remove any pre existing previous auth keys file
    ssh.runCmd("rm -f %s" % (previousAuthKeysFile), throwError=False)

    # Move the current auth keys file to the old one and the tmp to the current one
    ssh.runCmd("mv %s %s" % (authKeysFile, previousAuthKeysFile))
    ssh.runCmd("mv %s %s" % (tmpAuthKeysFile, authKeysFile))


def getAuthKeyBackupFile(ssh, maxBackupFileCount=10):
    """Get the name of the backup name for the authorised keys file.
       - We create up to maxBackupFileCount backup files.
       - Once all the backup files have been created we always replace the oldest
         backup file.
       - The backup files have the suffix .backup1, .backup2 etc.
    """
    authKeysFile = getRemoteAuthorisedKeyFile(ssh)
    authKeyBackupFilePart = "%s.backup" % (authKeysFile)
    suffixNum = 1
    while True:
        authKeyBackupFileName = "%s%d" % (authKeyBackupFilePart, suffixNum)
        rc, stdoutLines, stderrLines = ssh.runCmd("test -f %s" % (authKeyBackupFileName), throwError=False)
        if rc != 0:
            return authKeyBackupFileName
        # If all the backup files have been created
        if suffixNum >= maxBackupFileCount:
            # List the files in creation order (oldest first)
            rc, stdoutLines, stderrLines = ssh.runCmd("ls -ltr %s*" % (authKeyBackupFilePart), throwError=False)
            if rc == 0:
                if len(stdoutLines) > 0:
                    elems = stdoutLines[0].split()
                    if len(elems) > 0:
                        # Return the oldest file as the next backup filename so that we roll
                        # around the always replacing the oldest backup file.
                        backupfile = elems[len(elems) - 1]
                        return backupfile

            raise SSHError("Unable to %s to %s. Please manually remove the backup files on the ssh server." % (authKeysFile, authKeyBackupFilePart))

        suffixNum = suffixNum + 1


def openSSHConnection(username, host, port, uio, passwordList=[]):
    """Open an ssh connection to an ssh server,
       passwordList may be an emty list if auto login is configured."""
    ssh = ExtendedSSHClient()
    ssh.set_missing_host_key_policy(AutoAddPolicy())
    sshConnect(ssh, username, host, port, uio, passwordList)
    return ssh

#---------------------------------------------------------------------------------------------
# The following is a lter implementation of ssh library functions and duplicates some of the above
# We'll have them both for a while until I move all implemenations to use the following.

class SSH(object):
    """@brief responsible for connecting an ssh connection, excuting commands."""

    PRIVATE_KEY_FILE_LIST = ["id_rsa", "id_dsa", 'id_ecdsa']

    @staticmethod
    def GetPrivateKeyFile():
        """@brief Get the private key file from the <HOME>/.ssh"""
        homePath = os.path.expanduser("~")
        homeFolder = '%s/.ssh' % (homePath)
        if not os.path.isdir(homeFolder):
            username = getuser()
            if username == 'root':
                homeFolder = '/root/.ssh'
            else:
                homeFolder = '/home/%s/.ssh' % (username)

        for key in SSH.PRIVATE_KEY_FILE_LIST:
            keyFile = os.path.join(homeFolder, key)
            if os.path.isfile(keyFile):
                return keyFile

        raise SSHError("Unable to find private key file. Please use the 'ssh-keygen -t rsa' command to generate the key.")

    def __init__(self, host, port, username, useCompression, sshPrivateKeyFile, password=None, uo=None):
        """@brief Constructor
           @param host The SSH hostname
           @param port The port number
           @param username The ssh username"""
        self._host = host
        self._port = port
        self._username = username
        self._uo = uo
        self._localAddress = None
        self.useCompression = useCompression
        self._sshPrivateKey = paramiko.RSAKey.from_private_key_file(sshPrivateKeyFile)
        self._password = password

        self._ssh = paramiko.SSHClient()
        logging.getLogger("paramiko").setLevel(logging.WARNING)
        self._ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    def connect(self):
        """@brief Connect the ssh connection
           @return a ref to the paramiko.SSHClient object"""

        self._ssh.connect(self._host, username=self._username, password=self._password, port=self._port, pkey=self._sshPrivateKey)
        # It can be usefull to know what local IP address was used to reach the ssh server
        self._localAddress = self._ssh.get_transport().sock.getsockname()[0]
        self._ssh.get_transport().use_compression(self.useCompression)

    def getLocalAddress(self):
        """@brief Get the local IP address of the network interface used to connect to the ssh server"""
        return self._localAddress

    def getSSHClient(self):
        """@brief return a ref to the SSHClient object"""
        return self._ssh

    def runCmd(self, cmd, _timeout=None):
        """@brief Run command over an active ssh session.
           @param timeout The timeout for the command in seconds (default=None).
           @return a tuple (stdin, stdout, stderr)"""
        return self._ssh.exec_command(cmd, timeout=_timeout)

    def close(self):
        """@brief Close an open ssh connection."""
        self._ssh.close()

    def getTransport(self):
        """@brief Get the ssh transport object. Should only be
                  called when the ssh session is connected.
           @return The ssh transport object."""
        return self._ssh.get_transport()


class SSHTunnelManager(object):
    """@brief Responsible for setting up, tearing down and maintaining lists of
              SSH port forwarding and ssh reverse port forwarding connections."""

    RX_BUFFER_SIZE = 4096

    def __init__(self, uo, ssh, useCompression):
        """@brief Constructor
           @param uo  UserOutput object
           @param ssh An instance of paramiko.SSHClient that has previously been
                      connected to an ssh server"""
        self._uo = uo
        self._ssh = ssh
        self._useCompression = useCompression
        if not self._ssh.getTransport().is_active():
            raise SSHError("!!! The ssh connection is not connected !!!")

        self._forwardingServerList = []
        self._reverseSShDict = {}

    def startFwdSSHTunnel(self, serverPort, destHost, destPort):
        """@brief Start an ssh port forwarding tunnel. This is a non blocking method.
                  A separate thread will be started to handle data transfer over the
                  ssh forwarding connection.
           @param serverPort The TCP server port. On a port forwarding connection
                             the TCP server runs on the src end of the ssh connection.
                             This is the machine that this python code is executing on.
           @param destHost   The host address of the tunnel destination at the remote
                             end of the ssh connection.
           @param destPort   The host TCP port of the tunnel destination at the remote
                             end of the ssh connection."""
        self._uo.info("Forwarding local TCP server port (%d) to %s:%d on the other end of the ssh connection." % (serverPort, destHost, destPort))
        transport = self._ssh.getTransport()

        class SubHander(ForwardingHandler):
            chain_host = destHost
            chain_port = destPort
            ssh_transport = transport
            ssh_transport.use_compression(self._useCompression)
            uo = self._uo

        forwardingServer = ForwardingServer(('', serverPort), SubHander)
        self._forwardingServerList.append(forwardingServer)
        newThread = threading.Thread(target=forwardingServer.serve_forever)
        newThread.setDaemon(True)
        newThread.start()

    def stopFwdSSHTunnel(self, serverPort):
        """@brief stop a previously started ssh port forwarding server
           @param serverPort The TCP server port which is currently accepting
                             port forwarding connections on."""
        for forwardingServer in self._forwardingServerList:
            forwardingServerPort = forwardingServer.server_address[1]
            if forwardingServerPort == serverPort:
                forwardingServer.shutdown()
                forwardingServer.server_close()
                self._uo.info("Shutdown ssh port forwarding connection using local server port %d." % (serverPort))

    def stopAllFwdSSHTunnels(self):
        """@brief Stop all previously started ssh port forwarding servers.."""
        for forwardingServer in self._forwardingServerList:
            forwardingServer.shutdown()
            forwardingServer.server_close()
            self._uo.info("Shutdown ssh port forwarding on %s." % (str(forwardingServer.server_address)))

    def startRevSSHTunnel(self, serverPort, destHost, destPort):
        """@brief Start an ssh reverse port forwarding tunnel
           @param serverPort The TCP server port. On a reverse port forwarding connection
                             the TCP server runs on the dest end of the ssh connection.
                             This is the machine at the remote end of the ssh connection.
           @param destHost   The host address of the tunnel destination at the local
                             end of the ssh connection.
           @param destPort   The host TCP port of the tunnel destination at the local
                             end of the ssh connection."""
        self._uo.info("Forwarding (reverse) Remote TCP server port (%d) to %s:%d on this end of the ssh connection." % (serverPort, destHost, destPort))
        # We add the None refs as the placeholders will be used later
        chan = None
        sock = None
        self._reverseSShDict[serverPort] = (destHost, destPort, chan, sock)

        self._ssh.getTransport().use_compression(self._useCompression)
        self._ssh.getTransport().request_port_forward('', serverPort, handler=self._startReverseForwardingHandler)

    def stopRevSSHTunnel(self, serverPort):
        """@brief stop a previously started reverse ssh port forwarding server
           @param serverPort The TCP server port which is currently accepting
                             port forwarding connections on."""
        if self._reverseSShDict.has_key(serverPort):
            revSSHParams = self._reverseSShDict[serverPort]
            chan = revSSHParams[2]
            sock = revSSHParams[3]

            if chan:
                chan.close()

            if sock:
                sock.close()

            self._uo.info("Shutdown reverse ssh port forwarding connection using remote server port %d." % (serverPort))

    def stopAllRevSSHTunnels(self):
        """@brief Stop all previously started reverse ssh port forwarding servers."""
        for key in self._reverseSShDict.keys():
            revSSHParams = self._reverseSShDict[key]
            chan = revSSHParams[2]
            sock = revSSHParams[3]

            if chan:
                chan.close()

            if sock:
                sock.close()

            self._uo.info("Shutdown reverse ssh port forwarding connection using remote server port %d." % (key))

    def stopAllSSHTunnels(self):
        """@brief Stop all ssh tunnels."""
        self.stopAllFwdSSHTunnels()
        self.stopAllRevSSHTunnels()

    # !!! The following methods are internal and should noit be called externally.
    def _getDestination(self, serverPort):
        """@brief Get destination (address and port) for the given server port.
           @param serverPort The TCP server port on the ssh server."""
        if self._reverseSShDict.has_key(serverPort):
            revSSHParams = self._reverseSShDict[serverPort]
            return (revSSHParams[0], revSSHParams[1])

        return None

    def _startReverseForwardingHandler(self, chan, (origin_addr, origin_port), (server_addr, serverPort)):
        """@brief Called when a channel is connected in order to start a handler thread fot it."""

        # Get the destination address and port for this server port
        destHost, destPort = self._getDestination(serverPort)

        hThread = threading.Thread(target=self._reverseForwardingHandler, args=(chan, serverPort, destHost, destPort))
        hThread.setDaemon(True)
        hThread.start()

    def _reverseForwardingHandler(self, chan, serverPort, destHost, destPort):
        """@brief Handle a reverse ssh forwarding connection.
           @param chan A connected channel over an ssh connection.
           @param serverPort The server port (on remote ssh server) from where the reverse ssh connection originated.
           @param destHost The destination host address.
           @param destPort The destination port address."""

        sock = socket.socket()
        # Add references to the chnl and sock so that they can be closed if required
        self._reverseSShDict[serverPort] = (destHost, destPort, chan, sock)
        try:
            sock.connect((destHost, destPort))
        except Exception as e:
            self._uo.error('Forwarding (reverse) request to %s:%d failed: %r' % (destHost, destPort, e))
            return

        self._uo.info('Connected!  Reverse tunnel open %r -> %r -> %r' % (chan.origin_addr,
                                                                          chan.getpeername(), (destHost, destPort)))
        while True:
            r, w, x = select.select([sock, chan], [], [])
            if sock in r:
                data = sock.recv(SSHTunnelManager.RX_BUFFER_SIZE)
                if len(data) == 0:
                    break
                try:
                    chan.send(data)
                except:
                    break
            if chan in r:
                data = chan.recv(SSHTunnelManager.RX_BUFFER_SIZE)
                if len(data) == 0:
                    break
                try:
                    sock.send(data)
                except:
                    break
        chan.close()
        sock.close()
        self._uo.info('Tunnel closed from server port %d' % (serverPort))


class ForwardingServer(SocketServer.ThreadingTCPServer):
    """@brief Server responsible for ssh port forwarding"""
    daemon_threads = True
    allow_reuse_address = True


class ForwardingHandler(SocketServer.BaseRequestHandler):
    """@brief handler for ssh port forwarding connections."""

    def handle(self):
        try:
            chan = self.ssh_transport.open_channel('direct-tcpip',
                                                   (self.chain_host, self.chain_port),
                                                   self.request.getpeername())
        except Exception as e:
            self.uo.error('Incoming request to %s:%d failed: %s' % (self.chain_host,
                                                                    self.chain_port,
                                                                    repr(e)))
            return
        if chan is None:
            self.uo.error('Incoming request to %s:%d was rejected by the SSH server.' %
                          (self.chain_host, self.chain_port))
            return

        self.uo.info('Connected!  Tunnel open %r -> %r -> %r' % (self.request.getpeername(),
                                                                 chan.getpeername(), (self.chain_host, self.chain_port)))
        while True:
            r, w, x = select.select([self.request, chan], [], [])
            if self.request in r:
                data = self.request.recv(SSHTunnelManager.RX_BUFFER_SIZE)
                if len(data) == 0:
                    break
                chan.send(data)
            if chan in r:
                data = chan.recv(SSHTunnelManager.RX_BUFFER_SIZE)
                if len(data) == 0:
                    break
                self.request.send(data)

        peername = self.request.getpeername()
        chan.close()
        self.request.close()
        self.uo.info('Tunnel closed from %r' % (peername,))
