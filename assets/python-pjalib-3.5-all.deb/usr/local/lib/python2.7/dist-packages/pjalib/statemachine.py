import inspect

#A simple state machine implementation.

class StateMachineError(Exception):
  """@brief An exception that can be thrown by StateMachine instances."""
  pass

class StateMachineMethodSet(object):
    """@brief Responsible for holding references to the name of a state and the
              enter, check and exit methods for this state."""

    def __init__(self):
        """@brief Constructor"""
        self.stateName   = None
        self.enterMethod = None
        self.checkMethod = None
        self.exitMethod  = None

    def checkMethodSet(self):
        """@brief Determine if all the check method has been set.
           @return True if the check method has been set."""
        if self.checkMethod:
            return True
        return False

    def __repr__(self):
        """@brief Return the string representation of this object."""
        enterMethodName = "None"
        checkMethodName = "None"
        exitMethodName  = "None"

        if self.enterMethod:
            enterMethodName = self.enterMethod.__name__

        if self.checkMethod:
            checkMethodName = self.checkMethod.__name__

        if self.exitMethod:
            exitMethodName = self.exitMethod.__name__

        return "ENTER: %s, CHECK: %s, EXIT: %s" % (enterMethodName, checkMethodName, exitMethodName)

class StateMachine(object):
    """@brief A simple state machine that uses the method on a controller object
      to define the state transitions."""

    STATE_METHOD_SEPARATOR  = "_"
    ENTER_STATE_NAME        = "Enter"
    CHECK_STATE_NAME        = "Check"
    EXIT_STATE_NAME         = "Exit"
    INITIAL_STATE_METHOD    = "initialStateMethod"

    def __init__(self, controller, uo):
        """@brief Constructor
           @param controller This is an instance of an object that contains
                  methods that are executed to enter, exit and check each
                  state.
                  the entry, check and exit method names must end with
                  _Enter, _Check and _Exit respectively.
                  If the controller object defines a shutDown() method then this
                  will be called on statemachine exit. 
           @param uo A UserOutput implementation. This only needs to implement 
                     a debug method accepting one string argument."""
        self._controller        = controller
        self._uo                = uo
        self._orderedMethodList =  None
        self._nextStateMethod   = None
        self._loadStates()

    def _getNewStateMachineMethodSet(self, stateName):
        """@brief Get a StateMachineMethodSet instance for the given stateName.
           @param stateName The name of the state."""

        stateMachineMethodSet = StateMachineMethodSet()

        memberList = inspect.getmembers(self._controller, predicate=inspect.ismethod)
        for member in memberList:
            methodName = member[0]
            method     = member[1]

            enterStateMethodName = "%s%s%s" % (stateName, StateMachine.STATE_METHOD_SEPARATOR, StateMachine.ENTER_STATE_NAME)
            checkStateMethodName = "%s%s%s" % (stateName, StateMachine.STATE_METHOD_SEPARATOR, StateMachine.CHECK_STATE_NAME)
            exitStateMethodName  = "%s%s%s" % (stateName, StateMachine.STATE_METHOD_SEPARATOR, StateMachine.EXIT_STATE_NAME)

            if methodName == enterStateMethodName:
                stateMachineMethodSet.stateName=stateName
                stateMachineMethodSet.enterMethod = method

            elif methodName == checkStateMethodName:
                stateMachineMethodSet.stateName=stateName
                stateMachineMethodSet.checkMethod = method

            elif methodName == exitStateMethodName:
                stateMachineMethodSet.stateName=stateName
                stateMachineMethodSet.exitMethod = method

        #We need at least the check method for the state to be valid.
        if stateMachineMethodSet.checkMethodSet():
            return stateMachineMethodSet
        else:
            return None

    def _getStateNameList(self):
        """@brief Get a list of state names.
                  These ate defined by the methods on the controller class."""
        stateNameList = []
        memberList = inspect.getmembers(self._controller, predicate=inspect.ismethod)
        for member in memberList:
            methodName = member[0]
            if methodName.endswith("%s%s" % (StateMachine.STATE_METHOD_SEPARATOR, StateMachine.ENTER_STATE_NAME) ) or\
               methodName.endswith("%s%s" % (StateMachine.STATE_METHOD_SEPARATOR, StateMachine.CHECK_STATE_NAME) ) or\
               methodName.endswith("%s%s" % (StateMachine.STATE_METHOD_SEPARATOR, StateMachine.EXIT_STATE_NAME) ):
               
                elems = methodName.split(StateMachine.STATE_METHOD_SEPARATOR)
                if len(elems) == 2:
                    stateName = elems[0]
                    if stateName not in stateNameList:
                        stateNameList.append(stateName)

        return stateNameList

    def _ensureInitialState(self):
        """@brief Ensure that we have an attribute on the controller class that
                  defines the initial state method."""
        foundInitialStateMethod = False
        attributeDict = self._controller.__dict__
        for attribute in attributeDict.keys():
            if attribute == StateMachine.INITIAL_STATE_METHOD:
                if not self._controller.initialStateMethod:
                    raise StateMachineError("The controller class has not set the %s attribute." % (StateMachine.INITIAL_STATE_METHOD) )

            foundInitialStateMethod = True

        if not foundInitialStateMethod:
            raise StateMachineError("The controller class does not define the %s attribute." % (StateMachine.INITIAL_STATE_METHOD) )

    def _loadStates(self):
        """@brief Load the states defined by the methods in the controller class."""
        self._stateDict = {}

        self._ensureInitialState()

        stateNameList = self._getStateNameList()

        for stateName in stateNameList:
            stateMachineMethodSet = self._getNewStateMachineMethodSet(stateName)
            if stateMachineMethodSet:
                self._stateDict[stateName]=stateMachineMethodSet
            else:
                break

        if len(self._stateDict.keys()) == 0:
            raise StateMachineError("The controller class does not implement the required state machine methods." )

    def logStates(self):
        """@brief Log the available states.
                  This log will show the entry, check and exit methods for each defined state."""
        for stateName in self._stateDict.keys():
            self._uo.debug( str(self._stateDict[stateName]) )

    def _getStateMachineMethodSet(self, stateName):
        """@brief Get the StateMachineMethodSet instance associated with the state.
           @param stateName the name of a state."""
        return self._stateDict[stateName]

    def _executeMethod(self, currentStateMethod):
        """@brief Execute a state entry, check or exit method method
           @param currentStateMethod The method to be executed."""

        #Decide what method should be executed next
        methodName = currentStateMethod.__name__
        stateName, methodType = methodName.split(StateMachine.STATE_METHOD_SEPARATOR)

        self._uo.debug( 'Calling : %s.%s()' % (self._controller.__class__.__name__, methodName) )

        nextStateMethod = currentStateMethod()

        #If we have just executed a check state method but have no next state
        if methodType == StateMachine.CHECK_STATE_NAME:

            if not nextStateMethod:
                return nextStateMethod

            self._nextStateMethod = nextStateMethod

        stateMachineMethodSet = self._getStateMachineMethodSet(stateName)

        #If we've just executed a state entry method then we must
        #always execute the check state method.
        if methodType == StateMachine.ENTER_STATE_NAME:
            return stateMachineMethodSet.checkMethod

        #If we've just executed the check state method
        elif methodType == StateMachine.CHECK_STATE_NAME:

            #If we have a state exit method then this will be the next executed.
            if stateMachineMethodSet.exitMethod:
                return stateMachineMethodSet.exitMethod
            else:
                return self._nextStateMethod

        #If we've just executed an exit state method move onto the next state.
        elif methodType == StateMachine.EXIT_STATE_NAME:

            #Failing this execute the method returned from the method just called.
            return self._nextStateMethod

    def run(self):
        """@brief Run the state machine and block until exit."""

        currentStateMethod = self._controller.initialStateMethod

        try:
            
            while True:
    
                currentStateMethod = self._executeMethod(currentStateMethod)
    
                if not currentStateMethod:
                    break
            
        finally:
            if hasattr(self._controller, 'shutDown'):
                self._controller.shutDown()
            
            
            