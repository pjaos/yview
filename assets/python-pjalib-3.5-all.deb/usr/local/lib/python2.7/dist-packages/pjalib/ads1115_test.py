#!/usr/bin/env python

from    time import sleep, time

from ads1115 import ADS1115ADC

def measureVolts():
    CODES_PER_VOLT = 2209

    ads1115ADC = ADS1115ADC(ADS1115ADC.ADDR_PIN_LOW_SLAVE_ADDR)

    fsVoltage = 4.096
    samplesPerSecond = 860

    ads1115ADC.setADC0(fsVoltage, samplesPerSecond)
    ads1115ADC.setADC1(fsVoltage, samplesPerSecond)
    ads1115ADC.setADC2(fsVoltage, samplesPerSecond)
    ads1115ADC.setADC3(fsVoltage, samplesPerSecond)
    minValue = 1E6
    maxValue = 1E-6
    while True:
        startTime=time()
        #value = ads1115ADC.getADC3(singleEnded=False)
        value = ads1115ADC.getADC2(singleEnded=True)

        #if value > maxValue:
        #    maxValue=value
        #if value < minValue:
        #    minValue=value
        #print 'PJA: value = 0x%02x (max=%d, min=%d, delta=%d) to %f seconds' % (value, maxValue, minValue, maxValue-minValue, time()-startTime)

        if value <= 32767:
            volts = float(value)/CODES_PER_VOLT
            print 'PJA: value = %f' % (volts)

        sleep(0.1)

def measureAmps():

    NO_CURRENT_CODES = 31686
    CODES_PER_AMP = 785
    ads1115ADC = ADS1115ADC(ADS1115ADC.ADDR_PIN_LOW_SLAVE_ADDR)

    fsVoltage = 2.048
    samplesPerSecond = 860

    ads1115ADC.setADC0(fsVoltage, samplesPerSecond)
    ads1115ADC.setADC1(fsVoltage, samplesPerSecond)
    ads1115ADC.setADC2(fsVoltage, samplesPerSecond)
    ads1115ADC.setADC3(fsVoltage, samplesPerSecond)
    minValue = 1E6
    maxValue = 1E-6
    while True:
        startTime=time()

        value = ads1115ADC.getADC0(singleEnded=True)
        #value = ads1115ADC.getADC0(singleEnded=False)

        #if value > maxValue:
        #    maxValue=value
        #if value < minValue:
        #    minValue=value
        #print 'PJA: value = 0x%02x (max=%d, min=%d, delta=%d) to %f seconds' % (value, maxValue, minValue, maxValue-minValue, time()-startTime)

        codes = NO_CURRENT_CODES-value
        amps = float(codes)/CODES_PER_AMP
        print 'PJA: value = %f' % (amps)

        sleep(0.1)

def measureVoltsAmpsPower():

    CODES_PER_VOLT = 2209
    NO_CURRENT_CODES = 31686
    CODES_PER_AMP = 785
    ads1115ADC = ADS1115ADC(ADS1115ADC.ADDR_PIN_LOW_SLAVE_ADDR, simulateHardware=False)

    voltsRefVoltage = 4.096
    ampsRefVoltage = 2.048
    samplesPerSecond = 860

    ads1115ADC.setADC0(ampsRefVoltage, samplesPerSecond)
    ads1115ADC.setADC2(voltsRefVoltage, samplesPerSecond)
    minValue = 1E6
    maxValue = 1E-6
    while True:
        startTime=time()


        voltCodes = ads1115ADC.getADC2(singleEnded=True)
        if voltCodes > 32767:
            voltCodes=0

        ampCodes = NO_CURRENT_CODES-ads1115ADC.getADC0(singleEnded=True)

        volts = float(voltCodes)/CODES_PER_VOLT
        amps = float(ampCodes)/CODES_PER_AMP

        print 'PJA: volts=%f,amps=%f,watts=%f' % (volts, amps, volts*amps)

        sleep(0.1)
        
        
def _measureVolts():
    CODES_PER_VOLT = 7989
    fsVoltage = 4.096
    
    #CODES_PER_VOLT = 7989*2
    #fsVoltage = 2.048

    ads1115ADC = ADS1115ADC(ADS1115ADC.ADDR_PIN_LOW_SLAVE_ADDR)
    
    samplesPerSecond = 860
    ads1115ADC.setADC0(fsVoltage, samplesPerSecond)

    while True:
        startTime=time()
        value = ads1115ADC.getADC0(singleEnded=True)

        volts = float(value)/CODES_PER_VOLT
        print 'PJA: %f volts (%d)' % (volts, value)

        sleep(1)

def readADC0():
    
    ads1115ADC = ADS1115ADC(ADS1115ADC.ADDR_PIN_LOW_SLAVE_ADDR, simulateHardware=False)

    refVoltage = 4.096
    samplesPerSecond = 8
    ads1115ADC.setADC0(refVoltage, samplesPerSecond)
    while True:
        startTime=time()

        codes = ads1115ADC.getADC0(singleEnded=True)
        print 'PJA: codes=',codes

        sleep(1)
        
def readAllADCS():

    ads1115ADC = ADS1115ADC(ADS1115ADC.ADDR_PIN_LOW_SLAVE_ADDR, simulateHardware=False)

    refVoltage = 4.096
    samplesPerSecond = 8
    ads1115ADC.setADC0(refVoltage, samplesPerSecond)
    ads1115ADC.setADC1(refVoltage, samplesPerSecond)
    ads1115ADC.setADC2(refVoltage, samplesPerSecond)
    ads1115ADC.setADC3(refVoltage, samplesPerSecond)
    while True:

        adc0Codes = ads1115ADC.getADC0(singleEnded=True)
        adc1Codes = ads1115ADC.getADC0(singleEnded=True)
        adc2Codes = ads1115ADC.getADC0(singleEnded=True)
        adc3Codes = ads1115ADC.getADC0(singleEnded=True)
        
        print 'PJA: adc0Codes=',adc0Codes
        print 'PJA: adc1Codes=',adc1Codes
        print 'PJA: adc2Codes=',adc2Codes
        print 'PJA: adc3Codes=',adc3Codes

        sleep(1)

        
if __name__== '__main__':
    #measureVolts()
    #measureAmps()
    #measureVoltsAmpsPower()
    #readADC0()
    #_measureVolts()
    readAllADCS()
    
    #