#!/usr/bin/env python
################################################################################
# 
# Copyright (c) 2010, Paul Austen. All rights reserved.
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301  USA
#
################################################################################

from subprocess import Popen,PIPE
import threading
from time import time, sleep
import os
import types
import select

class ExecutionerError(Exception):
  pass

class Executioner(threading.Thread):
  """Responsible for executing a system command"""
  def __init__(self, cmdArgList=None, uo=None, stdoutCallBack=None):  
    """Responsible for running a system command.
       You may call the run() method directly if you wish the system command to
       run in the curtrent thread and block it's execution.
       If you wish the system command to be executed in a separated thread and 
       not block the current thread then cann the start() method on this object.
       If the command is executed in a separate thread then 
         - The isComplete() method may be called in order to determine if the 
           command is complete/has exited.
         - The getPID() method may be called in order to get the process ID of
           the running command.
       After the command has completed you may call getException() to get the
       exception generated when the command was executed. This will be None if 
       no exception occured.
       uo may be any object that implements the infpPrint(text) method and may 
       be used to display output from long running processes.  
       If stdoutCallBack is defined then stdoutCallBack(line) will be called 
       when lines of text are recived from the progrma being executed.
    """
    threading.Thread.__init__(self)
    self._cmdArgList=cmdArgList
    self._uo=uo
    self._cmdComplete=False
    self._exception=None
    self._pid=None
    self._returncode=-1
    self._stdoutdata=None
    self._stderrdata=None
    self._process=None
    
    self._stdoutLineslock = threading.Lock()
    self._stdoutLines=[]
    self.stdoutLineIndex=0
    self.stdoutCallBack=stdoutCallBack

    self._stderrLineslock = threading.Lock()
    self._stderrLines=[]

  def run(self):
    try:
      try:
        if len(self._cmdArgList) == 0:
          raise ExecutionerError("The command list is empty, no program to run.")
        shell=False
        if type(self._cmdArgList) == types.StringType:
          shell=True
        self._process = Popen(self._cmdArgList, stdout=PIPE, stderr=PIPE, shell=shell)
        self._pid=self._process.pid
          
        inputFDS=[self._process.stdout, self._process.stderr]
        while self._process.poll() == None:
          inputready, _, _ = select.select(inputFDS, [], [], 2.0)
          for fd in inputready:
            if fd == self._process.stdout:
              #Read from stdout into a buffer
              l = self._process.stdout.readline()
              if len(l) > 0:
                self._stdoutLineslock.acquire()
                self._stdoutLines.append(l)
                self._stdoutLineslock.release()
                
                if self._uo != None:
                  self._uo.infoPrint(l)
                  
                if self.stdoutCallBack != None:
                  self.stdoutCallBack(l)
                  
            if fd == self._process.stderr:
              l = self._process.stderr.readline()       
              if len(l) > 0:
                #Remove EOL from the line
                l=l.rstrip('\r')
                l=l.rstrip('\n')
                self._stderrLineslock.acquire()
                self._stderrLines.append(l)
                self._stderrLineslock.release()
                
                if self._uo != None:
                  self._uo.errorPrint(l)
                  
                if self.stdoutCallBack != None:
                  self.stdoutCallBack(l)
              
        self._returncode = self._process.returncode
      except Exception as ex:
        self._exception=ex
    finally:
      self._cmdComplete=True

  def isComplete(self):
    """Returns true when the command is complete."""
    return self._cmdComplete
    
  def getPID(self):
    """Return the process ID of the running process"""
    return self._pid
    
  def getException(self):
    """Return Exception generated during the execution of the command.
       Returns None if no Exception occured."""
    return self._exception
    
  def getReturnCode(self):
    """Get the return code. Must be called when the command has completed and
       will only be set if no exception has been generated."""
    return self._returncode
    
  def getStdoutLines(self):
    """Get the lines of text from stdout. 
       This can be called while the process is running to read the data from 
       stdout. You may not get all the data from the process while the process
       is running. Once the process has finished running all the text output
       by the program will be available."""
    self._stdoutLineslock.acquire()
    if not self._cmdComplete:
      #Read from the current location to the end of the buffer
      lines = tuple( self._stdoutLines[self.stdoutLineIndex:] )
      self.stdoutLineIndex=len(self._stdoutLines)
    else:
      #Read all the data from the process into the buffer
      while self._process != None:
        l = self._process.stdout.readline()
        if len(l) > 0:
          self._stdoutLines.append(l)
        else:
          break
      #Create a buffer from the lines of text
      lines = tuple(self._stdoutLines)
    self._stdoutLineslock.release()
    return lines
    
  def getStderrLines(self):
    """Get the lines of text from stderr. This should be called when the process
       has stopped."""
    self._stdoutLineslock.acquire()
    
    stderrLines=[]
    while self._process != None:
      #Read from stdout into a buffer
      l = self._process.stderr.readline()
      if len(l) > 0:
        stderrLines.append(l)
      else:
        break
    self._stdoutLineslock.release()
    
    return self._stderrLines + stderrLines
    
  def getStdoutData(self):
    """As getStdoutLines() but a single string is returned, rather than a list
       of lines of text."""
    return "".join(self.getStdoutLines())
    
  def getStderrData(self):
    """As getStderrLines() but a single string is returned, rather than a list
       of lines of text."""    
    return "".join(self.getStderrLines())
    
  def runCmd(self, cmd, mustSucceed, stdoutCallBack):
    """This blocking method can be used to execute a cmd. It is included for 
       compatability with the previous Executioner implementation.
       If mustSucceed == True then an ExecutionerError is raised if the command
                        does not return an error code of 0.
       If stdoutCallBack is not None then stdoutCallBack(line) will be called
       as lines of text are sent to stdout.

       Returns a tuple with the following elements
       0 = The return code from the executed cmd
       1 = A list of lines of text output by the cmd, This includes stdout and stderr. 
           stderr lines are appended to the stdout lines.
    """
    #self._setCmdArgListFromString(cmd)
    self._cmdArgList=cmd
    self.stdoutCallBack=stdoutCallBack
    self.run()
    if mustSucceed and self._returncode != 0:
      raise ExecutionerError("The command (%s) returned an error code of %d" % (repr(self._cmdArgList), self._returncode ) )

    lines = list(self.getStdoutLines()) + self.getStderrLines() 
    return (self._returncode, lines )

