#!/usr/bin/python
################################################################################
# 
# Copyright (c) 2010, Paul Austen. All rights reserved.
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301  USA
#
################################################################################

# Allow simple emails to be sent.

import smtplib
from   email.MIMEMultipart import MIMEMultipart
from   email.MIMEBase import MIMEBase
from   email.MIMEText import MIMEText
from   email.Utils import COMMASPACE, formatdate
from   email import Encoders
from   email.MIMEImage import MIMEImage
from   email.MIMEAudio import MIMEAudio
import mimetypes
import os
import os.path
 
class SendMailException(Exception):
  """An exceptiuon class for errors sending an email
  """
  pass

# Ported from Recipe 3.9 in Secure Programming Cookbook for C and C++ by
# John Viega and Matt Messier (O'Reilly 2003)

from string import *

rfc822_specials = '()<>@,;:\\"[]'

def charsOK(email_part):
  """Check an email part (name or domain for invalid characters"""
  for c in email_part:
    if c in rfc822_specials:
      return False
  return True

def isAddressValid(addr):
  """Check an email is valid, Returns True if it is"""
  addressValid=False
  elems = addr.split('@')
  if len(elems) == 2:
    name = elems[0]
    domain = elems[1]
    if len(name) > 0 and len(domain) > 0 and charsOK(name) and charsOK(domain):
      addressValid=True
  return addressValid

import smtplib

def sendMail(to, fro, subject, bodyText, server, files=[], debug=False, username=None, password=None, port=25, sslTLS=False, html=False):
  """   
        Send an email via an smtp server

        @param to:       A List of strings of email addresses (no default)
        @param fro:      The email address of the sender (no default)
        @param subject:  The subject line text (no default)
        @param bodyText: The text of the body of the email (no default
        @param server:   The email (smtp) server (no default)
        @param files:    A list of files to attach to the email (default empty list)
        @param debug:    If True then set smtp server to debug mode (default False)
        @param username: The username to login to the server (default None, server login not required)
        @param password: The password to login to the server (default None, server login not required)
        @param port:     The TCP port number to connect to the server (default 25)
        @param sslTLS:   If True the SSL TLS connection security is used (default False)
        @param html:     If True the message is send with html body text. IF False then plain text is sent as the message body. (default False)
        
  """
  # Create the enclosing (outer) message
  outer = MIMEMultipart('alternative')
  outer['Subject'] = subject
  outer['To'] = COMMASPACE.join(to)
  outer['From'] = fro
  outer.preamble = 'You will not see this in a MIME-aware mail reader.\n'
  # To guarantee the message ends with a newline
  outer.epilogue = ''

  #Send html if required
  if html:
    outer.attach( MIMEText(bodyText,'html') )
  else:
    outer.attach( MIMEText(bodyText,'text') )

  for filename in files:
    path=filename
    #If the file does not exist
    if not os.path.isfile(path):
      raise SendMailException("%s file not found. Unable to email it." % (path) )
    # Guess the content type based on the file's extension.  Encoding
    # will be ignored, although we should check for simple things like
    # gzip'd or compressed files.
    ctype, encoding = mimetypes.guess_type(path)
    if ctype is None or encoding is not None:
      # No guess could be made, or the file is encoded (compressed), so
      # use a generic bag-of-bits type.
      ctype = 'application/octet-stream'
    maintype, subtype = ctype.split('/', 1)
    if maintype == 'text':
      fp = open(path)
      # Note: we should handle calculating the charset
      msg = MIMEText(fp.read(), _subtype=subtype)
      fp.close()
    elif maintype == 'image':
      fp = open(path, 'rb')
      msg = MIMEImage(fp.read(), _subtype=subtype)
      fp.close()
    elif maintype == 'audio':
      fp = open(path, 'rb')
      msg = MIMEAudio(fp.read(), _subtype=subtype)
      fp.close()
    else:
      fp = open(path, 'rb')
      msg = MIMEBase(maintype, subtype)
      msg.set_payload(fp.read())
      fp.close()
      # Encode the payload using Base64
      Encoders.encode_base64(msg)
    #Set the filename parameter
    msg.add_header('Content-Disposition', 'attachment', filename=filename)
    outer.attach(msg)
  # Now send the message
  s = smtplib.SMTP(server, port)
  #If debugging required then set the debug level
  if debug > 0:
    s.set_debuglevel(1)
  if sslTLS:
    s.ehlo()
    s.starttls()
    s.ehlo()

  #If a username and password were supplied, use them to login to the server
  if username != None and password != None:
    s.login(username,password)
  s.sendmail(fro, to, outer.as_string())
  s.close()



def example():
  """An example of how to use this module
  """
  to=["youthere@isp.com","andyouthere@isp.com"]
  fro="mehere@isp.com"
  server="smtp.isp.com"
  filesToSend=["file1.txt","file2.txt","file3.bin"]
  print "Sending email to %s" % (to) 
  sendMail(
        to,
        fro,
        "The subject line of the email" ,
        "The body text of the email",
        server,
        files=filesToSend
  )
  print "Finished"


