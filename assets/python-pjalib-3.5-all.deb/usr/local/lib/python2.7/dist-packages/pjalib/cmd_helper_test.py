#!/usr/bin/env python

import  platform
from cmd_helper import *

#-------------------------------------------------------------------------------
#Unit test functions
# Note that to validate this code the unit tests should be run on
# Linux and windows separetley as they have different code paths.
#
import unittest

class CMDHelperTestFunctions(unittest.TestCase):

  def isWindows(self):
    """We test differently on Windows to other platforms because we have to"""
    if platform.system() == "Windows":
      return True
    return False

  def setUp(self):
    pass

  def test1_checkSetHomePath(self):
    """Check that we can instantiate the FSM class"""
    if self.isWindows():
      setHomePath("c:\\windows")
      self.assertTrue( os.environ["HOMEDRIVE"] == 'C:' )
      self.assertTrue( os.environ["HOMEPATH"] == '\\windows' )
      self.assertTrue( os.environ["HOME"] == '/c/windows' )
    else:
      setHomePath("/tmp")
      self.assertTrue( os.environ["HOME"] == '/tmp' )

  def test2_checkSetHomePath(self):
    """Check that if the home path is not found, then an error is generated."""
    with self.assertRaises(HomePathError):
      setHomePath("/adirthatdoesnotexist")

#Run the unit tests
if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(CMDHelperTestFunctions)
    unittest.TextTestRunner(verbosity=2).run(suite)


