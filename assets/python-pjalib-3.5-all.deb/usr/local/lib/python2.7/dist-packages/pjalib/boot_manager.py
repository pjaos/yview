#!/usr/bin/env python

import os
import sys
import platform

class BootManagerError(Exception):
    pass

class BootManager(object):
    """Responsible for adding and removing startup processes when the computer boots.
       Currently supports the following platforms
       Linux"""

    LINUX_OS_NAME = "Linux"
            
    def __init__(self, uio=None):
        """@brief Constructor
           @param uio A UIO instance to display user output. If unset then no output is displayed to user."""
        self._uio = uio
        self._osName = platform.system()
        self._platformBootManager = None
        
        if self._osName == BootManager.LINUX_OS_NAME:
            self._platformBootManager = LinuxBootManager(uio)
            
        else:
            raise BootManagerError("%s is an unsupported OS." % (self._osName) )
            
    def add(self, user="root"):
        """@brief Add an executable file to the processes started at boot time.
           @param exeFile The file/program to be executed. This should be an absolute path.
           @param user The Linux user that will run the executable file."""
        if self._platformBootManager:
            self._platformBootManager.add(user)

    def remove(self):
        """@brief Remove an executable file to the processes started at boot time.
           @param exeFile The file/program to be removed. This should be an absolute path.
           @param user The Linux user that will run the executable file."""
        if self._platformBootManager:
            self._platformBootManager.remove()

class LinuxBootManager(object):
    """Responsible for adding and removing startup processes when the computer boots
       that is running the Linux opperating system."""
    LOG_PATH="/var/log"
    LINUX_OS_NAME = "Linux"
    PROVIDES = "# Provides:          "
    SHORT_DESCRIPTION = "# Short-Description: "
    DESCRIPTION = "# Description:       "
    WORKING_DIR = "dir="
    CMD = "cmd="
    USER = "user="
    INITD_FOLDER = "/etc/init.d"
    ETC_INITD_TEMPLATE_LINES = [\
"#!/bin/sh",
"### BEGIN INIT INFO",
"%s" % (PROVIDES),
"# Required-Start:    $remote_fs $syslog",
"# Required-Stop:     $remote_fs $syslog",
"# Default-Start:     2 3 4 5",
"# Default-Stop:      0 1 6",
"%s" % (SHORT_DESCRIPTION),
"%s" % (DESCRIPTION) ,
"### END INIT INFO",
"",
"%s" % (WORKING_DIR) ,
"%s" % (CMD),
"%s" % (USER),
"",
"name=`basename $0`",
"pid_file=\"/var/run/$name.pid\"",
"stdout_log=\"/var/log/$name.log\"",
"stderr_log=\"/var/log/$name.err\"",
"",
"get_pid() {",
"    cat \"$pid_file\"",
"}",
"",
"is_running() {",
"    [ -f \"$pid_file\" ] && ps -p `get_pid` > /dev/null 2>&1",
"}",
"",
"case \"$1\" in",
"    start)",
"    if is_running; then",
"        echo \"Already started\"",
"    else",
"        echo \"Starting $name\"",
"        cd \"$dir\"",
"        if [ -z \"$user\" ]; then",
"            sudo $cmd >> \"$stdout_log\" 2>> \"$stderr_log\" &",
"        else",
"            sudo -u \"$user\" $cmd >> \"$stdout_log\" 2>> \"$stderr_log\" &",
"        fi\n",
"        echo $! > \"$pid_file\"",
"        if ! is_running; then",
"            echo \"Unable to start, see $stdout_log and $stderr_log\"",
"            exit 1",
"        fi",
"    fi",
"    ;;",
"    stop)",
"    if is_running; then",
"        echo -n \"Stopping $name..\"",
"        kill `get_pid`",
"        for i in 1 2 3 4 5 6 7 8 9 10",
"        do",
"            if ! is_running; then",
"                break",
"            fi",
"",
"            echo -n \".\"",
"            sleep 1",
"        done",
"        echo",
"",
"        if is_running; then",
"            echo \"Not stopped; may still be shutting down or shutdown may have failed\"",
"            exit 1",
"        else",
"            echo \"Stopped\"",
"            if [ -f \"$pid_file\" ]; then",
"                rm \"$pid_file\"",
"            fi",
"        fi",
"    else",
"        echo \"Not running\"",
"    fi",
"    ;;",
"    restart)",
"    $0 stop",
"    if is_running; then",
"        echo \"Unable to stop, will not attempt to start\"",
"        exit 1",
"    fi",
"    $0 start",
"    ;;",
"    status)",
"    if is_running; then",
"        echo \"Running\"",
"    else",
"        echo \"Stopped\"",
"        exit 1",
"    fi",
"    ;;",
"    *)",
"    echo \"Usage: $0 {start|stop|restart|status}\"",
"    exit 1",
"    ;;",
"esac",
"",
"exit 0"]

    def __init__(self, uio):
        """@brief Constructor
           @param uio A UIO instance to display user output. If unset then no output is displayed to user."""
        self._uio = uio
        self._logFile = None

        if os.geteuid() != 0:
            self._fatalError("Please run this command with root level access.")
            
        if not os.path.isdir(LinuxBootManager.LOG_PATH):
            self._fatalError("%s path not found" % (LinuxBootManager.LOG_PATH) )

        self._info("OS: %s" % (platform.system()) )
        
    def _getPaths(self):
        """@brief Get a list of the paths from the PATH env var.
           @return A list of paths or None if PATH env var not found."""
        pathEnvVar = os.getenv("PATH")
        envPaths = pathEnvVar.split(os.pathsep)
        return envPaths
        
    def _getInstallledStartupScript(self):
        """@brief Get the startup script full path. The startup script must be
                  named the same as the python file executed without the .py suffix.
           @return The startup script file (absolute path)."""""
        startupScript=None
        pythonFile = sys.argv[0] #The python file excuted at program startup
        if pythonFile.startswith("./"):
            pythonFile=pythonFile[2:]
        if pythonFile.endswith(".py"):
            pythonFile=pythonFile[:-3]
            
        envPaths = self._getPaths()
        
        if envPaths and len(envPaths) > 0:
            for envPath in envPaths:
                _startupScript = os.path.join(envPath, pythonFile)
                if os.path.isfile(_startupScript):
                    startupScript=_startupScript
                    break
                
        if not startupScript:
            paths = self._getPaths()
            if len(paths):
                for _path in paths:
                    self._info(_path)
                self._fatalError("%s startup script not found using the PATH env var." % (sys.argv[0]) )
            else:
                self._fatalError("No PATH env var found.")
                        
        return startupScript
            
    def add(self, user="root"):
        """@brief Add an executable file to the processes started at boot time.
                  This will also start the process. The executable file must be
                  named the same as the python file executed without the .py suffix.
           @param user The Linux user that will run the executable file."""
        exeFile = self._getInstallledStartupScript()         
        exePath = os.path.dirname(exeFile)
        if len(exePath) == 0:
            self._fatalError("%s is invalid as executable path is undefined." % (exeFile) )
        
        exeFilename = os.path.basename(exeFile)
        if len(exeFilename) == 0:
            self._fatalError("%s is invalid as executable filename is undefined." % (exeFile) )
        self._logFile = os.path.join(LinuxBootManager.LOG_PATH, exeFilename)

        absExeFilename = os.path.join(exePath, exeFilename)
        if not os.path.isfile( absExeFilename ):
            self._fatalError("%s file not found." % (absExeFilename) )

        startupScript = os.path.join(LinuxBootManager.INITD_FOLDER, exeFilename)
        if os.path.isfile(startupScript):
            self._fatalError("%s already exists" % (startupScript) )
                        
        outputLines = []
        for line in LinuxBootManager.ETC_INITD_TEMPLATE_LINES:

            if line == LinuxBootManager.PROVIDES:
                outputLines.append("%s%s" % (LinuxBootManager.PROVIDES, exeFilename) )
                
            elif line == LinuxBootManager.SHORT_DESCRIPTION:
                outputLines.append("%sStart %s daemon at boot time." % (LinuxBootManager.SHORT_DESCRIPTION, exeFilename) )

            elif line == LinuxBootManager.DESCRIPTION:
                outputLines.append("%sStart %s daemon at boot time." % (LinuxBootManager.DESCRIPTION, exeFilename) )

            elif line == LinuxBootManager.WORKING_DIR:
                outputLines.append("%s%s" % (LinuxBootManager.WORKING_DIR, exePath) )
                
            elif line == LinuxBootManager.CMD:
                outputLines.append("%s%s" % (LinuxBootManager.CMD, exeFilename) )
                
            elif line == LinuxBootManager.USER:
                outputLines.append("%s%s" % (LinuxBootManager.USER, user) )
                
            else:
                outputLines.append(line)

        try:
            fd = open(startupScript, 'w')
            fd.write( "\n".join(outputLines) )
            fd.close()
            self._info("Created %s" % (LinuxBootManager.INITD_FOLDER) )
        except IOError:
            self._fatalError("Failed to create %s" % (startupScript) )
                    
        cmd = "chmod +x %s" % (startupScript)
        self._runLocalCmd(cmd)
        cmd = "cd %s && update-rc.d %s defaults" % (LinuxBootManager.INITD_FOLDER, exeFilename)
        self._runLocalCmd(cmd)
        cmd = "cd %s && update-rc.d %s enable" % (LinuxBootManager.INITD_FOLDER, exeFilename)
        self._runLocalCmd(cmd)
        cmd="%s restart" % (startupScript)
        self._runLocalCmd(cmd)
            
    def remove(self):
        """@brief Remove the executable file to the processes started at boot time.
                  Any running processes will be stopped.  The executable file must be
                  named the same as the python file executed without the .py suffix."""
        exeFile = self._getInstallledStartupScript()
        exeFilename = os.path.basename(exeFile)
        startupScript = os.path.join(LinuxBootManager.INITD_FOLDER, exeFilename)
        if not os.path.isfile(startupScript):
            self._fatalError("%s is not installed." % (exeFilename) )
            
        cmd = "%s status" % (startupScript)
        rc = os.system(cmd)
        if rc == 0:
            cmd = "%s stop" % (startupScript)
            self._runLocalCmd(cmd)
            
        cmd = "cd %s && update-rc.d %s disable" % (LinuxBootManager.INITD_FOLDER, exeFilename)
        self._runLocalCmd(cmd)
        try:
            os.remove(startupScript)
        except IOError:
                self._fatalError("Failed to remove %s file." % (startupScript) )

    def _fatalError(self, msg):
        """@brief Record a fatal error.
           @param msg The message detailing the error."""
        self._error(msg)
        raise BootManagerError(msg)
    
    def _info(self, msg):
        """@brief Display an info level message to the user
           @param msg The message to be displayed."""
        self._log(msg)
        if self._uio:
            self._uio.info(msg)
            
    def _error(self, msg):
        """@brief Display an error level message to the user
           @param msg The message to be displayed."""
        self._log(msg)
        if self._uio:
            self._uio.error(msg)
    
    def _log(self, msg):
        """@brief Save a message to the log file.
           @param msg The message to save"""
        if self._logFile:
            fd = open(self._logFile, 'a')
            fd.write("%s\n" % (msg) )
            fd.close()

    def _runLocalCmd(self, cmd):
        """@brief Run a command
           @param cmd The command to run.
           @return The return code of the external cmd."""
        self._info("Running: %s" % (cmd) )
        rc = os.system(cmd)
        if rc != 0:
            self._fatalError("''%s' command failed" % (cmd) )
        return rc

#Example test code
#The /usr/local/bin/hw_loop script contents is
##!/bin/sh
#
#while [ 1 ]
#do
#	sleep 123
#done
# The python code to test adding/removing the above hw_loop program
#if __name__ == '__main__':
#    from uio import UIO
#    uio = UIO()
#    bootManager = BootManager(uio)
#    #bootManager.add("/usr/local/bin/hw_loop", user="pja")
#    bootManager.remove("/usr/local/bin/hw_loop")