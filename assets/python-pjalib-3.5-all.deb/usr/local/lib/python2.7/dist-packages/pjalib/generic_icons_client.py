import  os
import  socket
from    struct import pack, unpack
import  json
from    time import sleep
import  traceback
from    pjalib.ssh import SSH, SSHTunnelManager

class GenericIconsClientError(Exception):
  pass

class IconServerOptions(object):
    """@brief Responsible for holding the server options."""

    DEFAULT_SSH_PORT    =   22
    ICON_SERVER_PORT    = 8737
    JSON_NO_LOCATION    = "NO_LOCATION"

    def __init__(self):
        self.server             = None
        self.sshServerPort      = IconServerOptions.DEFAULT_SSH_PORT
        self.username           = None
        self.private_key        = None
        self.compression        = True
        self.reconnectPeriod    = 5
        self.debug              = False
        self.icons_port         = IconServerOptions.ICON_SERVER_PORT
        self.location           = IconServerOptions.JSON_NO_LOCATION
        self.rxTimeoutSecs      = 30

class GenericIconsClient(object):
    MAX_TCP_PORT        = 65535
    LEN_FIELD           = 4
    JSON_CMD            = "CMD"
    JSON_GET_DEVICES    = "GET_DEVICES"
    JSON_LOCATION       = "LOCATION"

    @staticmethod
    def GetHomePath():
        """Get the user home path as this will be used to store config files"""
        if os.environ.has_key("HOME"):
            return os.environ["HOME"]

        elif os.environ.has_key("HOMEDRIVE") and os.environ.has_key("HOMEPATH"):
            return os.environ["HOMEDRIVE"] + os.environ["HOMEPATH"]

        elif os.environ.has_key("USERPROFILE"):
            return os.environ["USERPROFILE"]

        return None

    @staticmethod
    def GetConfigFile(filename):
        """@brief Get the full path of a connfig file.
           @param The base filename for the config file."""
        homePath = GenericIconsClient.GetHomePath()

        if not filename.startswith("."):
            filename = "." + filename

        return os.path.join(homePath, filename)

    @staticmethod
    def GetMsgLength(request):
        """@brief Read the length of the subsequent message from the
                  request object.
                  Blocks until a message is received.
           @param request The request object passed from the handle() method."""
        d = GenericIconsClient.READ(request, GenericIconsClient.LEN_FIELD)
        s = unpack('>I', d)
        return s[0]

    @staticmethod
    def DictToJSON(aDict):
        """@brief convert a python dictionary into JSON text
           @param aDict The python dictionary to be converted
           @return The JSON text representing aDict"""
        return json.dumps(aDict)

    @staticmethod
    def JSONToDict(jsonText):
        """@brief Convert from JSON text to a python dict. Throws a ValueError
                  if the text is formatted incorrectly.
           @param jsonText The JSON text to be converted to a dict
           @return a python dict object"""
        return json.loads(jsonText)

    @staticmethod
    def READ(request, size):
        """@brief Read a number of bytes from the request object.
                  Blocks until the bytes are received is received.
           @param request The request object passed from the handle() method."""
        data = ''
        while len(data) < size:
            dataTmp = request.recv(size - len(data))
            data += dataTmp
            if dataTmp == '':
                raise RuntimeError("Socket closed")
        return data

    @staticmethod
    def RX(request):
        """@brief Get a dictionary object from a json message.
                   Blocks until a message is received.
           @param request The request object passed from the handle() method.
           @return a python dictionary object."""
        if request:
            size = GenericIconsClient.GetMsgLength(request)
            data = GenericIconsClient.READ(request, size)
            sFmt = ">%ds" % (size)
            msg = unpack(sFmt, data)
            d = GenericIconsClient.JSONToDict(msg[0])
            return d
        else:
            raise RuntimeError("RX socket error")

    @staticmethod
    def TX(request, theDict):
        """@brief Write the dict to the socket as json text
           @param request The request object passed from the handle() method.
           @theDict The python dictionary to send."""
        if request:
            msg = GenericIconsClient.DictToJSON(theDict)
            sFmt = ">%ds" % len(msg)
            bodyLen = pack('>I', len(msg))
            body = pack(sFmt, msg)
            request.send(bodyLen)
            request.send(body)
        else:
            raise RuntimeError("TX socket error")

    @staticmethod
    def TX_UDP(theDict, addressPort):
        """"@brief Send the service details to the remote host in a UDP packet.
            @param theDict, The device dict
            @param addressPort A tuple of the address and port number to send the data to."""
        msg = GenericIconsClient.DictToJSON(theDict)
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.sendto(msg, addressPort)

    @staticmethod
    def GetFreeTCPPort(startingPort=-1):
        """@brief Get a free port and return to the client. If no port is available
                  then -1 is returned.
           @return the free TCP port number or -1 if no port is available."""

        if startingPort != -1:
            tcpPort = -1
            for tcpPort in range(startingPort, GenericIconsClient.MAX_TCP_PORT + 1):
                try:
                    # Bind to a local port to find a free TTCP port
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.bind(('', tcpPort))
                    sock.close()
                    return tcpPort
                except socket.error:
                    pass

            if tcpPort == GenericIconsClient.MAX_TCP_PORT:
                raise GenericIconsClientError("No TCP port is available between %d and %d" % (startingPort, GenericIconsClient.MAX_TCP_PORT))

        else:
            # If no startingPort then get any available port.
            tcpPort = -1
            try:
                # Bind to a local port to find a free TTCP port
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.bind(('', 0))
                tcpPort = sock.getsockname()[1]
                sock.close()
            except socket.error:
                pass
            return tcpPort

    @staticmethod
    def IsPortFree(localPort):
        """@brief Determine if the local TCP port is available.
           @param localPort The TCP port
           @return True if it is free, False if not."""
        localPortFree = False
        try:
            # Bind to a local port to find a free TTCP port
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.bind(('', localPort))
            sock.close()
            localPortFree = True
        except socket.error:
            pass
        return localPortFree

    def __init__(self, uo, options):
        """@brief Constuctor
           @param uo UIO instance
           @param options ICONS src options. The following attributes
               server           The ICON (SSH) server address
               username         The ICON (SSH) server username
               private_key      The private ssh key to use for the ICON (SSH) connection
               port             The ICON (SSH) server port
               compression      True if ssh compression is used.
               reconnectPeriod  The number of seconds to wait before reconnecting to the server. If <= 0 then no reconnect attempt is made.
               debug            True if debugging is enabled.
               """
        self._uo = uo
        self._iconsOptions = options
        self._iconsClientSocket = None
        self._sshTunnelManager = None
        self._localIconsPort = GenericIconsClient.GetFreeTCPPort()

    @staticmethod
    def ReportException(uo, ex, debug):
        """@brief Report an exception. If debug is set then a stack trasce is
                  reported.
           @param ex The exception to report"""
        if debug:
            lines = traceback.format_exc().splitlines()
            for line in lines:
                uo.error(line)
        else:
            uo.error(ex)

    def runClientConnection(self):
        """@brief Called to connect to the server and handle all responses from it."""
        except_e = None
        while True:
            try:

                self._connectAndService()

            except SystemExit:
                raise

            # Don't print error information if CTRL C pressed
            except KeyboardInterrupt:
                raise

            except Exception as e:
                except_e = e

            finally:
                if except_e:
                    if self._iconsOptions.debug:
                        GenericIconsClient.ReportException(self._uo, except_e, self._iconsOptions.debug)
                    else:
                        self._uo.error(except_e)

            if self._iconsOptions.reconnectPeriod > 0:
                self._uo.error("Waiting %d seconds before attempting to reconnect to ICON server." % (self._iconsOptions.reconnectPeriod))
                sleep(self._iconsOptions.reconnectPeriod)
            else:
                break

    def _connectAndService(self):
        """@brief Connect to the ICON server and handle the connection.
           @throw GenericIconsClientError"""
        ssh = None
        try:

            if not self._iconsOptions.username:
                raise GenericIconsClientError("No ICONS username defined.")

            if not self._iconsOptions.server:
                raise GenericIconsClientError("No ICONS address defined.")

            #Build an ssh connection to the ICON server
            ssh = SSH(self._iconsOptions.server, self._iconsOptions.sshServerPort, self._iconsOptions.username, self._iconsOptions.compression, self._iconsOptions.private_key, uo=self._uo)
            ssh.connect()
            self.locaIPAddress = ssh.getLocalAddress()
            self._uo.info("Connected to ssh server %s on port %d" % (self._iconsOptions.server, self._iconsOptions.sshServerPort) )

            self._connectToICONServer(ssh)

            #Handle the connection here
            self._connected()

        finally:

            self._knownDeviceList = []

            if self._iconsClientSocket:
                self._iconsClientSocket.close()
                self._uo.info("Closed connection to ICON server on port %d" % (self._iconsOptions.sshServerPort))

            if self._sshTunnelManager:
                self._sshTunnelManager.stopAllSSHTunnels()

            if ssh:
                ssh.close()
                self._uo.info("Closed ssh connection to %s on port %d" % (self._iconsOptions.server, self._iconsOptions.sshServerPort))

            self._shutdown()

    def _connectToICONServer(self, ssh):
        """@brief Connect to the ICON server
           @param ssh The connected SSH object"""
        self._sshTunnelManager = SSHTunnelManager(self._uo, ssh, self._iconsOptions.compression)
        self._sshTunnelManager.startFwdSSHTunnel(self._localIconsPort, 'localhost', self._iconsOptions.icons_port)

        self._iconsClientSocket = socket.socket()
        self._iconsClientSocket.settimeout(self._iconsOptions.rxTimeoutSecs)
        self._uo.info("Connecting to ICON server (port %d) on ssh server" % (self._iconsOptions.icons_port))
        self._iconsClientSocket.connect(('localhost', self._localIconsPort))
        self._uo.info("Connected.")
        self._sendLocationToICONS()

    def _sendLocationToICONS(self):
        """@brief Send our location to the ICON server."""
        try:
            GenericIconsClient.TX(self._iconsClientSocket, {GenericIconsClient.JSON_LOCATION: self._iconsOptions.location})
            # The ICON server will close the connection if the location is already used.
            GenericIconsClient.RX(self._iconsClientSocket)

        except RuntimeError:
            raise GenericIconsClientError("The ICON server rejected the location (%s). It may already be used." % (self._iconsOptions.location))

    def _connected(self):
        """@brief This method is called when connected to the server.
                  It should be overridden in a subclass."""
        raise GenericIconsClientError("You need to override the _connected() method.")

    def _shutdown(self):
        """@brief Called after the ssh connection to the server has been shutodwn."""
        raise GenericIconsClientError("You need to override the _shutdown() method.")