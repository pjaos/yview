#!/usr/bin/env python
################################################################################
#
# Copyright (c) 2018, Paul Austen. All rights reserved.
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301  USA
#
################################################################################
import unittest
from pcred import Credential, CredentialError

class PCredFunctions(unittest.TestCase):

    CRED_REF = "TESTCREDENTIALS_FILE.txt"
    AUSERNAME="ausername"
    APASSWORD="apassword"

    def setUp(self):
      pass

    def testA_create(self):
        Credential()

    def testB_save(self):
        cred = Credential()
        username, password = cred.get()
        self.assertTrue( username == "" )
        self.assertTrue( password == "" )

    def testC_save(self):
        cred = Credential()
        cred.set(PCredFunctions.AUSERNAME, PCredFunctions.APASSWORD)
        cred.store(PCredFunctions.CRED_REF)

    def testD_load(self):
        cred = Credential()
        cred.set(PCredFunctions.AUSERNAME, PCredFunctions.APASSWORD)
        cred.store(PCredFunctions.CRED_REF)
        cred.load(PCredFunctions.CRED_REF)
        username, password = cred.get()
        self.assertTrue( username == PCredFunctions.AUSERNAME )
        self.assertTrue( password == PCredFunctions.APASSWORD )

    def testE_save(self):
        cred = Credential()
        username="A"*Credential.MAX_USERNAME_LENGTH
        cred.set(username, PCredFunctions.APASSWORD)

    def genUsernameToLongError(self):
        cred = Credential()
        username="A"*(Credential.MAX_USERNAME_LENGTH+1)
        cred.set(username, PCredFunctions.APASSWORD)

    def testF_save(self):
        with self.assertRaises(CredentialError):
            self.genUsernameToLongError()

    def testG_save(self):
        cred = Credential()
        password="A"*Credential.MAX_PASSWORD_LENGTH
        cred.set(PCredFunctions.AUSERNAME, password)

    def genPasswordToLongError(self):
        cred = Credential()
        password="A"*(Credential.MAX_PASSWORD_LENGTH+1)
        cred.set(PCredFunctions.AUSERNAME, password)

    def testH_save(self):
        with self.assertRaises(CredentialError):
            self.genPasswordToLongError()

    def testI_save(self):
        cred = Credential()
        cred.set(PCredFunctions.AUSERNAME, PCredFunctions.APASSWORD)
        cred.store(PCredFunctions.CRED_REF)
        self.assertTrue( cred.credentialStored(PCredFunctions.CRED_REF) )

    def testI_save(self):
        cred = Credential()
        cred.set(PCredFunctions.AUSERNAME, PCredFunctions.APASSWORD)
        cred.store(PCredFunctions.CRED_REF)
        cred.remove(PCredFunctions.CRED_REF)
        self.assertFalse( cred.credentialStored(PCredFunctions.CRED_REF) )

    def testJ_save(self):
        cred = Credential()
        cred.set(PCredFunctions.AUSERNAME, PCredFunctions.APASSWORD)
        cred.store(PCredFunctions.CRED_REF)

        cred = Credential()
        cred.load(PCredFunctions.CRED_REF)
        username, password = cred.get()
        self.assertTrue( username == PCredFunctions.AUSERNAME )
        self.assertTrue( password == PCredFunctions.APASSWORD )
        cred.clear()
        username, password = cred.get()
        self.assertTrue( username == "" )
        self.assertTrue( password == "" )

    def tearDown(self):
        cred = Credential()
        if cred.credentialStored(PCredFunctions.CRED_REF):
            cred.remove(PCredFunctions.CRED_REF)

if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(PCredFunctions)
    unittest.TextTestRunner(verbosity=2).run(suite)
