#!/bin/sh
#This test must be run as root and will fail if /dev/spidev0.1 does not exist.
sudo PYTHONPATH=build/lib.linux-armv6l-2.7/ ./test_pspi.py
