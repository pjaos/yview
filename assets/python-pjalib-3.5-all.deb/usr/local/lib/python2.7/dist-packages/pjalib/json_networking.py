#!/usr/bin/env python
import  SocketServer
import  socket
from    struct import pack, unpack
import  json

class JSONNetworking(Exception):
    pass


class JSONServer(SocketServer.ThreadingTCPServer):
    """@brief Responsible for accepting tcp connections to receive and send json messages."""

    daemon_threads = True
    allow_reuse_address = True


class JsonServerHandler (SocketServer.BaseRequestHandler):

    LEN_FIELD = 4

    @staticmethod
    def DictToJSON(aDict):
        """@brief convert a python dictionary into JSON text
           @param aDict The python dictionary to be converted
           @return The JSON text representing aDict"""
        return json.dumps(aDict)

    @staticmethod
    def JSONToDict(jsonText):
        """@brief Convert from JSON text to a python dict. Throws a ValueError
                  if the text is formatted incorrectly.
           @param jsonText The JSON text to be converted to a dict
           @return a python dict object"""
        return json.loads(jsonText)

    @staticmethod
    def READ(request, size):
        """@brief Read a number of bytes from the request object.
                  Blocks until the bytes are received is received.
           @param request The request object passed from the handle() method."""
        data = ''
        while len(data) < size:
            dataTmp = request.recv(size-len(data))
            data += dataTmp
            if dataTmp == '':
                raise RuntimeError("Socket closed")
        return data

    @staticmethod
    def GetMsgLength(request):
        """@brief Read the length of the subsequent message from the
                  request object.
                  Blocks until a message is received.
           @param request The request object passed from the handle() method."""
        d = JsonServerHandler.READ(request, JsonServerHandler.LEN_FIELD)
        s = unpack('>I', d)
        return s[0]

    @staticmethod
    def RX(request):
        """@brief Get a dictionary object from a json message.
                   Blocks until a message is received.
           @param request The request object passed from the handle() method.
           @return a python dictionary object."""
        if request:
            size = JsonServerHandler.GetMsgLength(request)
            data = JsonServerHandler.READ(request,  size)
            sFmt = ">%ds" % (size)
            msg = unpack(sFmt, data)
            return JsonServerHandler.JSONToDict(msg[0])
        else:
            raise RuntimeError("RX socket error")

    @staticmethod
    def TX(request, theDict):
        """@brief Write the dict to the socket as json text
           @param request The request object passed from the handle() method.
           @theDict The python dictionary to send."""
        if request:
            msg = JsonServerHandler.DictToJSON(theDict)
            sFmt = ">%ds" % len(msg)
            bodyLen = pack('>I', len(msg))
            body = pack(sFmt, msg)
            request.send(bodyLen)
            request.send(body)
        else:
            raise RuntimeError("TX socket error")

    def handle(self):
        """@brief Handle connections to the server."""
        raise JSONNetworking("!!! You must override this method in a subclass !!!")


class JSONClient(object):

    def __init__(self, address, port, keepAliveActSec=1, keepAliveTxSec=15, keepAliveFailTriggerCount=8):
        """@brief Connect to a JSONServer socket.
                  If on a Linux system then the connection will apply a keepalive to the TCP connection.
                  By default this is 2 minutes.
           @param address The address of the JSONServer.
           @param The port on the JSON server to connect to.
           @param keepAliveActSec Activate the keepalive failure this many seconds after it is triggered.
           @param keepAliveTxSec Send a TCP keepalive periodically. This defines the period in seconds.
           @param keepAliveFailTriggerCount Trigger a keepalive failure when this many keepalives fail consecutively."""

        self._socket = socket.socket()
        self._socket.connect( (address, port) )
            
        if hasattr(socket, 'SOL_SOCKET') and\
           hasattr(socket, 'SO_KEEPALIVE') and\
           hasattr(socket, 'IPPROTO_TCP') and\
           hasattr(socket, 'TCP_KEEPIDLE') and\
           hasattr(socket, 'TCP_KEEPINTVL') and\
           hasattr(socket, 'TCP_KEEPCNT'):        
            self._socket.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            self._socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, keepAliveActSec)
            self._socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, keepAliveTxSec)
            self._socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPCNT, keepAliveFailTriggerCount)

    def tx(self, theDict, throwError=True):
        """@brief send a python dictionary object to the server via json
           @param theDict The dictionary to send
           @param throwError If True then an exception will be thrown if an error occurs.
                              If False then this method will fail silentley.
           @return True on success. False on failure if throwError = False"""
        try:
            JsonServerHandler.TX(self._socket, theDict)
            return True
        except:
            if throwError:
                raise
            return False

    def rx(self, throwError=True):
        """@brief Get a python dictionary object from the server.
                   Blocks until complete message is received.
           @param throwError If True then an exception will be thrown if an error occurs.
                             If False then None will be returned."""
        try:
            return JsonServerHandler.RX(self._socket)
        except:
            if throwError:
                raise
            return None

    def close(self):
        """@brief Close the socket connection to the server."""
        if self._socket:
            self._socket.close()
